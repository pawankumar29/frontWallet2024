import { Col, Pagination, Row, Spin, Table } from "antd";
import React, { useEffect, useState } from "react";
import "./TransactionHistory.scss";
import DropdownCustom from "../../Common/Components/DropdownCustom/DropdownCustom";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import { CopyOutlined } from "@ant-design/icons";
import { useGetLatestTransactionMutation } from "../../Utility/Services/TransactionsAPI";
import moment from "moment";
import { formatNumber, toFixedVal } from "../../Common/functions/comman";
import { toast } from "react-toastify";
import { URL } from "../../Constant copy/Constant";
import _debounce from "lodash/debounce"; // Import debounce function

const limit = 10;
const menuPropsType = ["all", "deposit", "withdraw", "swap"];
const menuPropsStatus = ["all", "confirmed", "pending", "failed"];
const menuPropsEntity = ["all", "date_order", "usd_amount", "crypto_amount"];
const menuPropsAsc = ["ascending", "descending"];
const menuPropsFilter = ["all", "from_address", "to_address", "coin_name", "hash"];
//searchBy: for serach
function TransactionHistory() {
  const [page, setPage] = useState(1);
  const [isOpen, setIsOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("");
  const [entityFilter, setEntityFilter] = useState("");

  const [searchValue, setSearchValue] = useState("");
  const [searchFilter, setSearchFilter] = useState("");
  const [type, setType] = useState("");
  const [order, setOrder] = useState("descending");
  //descending
  const [isOpenType, setIsOpenType] = useState(false);
  const [isOpenEntity, setisOpenEntity] = useState(false);
  const [isOpenStatus, setIsOpenStatus] = useState(false);

  const [isOpenAsc, setIsOpenAsc] = useState(false);
  const [isOpenFilter, setIsOpenFilter] = useState(false);

  const [getLatestTransaction, { data, isLoading }] =
    useGetLatestTransactionMutation();

  useEffect(() => {
    latestTransaction();
  }, [page, type, searchValue, statusFilter, order, entityFilter]);

  const latestTransaction = async () => {
    let payload = {
      limit,
      page,
      status: statusFilter,
      trnx_type: type,
      searchBy: searchValue,
      filterType: searchFilter === "" ? "all" : searchFilter,
      entity_type_order: order,
      entity_type: entityFilter
    };
    getLatestTransaction(payload);
  };

  const columns = [
    {
      title: "From",
      dataIndex: "from_adrs",
      key: "from_adrs",
      render: (text, record) => (
        <div className="copyIcon">
          {record?.from_adrs}
          <CopyOutlined
            onClick={() => {
              window.navigator.clipboard.writeText(text);
              toast.success("Copied");
            }}
          />
        </div>
      ),
    },

    {
      title: "To",
      dataIndex: "to_adrs",
      key: "to_adrs",
      render: (text, record) => (
        <div className="copyIcon">
          {record?.to_adrs}
          <CopyOutlined
            onClick={() => {
              window.navigator.clipboard.writeText(text);
              toast.success("Copied");
            }}
          />
        </div>
      ),
    },
    {
      title: "Coin Name",
      dataIndex: "coin_data?.coin_symbol",
      key: "coin_data?.coin_symbol",
      render: (text, record) => (
        <span>{record?.coin_transation_data?.coin_name}</span>
      ),
    },
    {
      title: "Crypto Amount",
      key: "amount",
      dataIndex: "amount",
      render: (text, record) => <span>{formatNumber(record?.amount, 6)}</span>,
    },
    {
      title: "USD Amount",
      key: "USDAmount",
      dataIndex: "USDAmount",
      // render: (text, record) => (record?.usd_amount),
      render: (text, record) => (
        <span>
          {
            toFixedVal(
              record?.usd_amount,
              2
            )
          }

        </span>
      ),

    },
    {
      title: "Hash",
      key: "tx_id",
      dataIndex: "tx_id",
      // render: (text, record) => <a>{record?.coin_data?.coin_symbol}</a>,
    },
    {
      title: "Blockchain Status",
      key: "blockchain_status",
      dataIndex: "blockchain_status",
      render: (text, record) => <span>{record?.blockchain_status}</span>,
    },
    {
      title: "Type",
      key: "type",
      dataIndex: "type",
      render: (text, record) => <span>{text}</span>,
    },
    {
      title: "Date",
      key: "Date",
      dataIndex: "Date",
      render: (text, record) => (
        <p>
        {moment(record?.created_at).format("DD/MM/YYYY hh:mm A")}
        </p>

      )
      // <a>moment(record?.created_at).format("DD/MM/YYYY hh:mm")</a>}),
      // moment(record?.created_at).format("MM/DD/YYYY hh:mm")
    },
  ];

  // Function to handle downloading CSV file
  const handleDownloadCSV = () => {
    const response = `${URL.API_URL}transaction/download`;
    window.open(response);
    return;
  };

  // Function to handle filtering transactions by status
  const handleStatusFilter = (status) => {
    setStatusFilter(status);
    setPage(1);
  };
  // Function to handle filtering transactions by type
  const handleTypeFilter = (type) => {
    setType(type);
    setPage(1);
  };

  // Function to handle searching transactions
  const handleSearchFilter = (search) => {
    setSearchFilter(search);
    setPage(1);
  };

  // Function to handle ordering transactions
  const handleOrderFilter = (order) => {
    setOrder(order);
    setPage(1);
  };

  // Function to handle searching transactions by a specific value
  const handleSearch = (searchValue) => {
    const trimmedSearchValue = searchValue.trim();
    setSearchValue(trimmedSearchValue);
    setPage(1);
    latestTransaction();
  };

  const handleSelectEntity = (select) => {
    setEntityFilter(select);
    setPage(1);
  };

  const debouncedSearch = _debounce(handleSearch, 500);


  return (
    <div className="transactionHistory">
      <div className="commonCardBg">
        <div className="transactionHistory_top">
          <h2>Transaction History</h2>
        </div>
        <div className="transactionHistory_filters">
          <Row gutter={[15, 15]} className="no-wrap-row">
            <Col>
              <DropdownCustom
                buttonText="Filter"
                menuItems={menuPropsFilter}
                className="action"
                handleMenuClick={handleSearchFilter}
                isOpen={isOpenFilter}
                setIsOpen={setIsOpenFilter}
                value={searchFilter}
              />
            </Col>
            <Col>
              <InputCustom
                searchInputs
                onChange={debouncedSearch}
                placeholder="Search transactions"
              />
            </Col>
          </Row>

          <Row gutter={[15, 15]}>
            <Col>
              <DropdownCustom
                buttonText="Type"
                menuItems={menuPropsType}
                className="action"
                handleMenuClick={handleTypeFilter}
                isOpen={isOpenType}
                setIsOpen={setIsOpenType}
                value={type}
              />
            </Col>
            <Col>
              <DropdownCustom
                buttonText="Status"
                menuItems={menuPropsStatus}
                className="action"
                handleMenuClick={handleStatusFilter}
                isOpen={isOpenStatus}
                setIsOpen={setIsOpenStatus}
                value={statusFilter}
              />
            </Col>
            <Col>
              <DropdownCustom
                buttonText="Select Entity"
                menuItems={menuPropsEntity}
                className="action"
                isOpen={isOpenEntity}
                setIsOpen={setisOpenEntity}
                handleMenuClick={handleSelectEntity}
                value={entityFilter}
              />
            </Col>

            <Col>
              <DropdownCustom
                buttonText="Ascending"
                menuItems={menuPropsAsc}
                className="action"
                handleMenuClick={handleOrderFilter}
                isOpen={isOpenAsc}
                setIsOpen={setIsOpenAsc}
                value={order}
              />
            </Col>
            <Col>
              <ButtonCustom
                regularBtn
                label="Download CSV"
                className="downloadcsv"
                onClick={handleDownloadCSV}
              />
            </Col>
          </Row>
        </div>

        <div>
          <Spin spinning={isLoading}>
            <Table
              columns={columns}
              dataSource={data?.data}
              pagination={false}
            />
            <Pagination
              current={page}
              onChange={(e) => setPage(e)}
              total={data?.meta?.total}
              pageSize={limit}
              showSizeChanger={false}
            />
          </Spin>
        </div>
      </div>
    </div>
  );
}

export default TransactionHistory;
