import React, { useEffect, useState } from "react";
import "./Dashboard.scss";
import { Col, Row, Table } from "antd";
import { ArrowDownOutlined } from "@ant-design/icons";
import DoughnutChart from "../../Common/Components/DoughnutChart/DoughnutChart";
import { Link } from "react-router-dom";
import RecentTransactions from "../../Common/Components/RecentTransactions /RecentTransactions";
import DropdownCustom from "../../Common/Components/DropdownCustom/DropdownCustom";
import { useLazyGetUserCountQuery } from "../../Utility/Services/UserListAPI";
import { useGetSwapCoinsMutation } from "../../Utility/Services/SwapcoinAPI";
import { useGetSwapTransactionMutation } from "../../Utility/Services/SwapTransactionAPI";
// import DarkLineChart from "../../Common/Components/LineChart/LineChart";
import TransactionVolumeGraph from "../../Common/Components/DoughnutChart/TransactionVolumeGraph";
import TransactionGraph from "../../Common/Components/DoughnutChart/TransactionGraph";

const CoinToken = [["ETH"], ["BNB"], ["BTC"], ["USDT"]];
const menuProps = [["All"], ["1 Day"], ["1 Week"], ["1 Month"]];
function Dashboard() {
  const [timeLine, setTimeLine] = useState(["All"]);
  const [active, setActive] = useState(["All"]);
  const [isOpen, setIsOpen] = useState(false);
  const [timeline, setIsOpenTimeline] = useState(false);
  const [getUserCount, { data: count, isLoading }] = useLazyGetUserCountQuery();
  const [getSwap, { data: coinData }] = useGetSwapCoinsMutation();
  const [getSwapCoins, { data: coinDataFromIds }] = useGetSwapTransactionMutation();

  //useEffect
  useEffect(() => {
    getCount();
    getCoins();
  }, [active]);
  //coin ids
  // const coinIds = async () => {
  //   let ids = [];
  //   console.log(coinData,"COINDATATTATA")
  //   // coinData?.data?.map((coin) => ids.push(coin?.coin_id));
  //   coinData?.data?.map((coin) => console.log(coin, "CCCCC"));
  //   return ids;
  // };


  const coinIds = async () => {
    let ids = [];
    coinData?.data?.coin_data.forEach((coin) => ids.push(coin.coin_id))
    coinData?.data?.token_data.forEach((token) => ids.push(token.coin_id))
    return ids;
  };

  const getSwapTransactionData = async () => {
    const ids = await coinIds();
    const getCoinDataFromIds = () => {
      let data = {
        coin_ids: ids
      };
      getSwapCoins(data);
    };
    getCoinDataFromIds();
  }

  //useEffect
  useEffect(() => {
    getSwapTransactionData()
  }, [coinData]);

  //
  const getCount = () => {
    let payload = "";
    if (active[0] == "1 Day") {
      payload = "1d";
    }
    if (active[0] == "1 Week") {
      payload = "1w";
    }
    if (active[0] == "1 Month") {
      payload = "1m";
    }
    getUserCount(payload);
  };

  const getCoins = () => {
    let data = {
      coin_symbols: ["eth", "bnb", "trx"],
      token_symbols: ["usdt"]
    };
    getSwap(data);
  };

  //
  const handleMenuClick = (e) => {
    setActive(e);
    setIsOpen(false);
  };
  const handleClick = (e) => {
    console.log(e)
    setIsOpenTimeline(false)
    setTimeLine(e);
    // setIsOpen(false);
  };
  //
  const columns = [
    {
      title: "Token",
      dataIndex: "Token",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Total Swap Volume",
      dataIndex: "TotalSwapVolume",
    },
    {
      title: "24 Hour",
      dataIndex: "Hour",
    },
    {
      title: "7 Days",
      dataIndex: "Days7",
    },
    {
      title: "30 Days",
      dataIndex: "Days30",
    },
  ];

  //
  const data = coinDataFromIds?.data?.map((coin) => {
    const {
      coin_id: key,
      coin_image,
      coin_name,
      coin_symbol,
      coin_transation_data,
      fiat_price_data
    } = coin;

    const totalSwapAmount = coin_transation_data[0]?.total_swap_amount || 0;
    const fiatType = coin_transation_data[0]?.fiat_type || "";
    const totalInFiat = (totalSwapAmount * fiat_price_data.value).toFixed(2);
    console.log(totalInFiat, "TOTAL")
    const hourPriceChange = fiat_price_data?.latest_price?.price_change_24h || 0;
    const days7PriceChange = fiat_price_data?.latest_price?.percent_change_7d || 0;
    const days30PriceChange = fiat_price_data?.latest_price?.percent_change_30d || 0;

    const renderPriceChange = (change, period) => {
      const absChange = Math.abs(change); // Get the absolute value of the change

      return (
        <p className={change >= 0 ? "greenUpIcon" : "redDownIcon"}>
          {change >= 0 ? <ArrowDownOutlined /> : <ArrowDownOutlined />} ({absChange}%)
        </p>
      );
    };
    return {
      key,
      Token: (
        <div className="tableUserProfile">
          <img src={coin_image} alt="" />
          <p>{coin_name} ({coin_symbol})</p>
        </div>
      ),
      TotalSwapVolume: `$ ${totalInFiat} ${fiatType}`,
      Hour: renderPriceChange(hourPriceChange, "Hour"),
      Days7: renderPriceChange(days7PriceChange, "7 days"),
      Days30: renderPriceChange(days30PriceChange, "30 days"),
    };
  });

  return (
    <div className="dashboard">
      <Row gutter={[25, 25]}>
        <Col sm={24} md={24} lg={9}>
          <div className="dashboard_detailCard">
            <div className="commonCardBg">
              <h4>Active User</h4>
              <h3 className="percentageHeigh">
                <strong> {count?.data || 0}</strong>
              </h3>
              <div className="timeLineDrop">
                <DropdownCustom
                  buttonText={active || "Timeline"}
                  menuItems={menuProps}
                  className="action "
                  handleMenuClick={handleMenuClick}
                  isOpen={isOpen}
                  setIsOpen={setIsOpen}
                />
              </div>
              <DoughnutChart />
            </div>
          </div>
        </Col>
        <Col md={24} lg={15}>
          <div className="dashboard_report commonCardBg">
            <div className="dashboard_report_heading">
              <h5>
                What’s up Today <br />
                <span className="dashboard_report_subheading">
                  Date <span>00/00/0000</span>
                </span>
              </h5>
              <DropdownCustom
                buttonText={timeLine || "Timeline"}
                menuItems={CoinToken}
                className="action "
                handleMenuClick={handleClick}
                isOpen={timeline}
                setIsOpen={setIsOpenTimeline}
              />
            </div>
            <div className="dashboard_report_detail">
              <div className="dashboard_report_detail_left">
                <p>
                  <span>8</span> <span>minutes</span> <span>Ago</span>
                </p>
                <h6>Top Airdrops to Watch in May!</h6>
                <p>
                  The post Top Airdrops to Watch in May! appeared first on
                  Coinpedia Fintech News With the rising bullish sentiments in
                  the cryptocurrency industry post-Bitcoin-Halving and increased
                  price volatility, the market is predicted to achieve a new
                  all-time high (ATH) during the upcoming ...
                </p>
              </div>
              <div>
                <Link className="tableViewBtn"> View</Link>
              </div>
            </div>
            <div className="dashboard_report_detail">
              <div className="dashboard_report_detail_left">
                <p>
                  <span>18</span> <span>minutes</span> <span>Ago</span>
                </p>
                <h6>Ethereum’s Price Dynamics and Market Movements</h6>
                <p>
                  Ethereum shows steady recovery in daily charts. ETH price nears critical point with falling wedge pattern. Continue Reading:Ethereum’s Price Dynamics and Market Movements
                </p>
              </div>
              <div>
                <Link className="tableViewBtn"> View</Link>
              </div>
            </div>
            <div className="dashboard_report_detail">
              <div className="dashboard_report_detail_left">
                <p>
                  <span>2</span> <span>hours</span> <span>Ago</span>
                </p>
                <h6>Two Altcoins Set to Outperform This Week</h6>
                <p>
                  The post Two Altcoins Set to Outperform This Week appeared first on Coinpedia Fintech News A recent video analysis by Youtuber and crypto expert Crypto Banter has shed light on Bitcoin’s (BTC) current trading position of around $63,500, noting a resurgence in market strength foll...
                </p>
              </div>
              <div>
                <Link className="tableViewBtn"> View</Link>
              </div>
            </div>
          </div>
        </Col>
        <Col md={24}>
          <div className="commonCardBg">
            <h2>Swap Volume and Market Trend</h2>
            <Table scroll={{ x: 400 }} columns={columns} dataSource={data} />
          </div>
        </Col>
        <Col sm={24} md={12}>
          <div className="dashboard_userRegistration commonCardBg">
            <h2>Transaction Volume</h2>
            <Col xs={30} md={30}>
              <TransactionVolumeGraph />
            </Col>
            {/* <TransactionGraph /> */}
            {/* <DarkLineChart /> */}
            {/* <img src={chart} alt="" /> */}
          </div>
        </Col>
        <Col sm={24} md={12}>
          <div className="commonCardBg">
            <RecentTransactions />
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default Dashboard;
