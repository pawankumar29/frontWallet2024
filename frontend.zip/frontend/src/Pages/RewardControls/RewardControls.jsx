import React, { useEffect, useState } from "react";
import "./RewardControls.scss";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import { useLazyGetAllRewardsQuery, useUpdateRewardsMutation } from "../../Utility/Services/ReferralApi";

function RewardControls() {
  const [swap, setSwap] = useState("")
  const [swapReward, setSwapReward] = useState("")
  const [amount, setRewardAmount] = useState("")
  const [transaction, setTransaction] = useState("")
  const [getAllRewards, { data }] = useLazyGetAllRewardsQuery();
  const [updateRewards, { data: updateData }] = useUpdateRewardsMutation();


  useEffect(() => {
    getAllRewards()
  }, [])

  const handleUpdate = async () => {
    try {
      const swapNumber = parseFloat(swap);
      const swapRewardNumber = parseFloat(swapReward);
      const amountNumber = parseFloat(amount);
      const transactionNumber = parseFloat(transaction);

      // Check if any of the values are NaN (not a number)
      // if (isNaN(swapNumber) || isNaN(swapRewardNumber) || isNaN(amountNumber) || isNaN(transactionNumber)) {
      //   console.error("Invalid number input");
      //   // Handle the case where inputs are not valid numbers
      //   return;
      // }
      let payload = {
        type_1:"swap",
        type_number_1: swapNumber,
        reward_amount_1: swapRewardNumber,
        type_2:"TRANSACTION",
        type_number_2: amountNumber,
        reward_amount_2: transactionNumber
      };
      const response = await updateRewards(payload);

      console.log(response, "RES");
      // Extract the message from the response
      const message = response?.data?.message;
      toast.success(message);
      console.log(message, "MES");

    }
    catch (error) {
      // Handle error if submission fails
      console.error("Error adding token:", error);
    }

  }




  return (
    <div className="controlReward">
      <div className="commonCardBg">
        <div className="controlReward_head">
          <div className="controlReward_head_left"></div>
          <div className="controlReward_head_right">
            <h2>No. of Swap </h2> <h2>Reward Amount</h2>
          </div>
        </div>
        {/* Mapping and displaying "Swap" data */}
        {data && data?.data.map((item) => (
          item.type.toLowerCase() === "swap" && (
            <div key={item.id} className="controlReward_head">
              <div className="controlReward_head_left">
                <h3>Swap :</h3>
              </div>
              <div className="controlReward_head_right">
                <InputCustom regularInput value={swap === "" ? item.type_number : swap} onChange={(e) => setSwap(e.target.value)} />
                <InputCustom regularInput value={swapReward === "" ? item.reward_amount : swapReward} onChange={(e) => setSwapReward(e.target.value)} />
              </div>
            </div>
          )
        ))}
        {data && data?.data?.map((item) => (
          item.type.toLowerCase() === "transaction" && (
            <div key={item.id} className="controlReward_head">
              <div className="controlReward_head_left">
                <h3>Transaction :</h3>
              </div>
              <div className="controlReward_head_right">
                <InputCustom regularInput value={transaction === "" ? item.type_number : transaction} onChange={(e) => setTransaction(e.target.value)} />
                <InputCustom regularInput value={amount === "" ? item.reward_amount : amount} onChange={(e) => setRewardAmount(e.target.value)} />
              </div>
            </div>
          )
        ))}
        <div className="controlReward_saveBtn">
          <ButtonCustom label="Save" regularBtn onClick={handleUpdate} />
        </div>
      </div>
    </div>

  );
}

export default RewardControls;
