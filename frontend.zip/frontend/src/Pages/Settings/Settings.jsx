import React from "react";
import "./Settings.scss";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import qrcode from "../../assets/qr-code.jpg";
import { Switch } from "antd";

function Settings() {
  return (
    <div className="setting">
      <div className="setting_left commonCardBg">
        <h2>Change Password</h2>
        <InputCustom
          label
          labletext="Old Password"
          placeholder="Old Password"
          type="password"
          passwordInput
        />

        <InputCustom
          label
          labletext="New Password"
          placeholder="New Password"
          type="password"
          passwordInput
        />
        <InputCustom
          label
          labletext="Confirm Password"
          placeholder="Confirm Password"
          type="password"
          passwordInput
        />
        <div className="setting_left_btn">
          <ButtonCustom label="Submit" regularBtn />
        </div>
      </div>
      <div className="setting_right commonCardBg">
        <div className="setting_right_toggle d-flex accountsPlan">
          <div className="google">
            <div className="">
              <h3>Enable Server maintenance mode </h3>
            </div>
          </div>
          <Switch defaultChecked={true} onChange={false} />
        </div>
        <div>
          <h2>Enable 2FA</h2>
          <div className="setting_right_qrCode">
            <img src={qrcode} alt="qrcode" />
            <InputCustom regularInput placeholder="" />
            <InputCustom regularInput placeholder="" />
            <div className="setting_right_qrCode_btn">
              <ButtonCustom
                label="Close"
                regularBtn
                className="announcement_top_sendBtn"
              />
              <ButtonCustom
                label="Enable"
                regularBtn
                className="announcement_top_sendBtn"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Settings;
