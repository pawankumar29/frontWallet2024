import React, { useEffect, useState } from "react";
import "./UserList.scss";
import { Modal, Pagination, Spin, Table, Tag } from "antd";
import {
  CopyOutlined,
  DeleteFilled,
  ExportOutlined,
  FilterOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import { Link, useNavigate } from "react-router-dom";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import userImg from "../../assets/maxSmith.jpg";
import { toast } from "react-toastify";
import { useGetUserDataListMutation, useLazyDeleteUserQuery } from "../../Utility/Services/UserDataListAPI";
import moment from "moment";
import { URL } from "../../Constant copy/Constant";

function UserList() {
  const limit = 10;
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [selectionType, setSelectionType] = useState("checkbox");
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [deleteModal, setDeleteModal] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [deleteId, setDeleteId] = useState(null)
  const [search, setSearch] = useState("");

  const [getUserDataList, { data, isLoading }] = useGetUserDataListMutation();
  const [deleteUser, { isLoading: deleteLoading }] = useLazyDeleteUserQuery();

  console.log(page, "PAGE====>");

  useEffect(() => {
    userListData();
  }, [page, search]);

  const handleViewUserDetails = (e, user) => {
    e.preventDefault();

    navigate(`/customerDetail`, { state: { userData: user } });
  };

  const handleDownloadCSV = () => {
    const response = `${URL.API_URL}users/exportCsv?search=${search}`;
    console.log("RESPONSE", response)
    window.open(response);
    return;
  };

  const userListData = async () => {
    let payload = { limit, page, search };
    getUserDataList(payload);
  };

  const handleSearch = (searchValue) => {
    const trimmedSearchValue = searchValue.trim();
    setSearch(trimmedSearchValue);
    userListData();
    setPage(1);
  };

  const modalOpen = (coin_id) => {
    console.log(coin_id,"ididi");
    setDeleteModal(true);
    setDeleteId(coin_id)
  };

  const handleOk = () => {
    setDeleteModal(false);
  };

  const handleCancel = () => {
    setDeleteModal(false);
  };

  const handleDeleteConfirmation = async (coin_id) => {
    console.log(coin_id, "IDDDDDD");
    try {
      await deleteUser(coin_id);
      setDeleteConfirm(false);
      getUserDataList(); // Refresh token list after deletion
      // setDeleteItem(null);
      setDeleteModal(false); // Close the delete modal
      toast.success("Token deleted successfully.");
    }
    catch (error) {
      console.error("Error deleting token:", error);
      toast.error("Failed to delete token. Please try again later.");
    }
  };
  const items = [
    {
      key: "1",
      label: "Action 1",
    },
    {
      key: "2",
      label: "Action 2",
    },
  ];

  const columns = [
    {
      title: "S.No",
      dataIndex: "serialNo",
    },
    {
      title: "Date",
      dataIndex: "date",
    },
    {
      title: "Wallet Name",
      dataIndex: "walletName",
    },

    {
      title: "Wallet Address",
      dataIndex: "address",
    },

    {
      title: "Multichain Portfolio",
      dataIndex: "mPort",
    },
    {
      title: "ACTIONS",
      dataIndex: "action",
    },
  ];
  function calculateSerialNumber(index) {
    return (page - 1) * limit + index + 1;
  }

  const tableData = data?.data?.map((user, index) => {
    console.log(user, "USERSERERS");
    const { wallet_id, user_id, wallet_name, address, coin, coin_name, total_user_balance } = user;


    return {
      key: user_id,
      serialNo: (
        <div className="tableUserProfile">
          <p>
            {calculateSerialNumber(index)}
          </p>
          <p>
            {wallet_name?.length > 10
              ? wallet_name.substring(0, 10) + "..."
              : ""}{" "}
            <br />
          </p>
          {console.log("this is the dat inded", data.data[index])}
        </div>
      ),
      date: moment(user?.created_at).format("DD/MM/YYYY hh:mm A"),
      // date: timestamp ? new Date(timestamp).toLocaleDateString() : null,
      walletName: wallet_name,
      address: (
        <div>
          {address.length > 10
            ? address.substring(0, 10) + "..."
            : address}
          <CopyOutlined
            style={{ marginLeft: "6px" }}
            onClick={() => {
              window.navigator.clipboard.writeText(address);
              toast.success("Copied");
            }}
          />
        </div>
      ),
      mPort: total_user_balance,
      action: (
        <div>
          <Link
            className="tableViewBtn"
            onClick={(event) => {
              console.log(event, "envet");
              handleViewUserDetails(event, data.data[index]);
            }}
          >
            View
          </Link>
          <span className="delteBtn">
            <DeleteFilled onClick={() => modalOpen(user?.user_id)} />
          </span>
        </div>
      ),
    };
  });
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      console.log(
        `selectedRowKeys: ${selectedRowKeys}`,
        "selectedRows: ",
        selectedRows
      );

      setSelectedUsers(selectedRows);
    },
  };
  console.log(data?.meta?.total, "DATADTADTAYTDYSD465465--");
  return (
    <div className="userList">
      <div className="commonCardBg">
        <div className="userList_top">
          <InputCustom
            searchInputs
            placeholder="Search By Username/Wallet Address"
            onChange={handleSearch}
          />
          <div className="userList_top_btn">
            {selectedUsers.length === 0 ? (
              <div className="userList_top_btn">
                <ButtonCustom
                  icon={<FilterOutlined />}
                  label="Filter"
                  regularBtn
                  className="editBtn"
                />
                <ButtonCustom
                  icon={<ExportOutlined />}
                  label="Export"
                  regularBtn
                  className="editBtn"
                  onClick={handleDownloadCSV}
                />
              </div>
            ) : (
              <div className="userList_top_btn">
                <ButtonCustom icon={<DeleteFilled />} label="Delete" redBtn />
              </div>
            )}
          </div>
        </div>

        <Spin spinning={isLoading}>
          <Table
            rowSelection={{
              type: selectionType,
              ...rowSelection,
            }}
            columns={columns}
            dataSource={tableData}
            pagination={false}
            scroll={{ x: 1300, y: 400 }}
          />
          <Pagination
            current={page}
            onChange={(e) => setPage(e)}
            total={data?.meta?.total}
            pageSize={limit}
            showSizeChanger={false}
          />
        </Spin>
      </div>
      <Modal
        visible={deleteModal}
        onOk={() => handleDeleteConfirmation(deleteId)}
        onCancel={handleCancel}
        centered
      >
        <div className="deletModal">
          <h4>Do you want to delete user</h4>
          <div className="deletModal_btn">
            <ButtonCustom label="Yes" regularBtn onClick={() => handleDeleteConfirmation(deleteId)} />
            <ButtonCustom label="No" regularBtn className="deletModal_btn_no" onClick={handleCancel} />
          </div>
        </div>
      </Modal>
    </div>
  );
}

export default UserList;
