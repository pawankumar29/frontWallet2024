import React, { useEffect, useState } from "react";
import "../PaymentRecords/PaymentRecords.scss";
import { Col, Row, Table } from "antd";
import { ExportOutlined } from "@ant-design/icons";
import DropdownCustom from "../../../Common/Components/DropdownCustom/DropdownCustom";
import ButtonCustom from "../../../Common/Components/ButtonCustom/ButtonCustom";
import { useGetSwapTransactionMutation } from "../../../Utility/Services/UserDataListAPI";
import { useLocation } from "react-router-dom";
import moment from "moment";

function SwapTable({ userList }) {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");

  const [filterType, setFilterType] = useState("");
  const [order, setOrder] = useState("descending");
  //descending
  const [isOpenType, setIsOpenType] = useState(false);
  const [isOpenStatus, setIsOpenStatus] = useState(false);
  const location = useLocation();
  console.log("this is the location at cutomer", location);
  const { userData } = location.state;
  const [getSwapTransaction, { data: getswapTransaction }] =
    useGetSwapTransactionMutation();

  // coin_ids":[1,2,6],
  // "wallet_address": "0x3b71ec93c9fe8c59f6200b87ea9526ed05fc0830"

  console.log(getswapTransaction, "getSwap");
  const { wallet_address, user_id } = userData;
  console.log(userList.userList, "da=======>>>")
  // let addresses = []
  // wallet_address && wallet_address?.map((address, i) => {
  //   address.push(addresses)
  // })
  // console.log(addresses, "ADDRESS++++")
  useEffect(() => {
    tokenListData();
  }, [page, statusFilter, filterType]);

  const tokenListData = async (walletAddress) => {
    const walletAdd = []
    if (userList?.userList) {
      for (const user of userList.userList) {
        walletAdd.push(user?.wallet_address)
      }
    }
    let payload = {
      address_list: walletAdd, status: statusFilter, filter_type:filterType
    };
    getSwapTransaction(payload);
  };

  const menuPropsType = ["deposit", "withdraw", "swap"];
  const menuPropsStatus = ["confirmed", "pending", "failed"];

  const handleDownloadCSV = () => {
    // const response = `${URL.API_URL}transaction/download`;
    // window.open(response);
    // return;
  };

  // Function to handle filtering transactions by status
  const handleStatusFilter = (status) => {
    setStatusFilter(status);
    setIsOpenType(true);
  };
  // Function to handle filtering transactions by type
  const handleTypeFilter = (type) => {
    setFilterType(type);
    setIsOpenType(true);

  };

  const columns = [
    {
      title: "Date",
      dataIndex: "Date",
      key: "Date",
    },
    {
      title: "From Coin",
      dataIndex: "FromCoin",
      key: "FromCoin",
    },
    {
      title: "To Coin",
      dataIndex: "ToCoin",
      key: "ToCoin",
    },

    {
      title: "Amount",
      key: "Amount",
      dataIndex: "Amount",
    },

    {
      title: "Transaction Hash",
      dataIndex: "TranHash",
      key: "TranHash",
    },
  ];


  const data1 = getswapTransaction?.data?.map((transaction, i) => {
    console.log(transaction, "TRTRSTRSTRS")
    const {
      coin_id: key,
      from_adrs,
      to_adrs,
      amount,
      tx_id,
      updated_at,
      created_at,
    } = transaction;
    // const address = transaction?.coin_transation_data?.fiat_price_data?.token_address;
    // console.log(address, "DDDDDDDTTT")
    return {
      key: String(key),
      Date: (
        <p>
          {moment(created_at).format("DD/MM/YYYY hh:mm A")}
        </p>
      ),
      FromCoin: from_adrs,
      ToCoin: to_adrs,
      Amount: amount,
      TranHash: (
        <div className="copyIcon">
          {tx_id}
          <ExportOutlined />
        </div>
      ),
    }

  })




  const data = [
    {
      key: "1",
      Date: "24/04/2024",
      FromCoin: "USDC (USDC)",
      ToCoin: "sa+fd",
      Amount: "45,455.8842",
      TranHash: (
        <div className="copyIcon">
          x833n......dnn487dnj
          <ExportOutlined />
        </div>
      ),
    },
  ];
  return (
    <div className="paymentRecords">
      <div className="commonCardBg">
        <div className="paymentRecords_top">
          <h2>Payment Records</h2>
          <Row gutter={[15, 15]}>
            <Col>
              <DropdownCustom
                buttonText="Type"
                menuItems={menuPropsType}
                className="action"
                handleMenuClick={handleTypeFilter}
                isOpen={isOpenType}
                setIsOpen={setIsOpenType}
              value={filterType}
              />
            </Col>
            <Col>
              <DropdownCustom
                buttonText="Status"
                menuItems={menuPropsStatus}
                className="action"
                handleMenuClick={handleStatusFilter}
                isOpen={isOpenStatus}
                setIsOpen={setIsOpenStatus}
              value={statusFilter}
              />
            </Col>
            <Col>
              <ButtonCustom
                regularBtn
                label="Download CSV"
                className="downloadcsv"
                onClick={handleDownloadCSV}
              />
            </Col>
          </Row>
        </div>
        <div>
          <Table columns={columns} dataSource={data1} />
        </div>
      </div>
    </div>
  );
}

export default SwapTable;
