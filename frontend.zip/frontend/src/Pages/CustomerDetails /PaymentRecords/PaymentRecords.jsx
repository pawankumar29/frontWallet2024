import React, { useEffect, useState } from "react";
import "./PaymentRecords.scss";
import { Col, Row, Table } from "antd";
import {
  ExportOutlined,
  FilterOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import ButtonCustom from "../../../Common/Components/ButtonCustom/ButtonCustom";
import DropdownCustom from "../../../Common/Components/DropdownCustom/DropdownCustom";
import {
  useGetUserTransactionMutation,
  useLazyGetUserDataQuery,
} from "../../../Utility/Services/UserDataListAPI";
import moment from "moment";
import { URL } from "../../../Constant copy/Constant";
import { useLocation } from "react-router-dom";

function PaymentRecords() {
  const location = useLocation();
  const { userData } = location.state;
  const limit = 10;
  const menuPropsType = ["all","deposit", "withdraw", "swap"];
  const menuPropsStatus = ["confirmed", "pending", "failed"];
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  // const [wallet_address, setWallet_address] = useState("");

  const [isOpenType, setIsOpenType] = useState(false);
  const [isOpenStatus, setIsOpenStatus] = useState(false);
  const [filter_type, setFilterType] = useState("");
  const [getUserData, { data: userList }] = useLazyGetUserDataQuery();
  // const [getUserData, { data: userList }] = useLazyGetUserDataQuery()

  const { wallet_address, user_id } = userData;
  const [getUserTransaction, { data: getTransaction }] =
    useGetUserTransactionMutation();

  useEffect(() => {
    if (user_id) {
      getUserData(user_id);
    }
  }, []);

  useEffect(() => {
    const fetchData = async () => {
     await tokenListData();
    };

    fetchData();
  }, [page, statusFilter, filter_type, userList]);

  const tokenListData = async () => {
    let walletAdd = [];
    let listing = userList?.data?.data;
    for (const user of listing) {
      walletAdd.push(user?.wallet_address);
    }

    let payload = {
      address_list: walletAdd,
      status: statusFilter,
      filter_type,
    };
    await getUserTransaction(payload);
  };

  // Function to handle filtering transactions by status
  const handleStatusFilter = (status) => {
    setStatusFilter(status);
    setIsOpenType(true);
    setPage(1);
  };
  // Function to handle filtering transactions by type
  const handleTypeFilter = (type) => {
    setFilterType(type);
    setPage(1);
  };
  //Download CSV
  const handleDownloadCSV = () => {
    // const response = `${URL.API_URL}users/exportCsv`;
    // window.open(response);
    // return;
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "Date",
      key: "Date",
    },
    {
      title: "Transaction Type",
      dataIndex: "TranType",
      key: "TranType",
    },
    {
      title: "Chain",
      dataIndex: "Chain",
      key: "Chain",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Token",
      dataIndex: "Token",
      key: "Token",
    },
    {
      title: "Wallet Address ",
      dataIndex: "address",
      key: "address",
    },
    {
      title: "Transaction Hash",
      dataIndex: "TranHash",
      key: "TranHash",
    },

    {
      title: "Price",
      key: "Price",
      dataIndex: "Price",
    },
    {
      title: "Amount",
      key: "Amount",
      dataIndex: "Amount",
    },
    {
      title: "Total Value",
      key: "Value",
      dataIndex: "Value",
    },
  ];

  const data = getTransaction?.data?.slice(0, 5)?.map((transaction) => {
    const {
      coin_id: key,
      amount,
      type,
      tx_id,
      from_adrs,
      fiat_type,
      created_at,
      coin_transation_data,
    } = transaction;

    const coinName = coin_transation_data?.coin_name;
    const price = amount * (coin_transation_data?.fiat_price_data?.value ?? 0);
    const total = price * amount;

    return {
      key: String(key),
      Date: moment(created_at).format("DD/MM/YYYY hh:mm A"),
      TranType: type,
      Chain: coinName,
      Token: fiat_type,
      address: from_adrs,
      Portfolio: "47.37%",
      TranHash: (
        <div className="copyIcon">
          {tx_id}
          <ExportOutlined />
        </div>
      ),
      Price: `$ ${price.toFixed(2)}`,
      Amount: amount,
      Value: `$ ${total.toFixed(5)}`,
    };
  });

  // const data1 = [
  //   {
  //     key: coin_id,
  //     Date: "23/04/2024",
  //     TranType: "Deposit",
  //     Chain: "BNB",
  //     Token: "USDC (USDC)",
  //     address: "djb2d5as4dasd2as1s54dasdda",
  //     Portfolio: "47.37%",
  //     TranHash: (
  //       <div className="copyIcon">
  //         x833n......dnn487dnj
  //         <ExportOutlined />
  //       </div>
  //     ),
  //     Price: "$0.9999316",
  //     Amount: "45,455.8842",
  //     Value: "$0.9999316",
  //   },
  // ];

  return (
    <div className="paymentRecords">
      <div className="commonCardBg">
        <div className="paymentRecords_top">
          <h2>Payment Records</h2>

          <Row gutter={[15, 15]}>
            <Col>
              <DropdownCustom
                buttonText="Type"
                menuItems={menuPropsType}
                className="action"
                handleMenuClick={handleTypeFilter}
                isOpen={isOpenType}
                setIsOpen={setIsOpenType}
                value={filter_type}
              />
            </Col>
            <Col>
              <DropdownCustom
                buttonText="Status"
                menuItems={menuPropsStatus}
                className="action"
                handleMenuClick={handleStatusFilter}
                isOpen={isOpenStatus}
                setIsOpen={setIsOpenStatus}
                value={statusFilter}
              />
            </Col>

            <Col>
              <ButtonCustom
                regularBtn
                label="Download CSV"
                className="downloadcsv"
                onClick={handleDownloadCSV}
              />
            </Col>
          </Row>
        </div>
        <div className="paymentRecords_table">
          <Table columns={columns} dataSource={data} />
        </div>
      </div>
    </div>
  );
}

export default PaymentRecords;
