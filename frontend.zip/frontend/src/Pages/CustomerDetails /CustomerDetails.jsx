import React, { useEffect, useState } from "react";
import "./CustomerDetails.scss";
import {

  CopyOutlined,
  DownOutlined,
} from "@ant-design/icons";
import SubCard from "../../Common/SubCard/SubCard";
import Accounts from "./Accounts/Accounts";
import DetailTabs from "./DetailTabs/DetailTabs";
import { useLocation } from "react-router-dom";
import { URL } from "../../Constant copy/Constant";
import { useLazyGetUserDataQuery } from "../../Utility/Services/UserDataListAPI";
import { toast } from "react-toastify";

function CustomerDetails() {
  const location = useLocation();
  console.log("this is the location at cutomer", location);
  const { userData } = location.state;
  const [isOpen, setIsOpen] = useState(false);
  const [balance, setBalance] = useState(null);
  const [walletAddress, setWalletAddress] = useState([])

  const [getUserData, { data: userList }] = useLazyGetUserDataQuery()
  // const { Panel } = Collapse;

  const { wallet_id, wallet_name, wallet_address, coin, user_id } = userData;

  useEffect(() => {
    console.log(userList?.data?.data, "======>>>>>>9999")
    if (user_id) {
      getUserData(user_id)
    }
  }, []);

  useEffect(() => {
    getTotalValue();

  }, [userList])

  const getTotalValue = () => {
    let totalValue = 0;

    // Iterate over each object in the data array
    userList?.data?.data?.forEach((item) => {
      console.log("ITEEEMMM", item);
      if (item?.coin?.fiat_price_data != null) {
        // Multiply balance with fiat value to get the total value for this object
        const itemValue = item?.balance * item?.coin?.fiat_price_data.value;
        console.log("ITEEEMMM", itemValue);

        // Add this object's total value to the overall total
        totalValue += itemValue;
      } else {
        // If fiat_price_data is null or undefined, just add balance directly
        totalValue += item?.balance;
      }
    });

    return totalValue;
  };

  const walletAddresses = [];
  userList?.data?.data?.forEach((balance) => {
    console.log(balance, "BALANCE-----")
    if (balance.coin_family === 1) {
      walletAddresses.push(balance.wallet_address);
    }
    if (balance.coin_family === 2) {
      walletAddresses.push(balance.wallet_address);
    }
    if (balance.coin_family === 6) {
      walletAddresses.push(balance.wallet_address);
    }
  });
  console.log(walletAddresses)

  const totalValue = getTotalValue().toFixed(3);


  const userDetails = [
    { label: "Account ID", value: wallet_id },
    { label: "Billing Email", value: "info@keenthemes.com" },
    {
      label: "Billing Address",
      value: "101 Collin Street, Melbourne 3000 VIC Australia",
    },
    { label: "Language", value: "English" },
    { label: "Upcoming Invoice", value: "54238-8693" },
    { label: "Tax ID", value: "TX-8674" },
  ];
  const data = [
    { earnings: `$ ${totalValue}`, description: "Wallet Balance" },
    { earnings: "130", description: "Total Refferals" },
    { earnings: "500", description: "Total Rewards Earned" },
  ];
  const items = [
    {
      key: "1",
      label: (
        <div className="detailHeader">
          <h3>
            Details
            <DownOutlined
              style={{
                transform: isOpen ? "rotate(180deg)" : "",
                transition: "0.3s all",
              }}
            />
          </h3>
        </div>
      ),
      children: (
        <div className="detailBody">
          <h5>Premium user</h5>
          {userDetails.map((detail, index) => (
            console.log(detail, "DDDDDD>"),
            <div key={index} className="detailBody_text">
              <h4>{detail.label}</h4>
              <p>{detail.value}</p>
            </div>
          ))}
        </div>
      ),
    },
  ];

  return (
    <div className="customerDetails">
      <div className="customerDetails_top">
        <div className="customerDetails_top_profile commonCardBg">
          <div className="customerDetails_top_profile_head">

            <div className="customerDetails_top_profile_head_top">
              <h2>Wallet Name :</h2>
              <h3>{wallet_name}</h3>
            </div>
            <div className="customerDetails_top_profile_head_bottom">
              <h2>Wallet Address :-</h2>

              <ul>
                {userList?.data?.data?.map((wallet, index) => {
                  if ((wallet?.coin_family === 1 || wallet?.coin_family === 2) && index === userList.data.data.findIndex((item) => (item.coin_family === 1 || item.coin_family === 2))) {
                    return (
                      <li key={wallet.wallet_address}>
                        <h3>ETH/BNB</h3>
                        <p>
                          <span>{wallet.wallet_address}</span> <CopyOutlined onClick={() => {
                            window.navigator.clipboard.writeText(wallet.wallet_address);
                            toast.success("Copied");
                          }} />
                        </p>
                      </li>
                    );
                  } else if (wallet?.coin_family === 6) {
                    return (
                      <li key={wallet.wallet_address}>
                        <h3>TRON</h3>
                        <p>
                          <span>{wallet.wallet_address}</span> <CopyOutlined onClick={() => {
                            window.navigator.clipboard.writeText(wallet.wallet_address);
                            toast.success("Copied");
                          }} />
                        </p>
                      </li>
                    );
                  }
                  else if (wallet?.coin_family === 3) {
                    return (
                      <li key={wallet.wallet_address}>
                        <h3>BTC</h3>
                        <p>
                          <span>{wallet.wallet_address}</span> <CopyOutlined onClick={() => {
                            window.navigator.clipboard.writeText(wallet.wallet_address);
                            toast.success("Copied");
                          }} />
                        </p>
                      </li>
                    );
                  }
                  return null;
                })}
              </ul>
            </div>
          </div>
          <div className="customerDetails_top_profile_earnings">
            {data?.map((item, index) => (
              <SubCard
                key={index}
                earnings={item.earnings}
                description={item.description}
                icon={item.icon}
              />
            ))}
          </div>
        </div>
        <div className="customerDetails_top_profile">
          <Accounts user_wallet_data={userList?.data?.data} />
        </div>
      </div>
      <div className="customerDetails_buttom">
        <div className="customerDetails_buttom_tabSec">
          <DetailTabs userList={userList?.data?.data ?? null} />
        </div>
      </div>
    </div>
  );
}

export default CustomerDetails;
