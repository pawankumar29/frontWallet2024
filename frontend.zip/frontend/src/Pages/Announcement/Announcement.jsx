import React, { useState } from "react";
import "./Announcement.scss";
import { DatePicker, Table, Tag } from "antd";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import TextArea from "../../Common/Components/TextArea/TextArea";
import { HistoryOutlined } from "@ant-design/icons";
import CustomDatePicker from "../../Common/Components/CustomDatePicker/CustomDatePicker";

function Announcement() {
  const [selectionType, setSelectionType] = useState("checkbox");

  const columns = [
    {
      title: "S.No",
      dataIndex: "SNo",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Wallet Name",
      dataIndex: "WalletName",
    },
    {
      title: "MultichainPortfolio ",
      dataIndex: "MultichainPortfolio",
    },
    {
      title: "Code",
      dataIndex: "Code",
    },
    {
      title: "Date",
      dataIndex: "Date",
    },
  ];

  const data = [
    {
      key: "1",
      SNo: 1,
      WalletName: "Wallet",
      MultichainPortfolio: "$3,690.564546444",
      Code: "ABCD",
      Date: "01-04-2024 11:25:45 AM",
    },
    {
      key: "1",
      SNo: 2,
      WalletName: "Wallet",
      MultichainPortfolio: "$3,690.564546444",
      Code: "ABCD",
      Date: "01-04-2024 11:25:45 AM",
    },
  ];
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      console.log(
        `selectedRowKeys: ${selectedRowKeys}`,
        "selectedRows: ",
        selectedRows
      );

      setSelectedUsers(selectedRows);
    },
  };
  return (
    <div className="announcement">
      <div className="announcement_top commonCardBg">
        <InputCustom regularInput placeholder="Title" />
        <TextArea placeholder="Messages" />
        <ButtonCustom
          label="Send To All"
          regularBtn
          className="announcement_top_sendBtn"
        />
      </div>
      <div className="commonCardBg">
        <div className="announcement_filters">
          <div className="announcement_filters_left">
            <InputCustom searchInputs placeholder="Search User" />
            <CustomDatePicker picker="week" placeholder="DD/MM/YYYY" />
            <CustomDatePicker picker="week" placeholder="DD/MM/YYYY" />
          </div>
          <div className="announcement_filters_right">
            <ButtonCustom label="Filter" regularBtn />
            <ButtonCustom label="Reset" regularBtn />
          </div>
        </div>
        <div className="announcement_tablehistory">
          <p> <HistoryOutlined /> History</p>
        </div>
        <Table
          rowSelection={{
            type: selectionType,
            ...rowSelection,
          }}
          columns={columns}
          dataSource={data}
        />
      </div>
    </div>
  );
}

export default Announcement;
