import React from "react";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import "./Login.scss";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import { forgetPasswordSchema } from "../../Constant/Validations/Validation";
import { useNavigate } from "react-router-dom";

function ForgetPassword() {
  // const [loginUser, { isLoading }] = useLoginUserMutation();
  const navigate = useNavigate();
  const {
    control,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(forgetPasswordSchema),
    defaultValues: { email: "", name: "" },
  });

  const onSubmit = (data) => {
    // loginUser(data);
    // navigate("/login");
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="forgetPassword login">
        <Controller
          control={control}
          rules={{
            required: true,
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <InputCustom
              label
              labletext="Name"
              placeholder="Enter Your Name"
              type="text"
              regularInput
              value={getValues("name")}
              onChange={(e) => {
                setValue("name", e.target.value);
              }}
            />
          )}
          name="name"
        />
        {errors.name && <p className="errorMessage">{errors.name.message}</p>}

        <Controller
          control={control}
          rules={{
            required: true,
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <InputCustom
              label
              labletext="Email"
              placeholder="Enter Email"
              type="text"
              regularInput
              value={getValues("email")}
              onChange={(e) => {
                setValue("email", e.target.value);
              }}
            />
          )}
          name="email"
        />
        {errors.email && <p className="errorMessage">{errors.email.message}</p>}

        <div className="forgetPassword_button">
          <ButtonCustom label="Submit Request" regularBtn />
        </div>
      </div>
    </form>
  );
}

export default ForgetPassword;
