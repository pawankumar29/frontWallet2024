import React from "react";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import "./Login.scss";
import { Link, useNavigate } from "react-router-dom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import { Path } from "../../Routing/Constant/RoutePaths";
import { loginSchema } from "../../Constant/Validations/Validation";
import { useLoginUserMutation } from "../../Utility/Services/UserLoginAPI";
// import LineChart from "./graph";

function Login() {
  const [loginUser, { isLoading }] = useLoginUserMutation();
  const navigate = useNavigate();
  const {
    control,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const onSubmit = (data) => {
    console.log(data,"DATA")
    loginUser(data);
    localStorage.setItem("isLogged", "dksjhfkjsdhfdks");
    navigate("/dashboard");
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="login">
        <Controller
          control={control}
          rules={{
            required: true,
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <InputCustom
              label
              labletext="Email"
              placeholder="john.wick007@gmail.com"
              type="text"
              regularInput
              value={getValues("email")}
              onChange={(e) => {
                setValue("email", e.target.value);
              }}
            />
          )}
          name="email"
        />
        {errors.email && <p className="errorMessage">{errors.email.message}</p>}

        <Controller
          control={control}
          rules={{
            required: true,
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <InputCustom
              label
              labletext="Password"
              placeholder="*******"
              id="password"
              passwordInput
              tabIndex={2}
              value={getValues("password")}
              onChange={(e) => {
                setValue("password", e.target.value);
              }}
            />
          )}
          name="password"
        />
        {errors.password && (
          <p className="errorMessage">{errors.password.message}</p>
        )}

        <div className="login_forget">
          <Link to={Path.FORGOTPASSWORD}>Forgot Password ?</Link>
        </div>
        <div className="login_button">
          <ButtonCustom type={"submit"} label="Continue" regularBtn />
        </div>
      </div>
      <div className="chart_lineee">{/* <LineChart /> */}</div>
    </form>
  );
}

export default Login;
