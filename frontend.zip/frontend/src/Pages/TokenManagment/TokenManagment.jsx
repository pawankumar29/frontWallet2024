import React, { useEffect, useState } from "react";
import { Modal, Spin, Table } from "antd";
import InputCustom from "../../Common/Components/InputCustom/InputCustom";
import ButtonCustom from "../../Common/Components/ButtonCustom/ButtonCustom";
import { DeleteFilled, PlusOutlined } from "@ant-design/icons";
import "./TokenManagment.scss";
import DropdownCustom from "../../Common/Components/DropdownCustom/DropdownCustom";
import {
  useAddNewTokenMutation,
  useLazyDeleteTokenQuery,
  useLazyGetTokenListQuery,
  useTokenSearchMutation,
} from "../../Utility/Services/TokenManagmentAPI";
import moment from "moment";
import { useAddTokenMutation } from "../../Utility/Services/AddTokenAPI";
import { converToQueryParams } from "../../Common/functions/comman";
import { toast } from "react-toastify";
import _debounce from "lodash/debounce"; // Import debounce function
import { CopyOutlined } from "@ant-design/icons";

const menuData = [
  {
    value: 1,
    displayValue: "BNB",
  },
  {
    value: 2,
    displayValue: "ETH",
  },
  {
    value: 6,
    displayValue: "TRX",
  },
];
// const menuPropsType = [
//   {
//     value: 1,
//     displayValue: "ETH (ERC20)",
//   },
//   {
//     value: 2,
//     displayValue: "BSC(BEP20)",
//   },
//   {
//     value: 6,
//     displayValue: "TRON (TRC20)",
//   },
// ];
const menuPropsType = ["ERC20", "TRC20", "BEP20"];

const limit = 10;

function TokenManagment() {
  const [search, setSearch] = useState("");
  const [visible, setVisible] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [isOpenType, setIsOpenType] = useState(false);
  const [isOpenFilter, setIsOpenFilter] = useState(false);
  const [selectChain, setSelectChain] = useState("");
  const [selectChainLabel, setSelectChainLabel] = useState("");
  const [page, setPage] = useState("");
  const [type, setType] = useState("");
  const [tokenAddress, setTokenAddress] = useState("");
  const [tokenName, setTokenName] = useState("");
  const [decimal, setDecimal] = useState("");
  const [symbol, setSymbol] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [selectMenu, setSelectMenu] = useState("");
  // const [selectChainLabel, setSelectChainLabel] = useState("");

  // const { addtoken } = useAddTokenMutation();
  const [getTokenList, { data: token, isLoading }] = useLazyGetTokenListQuery();
  const [tokenSearch, { data: searchedToken }] = useTokenSearchMutation();
  const [addNewToken, { isLoading: addNewLoading }] = useAddNewTokenMutation();
  const [deleteToken, { isLoading: deleteLoading }] = useLazyDeleteTokenQuery();

  const showModal = () => {
    setVisible(true);
  };
  const modalOpen = (coin_id) => {
    setDeleteModal(true);
    setDeleteId(coin_id);
    // setDeleteItem(token);
  };

  useEffect(() => {
    tokenListData();
  }, [search, type]);

  const handleTypeFilter = (type) => {
    setType(type);
    setPage(1);
  };
  const handleSearch = (searchValue) => {
    const trimmedSearchValue = searchValue.trim();
    setSearch(trimmedSearchValue);
    setPage(1);
    tokenListData();
  };

  // Debounce the handleSearch function
  const debouncedSearch = _debounce(handleSearch, 500);
  const handleDeleteConfirmation = async (coin_id) => {
    console.log(coin_id, "IDDDDDD");
    try {
      await deleteToken(coin_id);
      setDeleteConfirm(false);
      tokenListData(); // Refresh token list after deletion
      // setDeleteItem(null);
      setDeleteModal(false); // Close the delete modal
      // toast.success("Token deleted successfully.");
    } catch (error) {
      console.error("Error deleting token:", error);
      toast.error("Failed to delete token. Please try again later.");
    }
  };

  const handleOk = () => {
    setVisible(false);
    setDeleteModal(false);
  };

  const handleCancel = () => {
    setVisible(false);
    setDeleteModal(false);
  };

  const tokenListData = async () => {
    let payload = {
      searchBy: search,
      token_type: type,
    };
    let params = converToQueryParams(payload);
    getTokenList(params);
  };

  const handleClick = (e) => {
    console.log("EEEE", e);
    setSelectChain(e.value);
    setSelectChainLabel(e.displayValue);
    setTokenName(""); // Clear token name when chain changes
  };

  const handleContractAddressChange = (e) => {
    setTokenAddress(e.target.value);
  };

  const handleSubmit = async () => {
    try {
      // Perform form validation
      if (!selectChain) {
        toast.error("Please select a network.");
        return;
      }

      if (!tokenAddress) {
        toast.error("Please enter a contract address.");
        return;
      }

      if (!symbol) {
        toast.error("Please enter the symbol.");
        return;
      }

      if (!decimal || isNaN(decimal)) {
        toast.error("Please enter a valid number for decimals.");
        return;
      }

      // Proceed with submitting the form if validation passes
      const tokenType =
        selectChain === 1 ? "BEP20" : selectChain === 2 ? "ERC20" : "TRC20";

      const tokenData = {
        coin_family: selectChain,
        token_address: tokenAddress,
        name: tokenName,
        symbol,
        decimals: decimal,
        token_type: tokenType,
      };

      // Call the mutation function to add the new token
      const response = await addNewToken(tokenData);
      console.log(response, "RES");
      // Extract the message from the response
      const message = response?.data?.message;

      console.log(message, "MES");

      // Close the modal after submission
      setVisible(false);

      toast.success(message);
    } catch (error) {
      // Handle error if submission fails
      console.error("Error adding token:", error);
    }
  };

  // useEffect(() => {
  // Check if both selectChain and tokenAddress have valid values

  useEffect(() => {
    // Check if both selectChain and tokenAddress have valid values
    if (selectChain && tokenAddress) {
      tokenSearch({ coinFamily: selectChain, tokenAddress })
        .then((response) => {
          // Update token name based on response
          setTokenName(response?.data?.data?.name);
          setDecimal(response?.data?.data?.decimals);
          setSymbol(response?.data?.data?.symbol);

          // Call handleSubmit after retrieving token information
          // handleSubmit();
        })
        .catch((error) => {
          // Handle error
          console.error("Error searching token:", error);
        });
    }
  }, [selectChain, tokenAddress, tokenSearch]);

  // const handleSearch = (searchValue) => {
  //   const trimmedSearchValue = searchValue.trim();
  //   setSearch(trimmedSearchValue);
  //   setPage(1);
  //   tokenListData();
  // };

  const columns = [
    {
      title: "Token",
      dataIndex: "Token",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Token Contract Address",
      dataIndex: "ContractAddress",
    },
    {
      title: "Token Network",
      dataIndex: "TokenType",
    },
    {
      title: "Date",
      dataIndex: "Date",
    },
    {
      title: "Action",
      dataIndex: "Action",
    },
  ];

  const data = token?.data?.map((token) => {
    const {
      coin_id: key,
      coin_image,
      coin_name,
      coin_symbol,
      token_address,
      token_type,
      updated_at,
      createdAt,
    } = token;
    console.log("TOKEN", token);
    const contractAddress = token_address
      ? `${token_address.substring(0, 6)}...${token_address.substring(
          token_address.length - 6
        )}`
      : "N/A";

    return {
      key: String(key),
      Token: (
        <div className="tableUserProfile">
          <img src={coin_image} alt={coin_name} />
          <p>
            {coin_name} ({coin_symbol.toUpperCase()})
          </p>
        </div>
      ),
      ContractAddress: contractAddress || "N/A",

      TokenType: token_type || "N/A",
      Date: <p>{moment(updated_at).format("DD/MM/YYYY hh:mm A")}</p>,
      Action: (
        <div className="delteBtn">
          <DeleteFilled onClick={() => modalOpen(token?.coin_id)} />
        </div>
      ),
    };
  });

  return (
    <div className="userList">
      <div className="commonCardBg">
        <div className="userList_top">
          <InputCustom
            searchInputs
            placeholder="Search Token"
            onChange={debouncedSearch}
          />

          <div className="userList_top_btn">
            <DropdownCustom
              buttonText="Token Type"
              menuItems={menuPropsType}
              className="action"
              handleMenuClick={handleTypeFilter}
              isOpen={isOpenType}
              setIsOpen={setIsOpenType}
              value={type}
            />
            <ButtonCustom
              icon={<PlusOutlined />}
              label="Add New"
              regularBtn
              onClick={showModal}
            />
          </div>
        </div>

        {/* <Spin spinning={isLoading}> */}
        <Table columns={columns} dataSource={data} />
        {/* </Spin> */}
      </div>
      <div>
        <Modal
          title="Add Custom Token"
          visible={visible}
          onOk={handleOk}
          onCancel={handleCancel}
          centered
        >
          <div className="tokenModal">
            <DropdownCustom
              buttonText="Select Network"
              menuItems={menuData}
              className="action"
              handleMenuClick={handleClick}
              isOpen={isOpenFilter}
              setIsOpen={setIsOpenFilter}
              value={selectChainLabel}
            />
            <InputCustom
              label
              labletext="Contract Address"
              regularInput
              placeholder="Contract Address"
              onChange={handleContractAddressChange}
            />
            <InputCustom
              label
              labletext="Token Name"
              regularInput
              placeholder="Token Name"
              value={tokenName} // Display token name
              disabled // Disable editing
            />
            <div className="tokenModal_symbol">
              <InputCustom
                label
                labletext="Symbol"
                regularInput
                placeholder="Symbol"
                value={symbol} // Display token name
                disabled
              />
              <InputCustom
                label
                labletext="Decimals"
                regularInput
                placeholder="Decimals"
                value={decimal} // Display token name
                disabled
              />
            </div>
            <ButtonCustom
              label="Done"
              regularBtn
              className="announcement_top_sendBtn"
              onClick={handleSubmit}
            />
          </div>
        </Modal>
        <Modal
          visible={deleteModal}
          onOk={() => handleDeleteConfirmation(deleteId)}
          onCancel={handleCancel}
          centered
        >
          <div className="deletModal">
            <h4>Do you want to Delete token?</h4>
            <div className="deletModal_btn">
              <ButtonCustom
                label="Yes"
                regularBtn
                onClick={() => handleDeleteConfirmation(deleteId)}
              />
              <ButtonCustom
                label="No"
                regularBtn
                className="deletModal_btn_no"
                onClick={handleCancel}
              />
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
}
export default TokenManagment;
