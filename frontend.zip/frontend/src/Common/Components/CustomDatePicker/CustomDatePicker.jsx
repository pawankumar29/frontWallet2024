import React from 'react'
import "./CustomDatePicker.scss"
import { DatePicker } from 'antd'

function CustomDatePicker({picker,placeholder}) {
  return (
    <div className='commonDatepicker'>
        <DatePicker picker={picker} placeholder={placeholder} />
    </div>
  )
}

export default CustomDatePicker