import { useState } from "react";
import "./InputCustom.scss";
import VisibilityOff from "../../../assets/VisibilityOff.svg";
import VisibilityOn from "../../../assets/VisibilityOn.svg";
import { SearchIcon } from "../../../assets/StoreAsset/StoreAsset";
import { SearchOutlined } from "@ant-design/icons";

function InputCustom(props) {
  const {
    label,
    labletext,
    placeholder,
    type,
    error,
    regularInput,
    passwordInput,
    id,
    name,
    onChange,
    value,
    customClass,
    searchInputs,
    tabIndex,
    onBlur,
    disabled,
    required = false,
  } = props;
  const [types, setTypes] = useState(false);
  const [searchValue, setSearchValue] = useState("");

  const handleInputChange = (e) => {
    setSearchValue(e.target.value); // Update the local state
    if (onChange) {
      onChange(e.target.value); // Call the onChange function from props
    }
  };

  return (
    <div
      className={`customInput ${passwordInput ? "customInput-password" : ""
        } ${customClass} ${error ? "customInput-inputError" : ""}`}
    >
      {label && (
        <label>
          {labletext}
          {required && <span> *</span>}
        </label>
      )}
      {regularInput && (
        <input
          placeholder={placeholder}
          type={type}
          id={id}
          name={name}
          onChange={onChange}
          value={value}
          tabIndex={tabIndex}
          onBlur={onBlur}
          disabled={disabled}
        />
      )}
      {passwordInput && (
        <div className="customInput-password_wrapper">
          <input
            placeholder={placeholder}
            type={types ? "text" : "password"}
            id={id}
            name={name}
            onChange={onChange}
            value={value}
            tabIndex={tabIndex}
            onBlur={onBlur}
          />
          <button onClick={() => setTypes(!types)} type="button">
            {types ? (
              <img
                src={VisibilityOn}
                alt="VisibilityOff"
                width={24}
                height={24}
              />
            ) : (
              <img
                src={VisibilityOff}
                alt="VisibilityOn"
                width={24}
                height={24}
              />
            )}
          </button>
        </div>
      )}
      {error && <p>{error}</p>}
      {searchInputs && (
        <div className="search-input-wrapper">
          <input
            type="text"
            placeholder={placeholder}
            value={searchValue}
            onChange={handleInputChange}
          />
          <button type="button" className="search-button">
            <SearchOutlined />
          </button>
        </div>
      )}
    </div>
  );
}

export default InputCustom;
