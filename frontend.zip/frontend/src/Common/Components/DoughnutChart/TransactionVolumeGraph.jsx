import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import { BlueMonth, GreenMonth, RedMonth } from "../../svg/svg";
import { useLazyGetTransactionCountsQuery } from "../../../Utility/Services/SwapTransactionAPI";
import { Select } from "antd";
const TransactionVolumeGraph = () => {

    const intialLable = ["1", "2", "3", "4", '5', "6", "7", "8", "9", '10']
    const [graphDataV2, setGraphDataV2] = useState({ day: [], week: [], month: [] })

    const [transactionFilter, setTransactionFilter] = useState("1w");
    const [graphData, setGraphData] = useState({
        labels: intialLable,
        datasets: []
    });
    const [getTransactionCounts, { data: transaction, isLoading, error }] = useLazyGetTransactionCountsQuery();
    console.log(transaction, "TRANSACTION")

    useEffect(() => { getTransactionCounts() }, [])
    // const getCount = () => {
    //     let payload = "";
    //     if (active[0] == "1 Day") {
    //         payload = "1d";
    //     }
    //     if (active[0] == "1 Week") {
    //         payload = "1w";
    //     }
    //     if (active[0] == "1 Month") {
    //         payload = "1m";
    //     }
    //     getTransactionCounts(payload);
    // };
    const options = [
        { value: 'all', label: 'All data' },
        { value: '1d', label: '1D (24 hours)' },
        { value: '1w', label: '1 Week (7 days)' },
        { value: '1m', label: '1 Month (30 days)' },
    ];

    useEffect(() => {
        console.log("transactionFilter", transactionFilter);
        if (transactionFilter) {
            let data = { ...graphData }
            // setTransactionFilter(options[0])
            if (transactionFilter === 'daily') {
                data.labels = [1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
                setGraphData(data)
            } else if (transactionFilter === 'weekly') {
                data.labels = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']
                setGraphData(data)
            }
            else if (transactionFilter === 'monthly') {
                data.labels = ['1', '7', '14', '22', '28', '31']
                setGraphData(data)
            }
            else {
                data.labels = intialLable
                setGraphData(data)
            }
        }
    }, [transactionFilter]);




    useEffect(() => {
        if (transaction) {
            console.log("ddddddddddd", transaction)
            const arr = [];
            const arr2 = [];
            const arr3 = [];
            transaction?.dataForOneDay?.map((item) => {
                arr.push(item.total_amount)
            })

            transaction?.dataForOneWeek?.map((item) => {
                arr2.push(item.total_amount)
            })

            transaction?.dataForOneMonth?.map((item) => {
                arr3.push(item.total_amount)
            })



            const data_ = { ...graphData }
            data_.datasets = [{
                label: "Transaction",
                data: arr,
                fill: true,
                borderColor: "rgb(75, 192, 192)",
                backgroundColor: "rgba(75, 130, 130, 0.2)",
                tension: 0.1,
            },
            {
                label: "Transaction",
                data: arr2,
                fill: true,
                borderColor: "rgb(255, 99, 132)",
                backgroundColor: "rgba(86,71,97, 0.2)",
                tension: 0.1,
            },
            {
                label: 'Transaction',
                data: arr3,
                fill: true,
                borderColor: 'rgb(7,224,152)',
                backgroundColor: 'rgba(86,71,97, 0.2)',
                tension: 0.1,
            },
            ]
            if (transactionFilter === 'daily') {
                const d = { ...data_ };
                d.datasets = [data_.datasets[0]]; // Keep only the first dataset
                setGraphData(d);
            } else if (transactionFilter === 'weekly') {
                const d = { ...data_ };
                d.datasets = [data_.datasets[1]]; // Keep only the first dataset
                setGraphData(d);
            }
            else if (transactionFilter === 'monthly') {
                const d = { ...data_ };
                d.datasets = [data_.datasets[2]]; // Keep only the first dataset
                setGraphData(d);
            }
            else {
                setGraphData(data_)

                // setGraphData(data)
                // setGraphData(data_)
            }
            // setGraphDataV2({ day: arr, week: arr2, month: arr3 })
            console.log("arr", arr)
        }
    }, [transaction, transactionFilter]);





    console.log(transaction, "transaction")
    const data = {
        labels: ["1", "2", "3", "4", '5', "6", "7", "8", "9", '10'],
        datasets: [
            {
                label: "Sales Data 1",
                data: [11, 43, 80, 81, 56, 55, 40],
                fill: true,
                borderColor: "rgb(75, 192, 192)",
                backgroundColor: "rgba(75, 130, 130, 0.2)",
                tension: 0.1,
            },
            {
                label: "Sales Data 2",
                data: [100, 59, 33, 44, 55, 66, 77],
                fill: true,
                borderColor: "rgb(255, 99, 132)",
                backgroundColor: "rgba(86,71,97, 0.2)",
                tension: 0.1,
            },
            {
                label: 'Sales Data 2',
                data: [35, 43, 63, 55, 75, 88, 100],
                fill: true,
                borderColor: 'rgb(7,224,152)',
                backgroundColor: 'rgba(86,71,97, 0.2)',
                tension: 0.1,
            },
        ],
    };

    const chartOptions = {
        plugins: {
            legend: {
                display: false,
            },
            scales: {
                xAxes: {
                    type: 'time',
                    // position: 'bottom',
                    time: {
                        displayFormats: { 'day': 'MM/YY' },
                        tooltipFormat: 'DD/MM/YY',
                        unit: 'month',
                    }
                },
            }
        },
    };

    const dataItems = [
        { text: "Last Day(24H)", amount: "$3,004", img: <BlueMonth /> },
        { text: "This Week(7D)", amount: "$4,102", img: <GreenMonth /> },
        { text: "This Month(30D)", amount: "$5,209", img: <RedMonth /> },
    ];
    return (
        <>
            <div className="transGraph">
                <div className="userReg__head">
                    <h4 className="commonHead">Transaction Volume</h4>
                    <div className="monthitems">
                        {dataItems.map((item, index) => (
                            <div className="iconItems" key={index}>
                                {item.img}
                                <p>
                                    <span>{item.text}</span>
                                    {item.amount}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
                <Line data={graphData} options={chartOptions} />
            </div>
            <div className='userReg__head'>
                <h4 className='commonHead'>User Registration</h4>
                <Select
                    value={transactionFilter}
                    onChange={(e) => setTransactionFilter(e)}
                    // menuIsOpen={true}
                    options={options}
                />
            </div>
        </>
    );
};

export default TransactionVolumeGraph;
