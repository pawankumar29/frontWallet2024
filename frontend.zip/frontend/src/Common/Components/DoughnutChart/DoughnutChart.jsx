import React, { useRef, useEffect } from 'react';
import Chart from 'chart.js/auto';
import "./DoughnutChart.scss"

const DoughnutChart = () => {
  const chartRef = useRef(null);
  let myChart;

  useEffect(() => {
    if (chartRef && chartRef.current) {
      myChart = new Chart(chartRef.current, {
        type: 'doughnut',
        data: {
          labels: [   'New Users', 'Existing User',],
          datasets: [{
            label: '# of Votes',
            data: [12, 19],
            backgroundColor: [
              '#FFFFFF              ',
              '#008db4              ',           
            ],
            
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'right',
            },
            title: {
              display: true,
            }
          }
        }
      });
    }

    return () => {
      if (myChart) {
        myChart.destroy();
      }
    };
  }, []);

  return (
    <div className='pieChart'>
      <canvas ref={chartRef} width="200" height="200"></canvas>
    </div>
  );
};

export default DoughnutChart;
