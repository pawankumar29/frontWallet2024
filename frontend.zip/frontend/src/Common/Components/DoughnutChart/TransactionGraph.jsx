import React, { useRef, useEffect, useState } from 'react';
import Chart from 'chart.js/auto';
import { Select } from 'antd';
// import { useGetRegisterUserCountsQuery } from '../../Redux/services/dashboardApi';
import { useLazyGetTransactionCountsQuery } from "../../../Utility/Services/SwapTransactionAPI";

const TransactionGraph = () => {
    const [timeLine, setTimeLine] = useState(["All"]);
    const [active, setActive] = useState(["All"]);
    const [graphData, setGraphData] = useState({
        // label: ['02:30','02:40','06:50','10:40','11:30'],
        // value: [11,22,33,44,5],
        label: [],
        value: []
    });
    const options = [
        { value: '1d', label: '1D (24 hours)' },
        { value: '1w', label: '1 Week (7 days)' },
        { value: '1m', label: '1 Month (30 days)' },
    ];
    const [userRegisterFilter, setUserRegisterFilter] = useState('1d');

    const [getTransactionCounts, { data, isLoading, error }] = useLazyGetTransactionCountsQuery();

    console.log(data,"^^^^^mmmm")
    useEffect(() => {
        getCount();
    }, [active]);
    const getCount = () => {
        let payload = "";
        if (active[0] == "1 Day") {
            payload = "1d";
        }
        if (active[0] == "1 Week") {
            payload = "1w";
        }
        if (active[0] == "1 Month") {
            payload = "1m";
        }
        getTransactionCounts(payload);
    };
    useEffect(() => {
        const labels = [];
        const values = [];
        data?.forEach((item) => {
            labels.push(item.label);
            values.push(item.user_count);
        });
        setGraphData({ label: labels, value: values });
    }, [data]);

    const chartRef = useRef(null);
    let chartInstance = useRef(null);

    useEffect(() => {
        if (chartRef && chartRef.current && graphData.label.length > 0) {
            if (chartInstance.current) {
                chartInstance.current.destroy(); // Destroy existing chart before creating a new one
            }

            chartInstance.current = new Chart(chartRef.current, {
                type: 'bar',
                data: {
                    labels: graphData.label,
                    datasets: [
                        {
                            data: graphData.value,
                            backgroundColor: 'rgb(0,149,255)',
                            borderColor: 'rgb(0,149,255)',
                            barThickness: 30,
                        },
                    ],
                },
                options: {
                    plugins: {
                        legend: {
                            display: false,
                        },
                    },
                },
            });
        }

        return () => {
            // Clean up by destroying the chart instance when the component unmounts
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }
        };
    }, [graphData]);

    return (
        <>
            <div className='userReg__head'>
                <h4 className='commonHead'>Transactions</h4>
                <Select
                    value={userRegisterFilter}
                    onChange={(e) => setUserRegisterFilter(e)}
                    menuIsOpen={true}
                    options={options}
                />
            </div>
            <canvas ref={chartRef} />
        </>
    );
};

export default TransactionGraph;
