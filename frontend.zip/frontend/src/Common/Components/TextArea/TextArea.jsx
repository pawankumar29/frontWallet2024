import React from 'react'
import "./TextArea.scss"

function TextArea({placeholder}) {
  return (
    <div className="CommonTextArea">
        <textarea  id="" cols="30" rows="5" placeholder={placeholder}></textarea>
    </div>
  )
}

export default TextArea