import { Spin, Table, Tag } from "antd";
import React, { useEffect } from "react";
import swap from "../../../assets/swap.png";
import sent from "../../../assets/send.png";
import recieve from "../../../assets/receive.png";
import btc from "../../../assets/Bitcoin.png";
import { useGetLatestTransactionMutation } from "../../../Utility/Services/TransactionsAPI";
import moment from "moment";
import { formatNumber } from "../../functions/comman";

function RecentTransactions() {
  const [getLatestTransaction, { data, isLoading }] =
    useGetLatestTransactionMutation();

  useEffect(() => {
    latestTransaction();
  }, []);
  const latestTransaction = async () => {
    let data = await getLatestTransaction({
      limit: 5, orderBy: "descending",
    });
    console.log(data, "++++++++DATA")
  };

  const columns = [
    {
      title: "Type",
      dataIndex: "type",
      render: (text, record) => (
        <div className="tableUserProfile">
          {["deposit", "withdraw", "Swap"].includes(text) && (
            console.log(text, "TEXT"),
            <img
              src={
                text === "deposit" ? recieve : text === "withdraw" ? sent : swap
              }
              alt=""
            />
          )}
          <p style={{ textTransform: "capitalize" }}>
            <span> {text} <br />{moment(record?.updated_at).format("DD/MM/YYYY hh:mm A")}</span>
          </p>
        </div>
      ),
    },
    {
      title: "Wallet Address",
      dataIndex: "",
      render: (text, record) => (
        <p>{record?.type === "deposit" ? record?.from_adrs : record?.to_adrs}</p>
      ),
    },
    {
      title: "Amount",
      dataIndex: "amount",
      render: (text, record) => (
        <p>
          {record?.coin_transation_data?.coin_image ? (
            <img
              style={{ height: 20, borderRadius: 50 }}
              src={record?.coin_transation_data?.coin_image}
              alt="Coin"
            />
          ) :
            ""}

          {formatNumber(text, 4)}
          <span className="coin_symbol">
            {" "}
            {record?.coin_transation_data?.coin_symbol}
          </span>{" "}
          <br />
          <span>
            ≈${" "}
            {formatNumber(
              text *
              record?.coin_transation_data?.fiat_price_data?.value,
              2
            )}{" "}
            {/* {moment(record?.updated_at).format("MM/DD/YYYY hh:mm A")} */}
          </span>
        </p>
      ),
    },
  ];


  return (
    <Spin spinning={isLoading}>
      <div>
        {" "}
        <h2>Payment Records</h2>
        <Table
          pagination={false}
          scroll={{ x: 400 }}
          columns={columns}
          dataSource={data?.data}
        />
      </div>
    </Spin>
  );
}

export default RecentTransactions;
