import React from "react";
import "./SidebarDashboard.scss";
import {
  CloseOutlined,
  LogoutOutlined,
  SettingOutlined,
  SoundOutlined,
} from "@ant-design/icons";
import Logo from "../../assets/HeaderLogo.png";
import HeaderMenu from "../Header/HeaderMenu";
import { Path } from "../../Routing/Constant/RoutePaths";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { loginUserState, logoutState } from "../../Utility/Slices/user.slice";
import Toaster from "../Toast/Toast";

function SidebarDashboard() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  return (
    <div className="sideBar">
      <div className="sideBar_onRight">
        <div>
          {" "}
          <div className="sideBar_closeIcon">
            <CloseOutlined />
          </div>
          <div className="sideBar_logo">
            <img src={Logo} alt="" />
          </div>
          <div className="sideBar_menuItem">
            <div className="sideBar_menuItem_top">
              <h3>
                <Link to={Path.ANNOUNCEMENT}>
                  <SoundOutlined /> Announcement
                </Link>
              </h3>
              <h3>
                <Link to={Path.SETTING}>
                  {" "}
                  <SettingOutlined /> Settings / Admin Controls
                </Link>
              </h3>
            </div>
            <HeaderMenu className="displayShow" />
          </div>
        </div>
        <div className="sideBar_onRight_logout">
          <span
            onClick={() => {
              dispatch(loginUserState(null));
              Toaster(true, "Logout successfully.");
            }}
          >
            <LogoutOutlined /> Logout
          </span>
        </div>
      </div>
    </div>
  );
}

export default SidebarDashboard;
