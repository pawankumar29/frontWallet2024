import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./App.scss";
import routes from "./Routing/Routes.jsx";
import { useEffect } from "react";

function App() {
  useEffect(() => {
    localStorage.setItem("isLogged", "");
  }, []);

  const router = createBrowserRouter([
    {
      path: "/",
      children: routes,
      // errorElement: <ErrorBoundary />,
    },
  ]);

  return (
    <>
      <ToastContainer />
      <RouterProvider router={router} />
    </>
  );
}

export default App;
