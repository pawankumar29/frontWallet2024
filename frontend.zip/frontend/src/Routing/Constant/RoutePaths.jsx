// Routing paths
const Path = {
  LOGIN: "/",
  FORGOTPASSWORD: "/fogetPassword",
  DASHBOARD: "/dashboard",
  CUSTOMERDETAILS: "/customerDetail",
  USERLIST: "/userList",
  TRANSHISTORY: "/transactionHistory",
  TOKENMANAGMENT: "/tokenManagment",
  REFERRALLIST: "/referralList",
  REWARDCONTROLS: "/rewardControls",
  ANNOUNCEMENT: "/announcement",
  SETTING: "/Settings"
};

export { Path };
