import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { loginUserState } from "../Slices/user.slice";
import { handleResponse, headerConfig } from "../../Common/functions/comman";
import { URL } from "../../Constant copy/Constant";

export const loginAPI = createApi({
  reducerPath: "login",
  baseQuery: fetchBaseQuery({
    baseUrl: URL.API_URL,
    prepareHeaders: (headers, { getState }) => {
      return headerConfig(headers, getState);
    },
  }),
  endpoints: (builder) => ({
    loginUser: builder.mutation({
      query: (payload) => ({
        url: "auth/login",
        method: "POST",
        body: payload,
      }),
      async onQueryStarted({}, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          console.log("log resp:: ", data);
          const resp = data?.data;
          dispatch(loginUserState(resp));

          handleResponse(true, data, dispatch);
        } catch (error) {
          handleResponse(true, error.error, dispatch);
        }
      },
    }),
  }),
});

export const { useLoginUserMutation } = loginAPI;
