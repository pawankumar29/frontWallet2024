import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { handleResponse, headerConfig } from "../../Common/functions/comman";
import { URL } from "../../Constant copy/Constant";

export const userListAPI = createApi({
  reducerPath: "userList",
  baseQuery: fetchBaseQuery({
    baseUrl: URL.API_URL,
    prepareHeaders: (headers, { getState }) => {
      return headerConfig(headers, getState);
    },
  }),
  endpoints: (builder) => ({
    getUserCount: builder.query({
      query: (time) => ({
        url: `users/count?timeLine=${time}`,
        method: "GET",
      }),
      async onQueryStarted({ }, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          handleResponse(false, data, dispatch);
        } catch (error) {
          handleResponse(true, error?.error, dispatch);
        }
      },
    }),

    // sendPhoneOtp: builder.mutation({
    //   query: (payload) => ({
    //     url: "user/sendPhoneOtp",
    //     method: "POST",
    //     body: payload,
    //   }),
    //   async onQueryStarted({}, { dispatch, queryFulfilled }) {
    //     try {
    //       const { data } = await queryFulfilled;
    //       console.log("send otp success : ", data);
    //       handleResponse(true, data?.response, dispatch);
    //     } catch (error) {
    //       console.log("send otp error : ", error?.error);
    //       handleResponse(true, error?.error, dispatch);
    //     }
    //   },
    // }),
  }),
});

export const { useLazyGetUserCountQuery } = userListAPI;
