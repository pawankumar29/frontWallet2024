import { Router } from "express";

export interface HelpersInterface {
  initialize?: () => void
}