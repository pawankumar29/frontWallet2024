export interface TokenData {
    decimals: number;
    name: string;
    symbol: string;
  }

export interface FCMObject {
  details:string;
  title : string
}