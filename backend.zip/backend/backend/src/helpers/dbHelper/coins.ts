import commonHelper from "../common/common.helpers";
import * as Models from '../../models/model/index';


class CoinQueries {

    public async coin_find_one(attr: any, where_clause: any) {
        try {
            let data: any;
            if (attr.length > 0) {
                data = await Models.CoinsModel.findOne({
                    attributes: attr,
                    where: where_clause,
                    raw: true
                })
            } else {
                console.log("no attr")
                data = await Models.CoinsModel.findOne({
                    where: where_clause,
                    raw: true
                })
            }
            return data;
        } catch (err: any) {
            console.error("Error in coin_find_one>>", err)
            await commonHelper.save_error_logs("coin_find_one", err.message);
            throw err;
        }
    }
    public async coin_find_all(attr: any, where_clause: any) {
        try {
            let data: any;
            if (attr.length > 0) {
                data = await Models.CoinsModel.findAll({
                    attributes: attr,
                    where: where_clause,
                })
            } else {
                console.log("no attr")
                data = await Models.CoinsModel.findAll({
                    where: where_clause,
                })
            }
            return data;
        } catch (err: any) {
            console.error("Error in coin_find_all>>", err)
            await commonHelper.save_error_logs("coin_find_all", err.message);
            throw err;
        }
    }
    public async coin_create(obj: any) {
        try {
            let data: any = await Models.CoinsModel.create(obj)
            return data;
        } catch (err: any) {
            console.error("Error in coin_create>>", err)
            await commonHelper.save_error_logs("coin_create", err.message);
            throw err;
        }
    }
    public async coin_update(set: any, where_clause: any) {
        try {
            let data: any = await Models.CoinsModel.update(set, { where: where_clause })
            return data;
        } catch (err: any) {
            console.error("Error in coin_update>>", err)
            await commonHelper.save_error_logs("coin_update", err.message);
            throw err;
        }
    }
    public async distinct_coin_data(where_clause: any) {
        try {
            let data: any = await Models.CoinsModel.findAll({
                attributes: ["cmc_id"],
                where: where_clause,
                group: ["cmc_id"]
            })
            return data;
        } catch (err: any) {
            console.error("Error in distinct_coin_data>>", err)
            await commonHelper.save_error_logs("distinct_coin_data", err.message);
            throw err;
        }
    }

}

const coin_queries = new CoinQueries();
export default coin_queries;
