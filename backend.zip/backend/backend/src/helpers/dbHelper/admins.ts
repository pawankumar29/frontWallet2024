import commonHelper from "../common/common.helpers";
import * as Models from '../../models/model/index';

class AdminsQueries {

    public admin_model: any = Models.AdminModel

    public async find_one_admin(attributes: any, where: any) {
        try {
            let data: any = await this.admin_model.findOne({
                attributes: attributes,
                where: where,
                raw: true
            })
            return data;
        } catch (err: any) {
            console.error("Error in find_one_admin>>", err)
            throw err;
        }
    }
    public async update_admin_table(set: any, where: any) {
        try {
            await this.admin_model.update(set, { where: where })
        } catch (err: any) {
            console.error("Error in update_admin_table>>", err)
            throw err;
        }
    }

}

const admins_queries = new AdminsQueries();
export default admins_queries;
