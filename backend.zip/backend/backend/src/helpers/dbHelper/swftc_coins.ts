import commonHelper from "../common/common.helpers";
import * as Models from '../../models/model/index';


class SWFTCQueries {

    public async swftc_find_one(attr: any, where_clause: any) {
        try {
            let data: any = await Models.SWFTCCoinsDataModel.findOne({
                attributes: attr,
                where: where_clause,
                raw: true
            })
            return data;
        } catch (err: any) {
            console.error("Error in swftc_find_one>>", err)
            await commonHelper.save_error_logs("swftc_find_one", err.message);
            throw err;
        }
    }
    public async swftc_find_all(attr: any, where_clause: any) {
        try {
            let data: any = await Models.SWFTCCoinsDataModel.findAll({
                attributes: attr,
                where: where_clause
            })
            return data;
        } catch (err: any) {
            console.error("Error in swftc_find_all>>", err)
            await commonHelper.save_error_logs("swftc_find_all", err.message);
            throw err;
        }
    }
    public async swftc_update(set: any, where_clause: any) {
        try {
            let data: any = await Models.SWFTCCoinsDataModel.update(set, { where: where_clause })
            return data;
        } catch (err: any) {
            console.error("Error in swftc_update>>", err)
            await commonHelper.save_error_logs("swftc_update", err.message);
            throw err;
        }
    }
    public async swftc_create(obj: any) {
        try {
            let data: any = await Models.SWFTCCoinsDataModel.create(obj)
            return data;
        } catch (err: any) {
            console.error("Error in swftc_create>>", err)
            await commonHelper.save_error_logs("swftc_create", err.message);
            throw err;
        }
    }
    public async swftc_destroy(where_clause: any) {
        try {
            await Models.SWFTCCoinsDataModel.destroy({ where: where_clause })
        } catch (err: any) {
            console.error("Error in swftc_destroy>>", err)
            await commonHelper.save_error_logs("swftc_destroy", err.message);
            throw err;
        }
    }

}

const swftc_queries = new SWFTCQueries();
export default swftc_queries;
