import * as Models from '../../models/model/index';
import commonHelper from '../common/common.helpers';

class CoinPriceInFiatGraphQueries {

    public async coin_price_in_fiat_graph_create(obj: any) {
        try {
            console.log("obj>>>", obj)
            let data: any = await Models.CoinPriceInFiatGraphModel.create(obj)
            return data;
        } catch (err: any) {
            console.error("Error in coin_price_in_fiat_graph_create>>", err)
            await commonHelper.save_error_logs("coin_price_in_fiat_graph_create", err.message);

            throw err;
        }
    }
    public async coin_price_in_fiat_graph_bulk_create(obj: any) {
        try {
            let data: any = await Models.CoinPriceInFiatGraphModel.bulkCreate(obj)
            return data;
        } catch (err: any) {
            console.error("Error in coin_price_in_fiat_graph_bulk_create>>", err)
            await commonHelper.save_error_logs("coin_price_in_fiat_graph_bulk_create", err.message);

            throw err;
        }
    }
    public async coin_price_in_fiat_graph_find_one(attr: any, where_clause: any) {
        try {
            let data: any = await Models.CoinPriceInFiatGraphModel.findOne({
                attributes: attr,
                where: where_clause,
                raw: true
            })
            return data;
        } catch (err: any) {
            console.error("Error in coin_price_in_fiat_graph_find_one>>", err)
            await commonHelper.save_error_logs("coin_price_in_fiat_graph_find_one", err.message);
            throw err;
        }
    }

}

const coin_price_in_fiat_graph_queries = new CoinPriceInFiatGraphQueries();
export default coin_price_in_fiat_graph_queries;
