import commonHelper from "../common/common.helpers";
import * as Models from '../../models/model/index';


class UserQueries {

    public async user_find_one(attr: any, where_clause: any) {
        try {
            let data: any = await Models.UsersModel.findOne({
                attributes: attr,
                where: where_clause,
                raw: true
            })
            return data;
        } catch (err: any) {
            console.error("Error in user_find_one>>", err)
            await commonHelper.save_error_logs("user_find_one", err.message);
            throw err;
        }
    }
    public async user_update(set: any, where_clause: any) {
        try {
            let data: any = await Models.UsersModel.update(set, { where: where_clause })
            return data;
        } catch (err: any) {
            console.error("Error in user_update>>", err)
            await commonHelper.save_error_logs("user_update", err.message);
            throw err;
        }
    }
    public async user_create(obj: any) {
        try {
            let data: any = await Models.UsersModel.create(obj)
            return data;
        } catch (err: any) {
            console.error("Error in user_create>>", err)
            await commonHelper.save_error_logs("user_create", err.message);
            throw err;
        }
    }

}

const user_queries = new UserQueries();
export default user_queries;
