import commonHelper from "../common/common.helpers";
import * as Models from '../../models/model/index';


class WalletQueries {

    public async wallet_find_one(attr: any, where_clause: any) {
        try {
            let data: any
            if (attr.length > 0) {
                data = await Models.WalletModel.findOne({
                    attributes: attr,
                    where: where_clause,
                    raw: true
                })
            } else {
                data = await Models.WalletModel.findOne({
                    where: where_clause,
                    raw: true
                })
            }
            return data;
        } catch (err: any) {
            console.error("Error in wallet_find_one>>", err)
            await commonHelper.save_error_logs("wallet_find_one", err.message);
            throw err;
        }
    }
    public async wallet_find_all(attr: any, where_clause: any) {
        try {
            let data: any = await Models.WalletModel.findAll({
                attributes: attr,
                where: where_clause,
            })
            return data;
        } catch (err: any) {
            console.error("Error in wallet_find_all>>", err)
            await commonHelper.save_error_logs("wallet_find_all", err.message);
            throw err;
        }
    }
    public async wallet_update(set: any, where_clause: any) {
        try {
            let data: any = await Models.WalletModel.update(set, { where: where_clause })
            return data;
        } catch (err: any) {
            console.error("Error in wallet_update>>", err)
            await commonHelper.save_error_logs("wallet_update", err.message);
            throw err;
        }
    }
    public async wallet_create(obj: any) {
        try {
            let data: any = await Models.WalletModel.create(obj)
            return data;
        } catch (err: any) {
            console.error("Error in wallet_create>>", err)
            await commonHelper.save_error_logs("wallet_create", err.message);
            throw err;
        }
    }

}

const wallet_queries = new WalletQueries();
export default wallet_queries;
