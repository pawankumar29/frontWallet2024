import NodeRSA from "node-rsa";
import fs from "fs";
import { config } from "../../config";
// import * as Models from '../../models/model/index';
import { catch_err_msg_queries } from "../dbHelper/index";
import axios from "axios";
import path from "path";
class CommonHelper {
  constructor() {}

  public async save_error_logs(fn_name: string, error_message: any) {
    try {
      await catch_err_msg_queries.catch_err_msg_create({
        fx_name: fn_name,
        error_msg: error_message || {},
      });
    } catch (err: any) {
      console.error("Error in save_error_logs", err);
    }
  }

  public async decryptDataRSA(data: any) {
    try {
      let privateKeyFile = await fs.readFileSync(
        `${__dirname}/../../config/keys/${config.RSA_PRIVATE_KEY_NAME}`,
        { encoding: "utf-8" }
      );
      // console.log('privateKeyFile>>>', privateKeyFile);
      let privateKey = Buffer.from(privateKeyFile);
      let RSAKey = new NodeRSA(privateKey);
      RSAKey.setOptions({ encryptionScheme: "pkcs1" });
      let decryptedData = await RSAKey.decrypt(data);
      return decryptedData;
    } catch (err: any) {
      console.error("decryptDataRSA error ======== ,", err.message);
      throw new Error(err);
    }
  }
  public async adminDecryptDataRSA(data: any) {
    try {
      const p = path.join(
        __dirname,
        `../../../build/config/admin_keys/${config.RSA_ADMIN_PRIVATE_KEY_NAME}`
      );
      //console.log("path::",p);
      let privateKeyFile = await fs.readFileSync(
        `${__dirname}/../../../build/config/admin_keys/${config.RSA_ADMIN_PRIVATE_KEY_NAME}`,
        { encoding: "utf-8" }
      );
      let privateKey = Buffer.from(privateKeyFile);
      let RSAKey = new NodeRSA(privateKey);
      RSAKey.setOptions({ encryptionScheme: "pkcs1" });
      let decryptedData = await RSAKey.decrypt(data);
      return decryptedData;
    } catch (err: any) {
      console.error("adminDecryptDataRSA error ======== ,", err.message);
      throw new Error(err);
    }
  }
  public async encryptDataRSA(data: any) {
    let publicKeyFile: any = fs.readFileSync(
      `${__dirname}/../../config/keys/${config.RSA_PUBLIC_KEY_NAME}`,
      { encoding: "utf-8" }
    );
    let publicKey: any = Buffer.from(publicKeyFile);
    let RSAKey: any = new NodeRSA(publicKey);
    RSAKey.setOptions({ encryptionScheme: "pkcs1" });
    let encryptedData: any = RSAKey.encrypt(data, "base64");
    return encryptedData;
  }

  public async adminEncryptDataRSA(data: any) {
    try {
      let privateKeyFile = await fs.readFileSync(
        `${__dirname}/../../config/admin_keys/${config.RSA_ADMIN_PRIVATE_KEY_NAME}`,
        { encoding: "utf-8" }
      );
      let privateKey = Buffer.from(privateKeyFile);
      let RSAKey = new NodeRSA(privateKey);
      RSAKey.setOptions({ encryptionScheme: "pkcs1" });
      let decryptedData = await RSAKey.decrypt(data);
      return decryptedData;
    } catch (err: any) {
      console.error("adminEncryptDataRSA error ======== ,", err.message);
      throw new Error(err);
    }
  }

  public async send_mail(email: string, text: string, subject: string) {
    try {
      let MAILGUN_API_KEY: string = `${config.MAILGUN.MAILGUN_API_KEY}`;
      let MAILGUN_DOMAIN: string = `${config.MAILGUN.MAILGUN_DOMAIN}`;
      let MAILGUN_BASE_URL: string = `${config.MAILGUN.MAILGUN_BASE_URL}${MAILGUN_DOMAIN}`;
      let response: any = await axios({
        method: "post",
        url: `${MAILGUN_BASE_URL}/messages`,
        auth: {
          username: "api",
          password: MAILGUN_API_KEY,
        },
        params: {
          from: config.MAILGUN.FROM_GMAIL,
          to: email,
          subject: subject,
          html: text,
        },
      });
      return response;
    } catch (err: any) {
      console.error("err in send_mail", err);
      return err;
    }
  }

  // public async send_mail_sendGrid(email: string, text: string, subject: string) {
  //   try {
  //     let SENDGRID_API_KEY: string = `${config?.SENDGRID?.API_KEY}`;
  //     let SENDGRID_BASE_URL: string = 'https://api.sendgrid.com/v3';
  //     let response: any = await axios({
  //       method: "post",
  //       url: `${SENDGRID_BASE_URL}/mail/send`,
  //       headers: {
  //         'Authorization': `Bearer ${SENDGRID_API_KEY}`
  //       },
  //       data: {
  //         from: config?.SENDGRID.FROM_EMAIL,
  //         to: email,
  //         subject: subject,
  //         content: [
  //           {
  //             type: 'text/plain',
  //             value: text,
  //           }
  //         ]
  //       }
  //     });
  //     return response;
  //   } catch (err: any) {
  //     console.error("err in send_mail", err);
  //     return err;
  //   }
  // }
}

const commonHelper = new CommonHelper();
export default commonHelper;
