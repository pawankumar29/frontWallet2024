import axios from "axios";
import { config } from "../../config";
import { ethWeb3 } from "./web3_eth_helpers";
import {
  GlblBooleanEnum,
  GlblCoins,
  GlblMessages,
} from "../../constants/global_enum";
import { utxobtc } from "./web3_btc_helpers";
import { trxWeb3 } from "./web3_trx_helper";
import { CoinInterface, NotificationInterface } from "../../models";
import { TokenType } from "../../constants/global_enum";
import { AbiItem } from "web3-utils";
import { exponentialToDecimal } from "./globalFunctions";
import * as Models from "../../models/model/index";
import { FCMObject } from "../../interfaces/global.interface";
import dbHelper, { settings_queries } from "../dbHelper";
import commonHelper from "./common.helpers";
import { bscWeb3 } from "./web3.bsc_helper";
//dependency
import Web3 from "web3";
import HttpProvider from "web3";
//dependency

// firebase admin
const firebaseAdmin = require("firebase-admin");
import fcmServiceAccount from "../../constants/fcm_admin_key.json";
import cmcHelper from "./cmc.helper";
import userhelper from "../../modules/user/helper";

var FCM = require("fcm-node");

class Global_helper {
  constructor() {
    (async () =>
      await firebaseAdmin.initializeApp({
        credential: firebaseAdmin.credential.cert(fcmServiceAccount),
      }))();
  }

  public async return_decimals_name_symbol(
    coin_family: number,
    token_address: string,
    lang: string
  ) {
    try {
      let tokenDetails: any = { decimals: 0, name: "", symbol: "" };
      switch (coin_family) {
        case config.STATIC_COIN_FAMILY.BNB:
          tokenDetails = await bscWeb3.searchToken(token_address, lang, false);
          break;
        case config.STATIC_COIN_FAMILY.ETH:
          tokenDetails = await ethWeb3.searchToken(token_address, lang, false);
          break;
        case config.STATIC_COIN_FAMILY.TRX:
          tokenDetails = await trxWeb3.searchToken(token_address, lang, false);
          break;
      }
      return tokenDetails;
    } catch (err: any) {
      console.error("Error in return_decimals_name_symbol>>", err);
      await commonHelper.save_error_logs(
        "return_decimals_name_symbol",
        err.message
      );
      return null;
    }
  }
  public async validate_address(data: any) {
    try {
      if (data.symbol) {
        data.symbol = data.symbol.toUpperCase();
        switch (data.symbol) {
          case GlblCoins.BNB:
            return await bscWeb3.validate_bnb_address(data.address);
          case GlblCoins.ETH:
            return await ethWeb3.validate_eth_address(data.address);
          case GlblCoins.BTC:
            // if (config.SERVER !== 'stage') {
            return await utxobtc.validate_btc_address(data.address);
            // }
            return true;
          case GlblCoins.TRX:
            return await trxWeb3.validate_trx_address(data.address);
        }
      } else if (data.coin_family) {
        switch (data.coin_family) {
          case config.STATIC_COIN_FAMILY.BNB:
            return await bscWeb3.validate_bnb_address(data.wallet_address);
          case config.STATIC_COIN_FAMILY.ETH:
            return await ethWeb3.validate_eth_address(data.wallet_address);
          case config.STATIC_COIN_FAMILY.BTC:
            // if (config.SERVER !== 'stage') {
            return await utxobtc.validate_btc_address(data.wallet_address);
            // }
            return true;
          case config.STATIC_COIN_FAMILY.TRX:
            return await trxWeb3.validate_trx_address(data.wallet_address);
        }
      }
    } catch (err: any) {
      console.error("Error in validate_address", err);
      await commonHelper.save_error_logs("validate_address", err.message);
      return false;
    }
  }
  public async get_new_token_balance(data: any) {
    let tokenType: string = data.token_type;
    try {
      let coin_family: number = data.coin_family;
      let token_address: string = data.token_address;
      let wallet_address: string = data.wallet_address;
      let tokenBalance: any;
      let userBalance: string |any= "";
      switch (coin_family) {
        case config.STATIC_COIN_FAMILY.BNB:
          tokenType = TokenType.BEP20;
          tokenBalance = (
            await bscWeb3.get_bep20_token_balance(
              token_address,
              config.CONTRACT_ABI as AbiItem[],
              wallet_address
            )
          )?.toString();
          userBalance =tokenBalance? exponentialToDecimal(Number(tokenBalance)):tokenBalance;
          break;
        case config.STATIC_COIN_FAMILY.ETH:
          tokenType = TokenType.ERC20;
          tokenBalance = (
            await ethWeb3.get_erc20_token_balance(
              token_address,
              config.CONTRACT_ABI as AbiItem[],
              wallet_address
            )
          )?.toString();
          userBalance =tokenBalance? exponentialToDecimal(Number(tokenBalance)):tokenBalance;
          break;
        case config.STATIC_COIN_FAMILY.TRX:
          tokenType = TokenType.TRC20;
          userBalance = (
            await trxWeb3.TRC20_Token_Balance(wallet_address, token_address)
          )
          break;
        default:
          throw GlblMessages.INVALID_COIN_FAMILY;
      }
      return { status:true,userBalance, tokenType };
    } catch (err: any) {
      console.error("Error in get_new_token_balance.", err);
      await commonHelper.save_error_logs("get_new_token_balance", err.message);
      return { status:false,userBalance: 0, tokenType };
      // return "0";
    }
  }
  public async swap_supported(token_address: string, coin_family: number) {
    try {
      let result: any;
      // Uniswap
      if (coin_family == config.STATIC_COIN_FAMILY.ETH) {
        let data: any = JSON.stringify({
          query: `{
                        token(id:"${token_address.toLowerCase()}"){
                        name
                        symbol
                        decimals
                        derivedETH
                        }
                    }`,
          variables: {},
        });
        await axios
          .post(
            `https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3`,
            data,
            { headers: { "Content-Type": "application/json" } }
          )
          .then((response) => {
            // await axios.post(`https://open-platform.nodereal.io/6a1e081738c744eaacd71f5867df78f9/uniswap/graphql/`, data, { headers: { "Content-Type": "application/json" } }).then(response => {
            result = response;
          })
          .catch((err) => {
            console.error("Error in swap_supported > eth.", err);
          });
      } else if (coin_family == config.STATIC_COIN_FAMILY.BNB) {
        // Token Supported on pancakeswap
        let data = JSON.stringify({
          query: `{
                        token(id: "${token_address.toLowerCase()}"){
                            name
                            symbol
                            decimals
                            derivedUSD
                            tradeVolumeUSD
                        }
                    }`,
          variables: {},
        });
        // const result = await axios.post(`https://open-platform.nodereal.io/32ccbdc48c474b0492ed01cc0d950ec4/pancakeswap/graphql`, data, { headers: { 'Content-Type': 'application/json' } });
        await axios
          .post(
            `https://open-platform.nodereal.io/6a1e081738c744eaacd71f5867df78f9/pancakeswap-free/graphql`,
            data,
            { headers: { "Content-Type": "application/json" } }
          )
          .then((response) => {
            result = response;
          })
          .catch((err) => {
            console.error("Error in swap_supported > matic.", err);
          });
      }
      if (result) {
        if (result?.data) {
          if (result.data?.data) {
            if (result.data.data.token != null) {
              return 1;
            } else {
              return 0;
            }
          } else {
            return 0;
          }
        } else {
          return 0;
        }
      } else {
        return 0;
      }
    } catch (err: any) {
      console.error(`TokenController swapSupported  error >>>`, err);
      return 0;
    }
  }
  public async oneInchSwapSupported(tokenAddress: any, coin_family: number) {
    let chain_id = 56;
    if (coin_family == 2) {
      chain_id = 1;
    }
    let config1: any = {
      method: "get",
      maxBodyLength: Infinity,
      url: `https://api.1inch.dev/token/v1.2/${chain_id}/search?query=${tokenAddress}&ignore_listed=false`,
      headers: {
        Authorization: config.ON_CHAIN.ONEINCH_API_KEY,
      },
    };

    try {
      return axios.request(config1).then((response) => {
        console.log(JSON.stringify(response.data));
        if (response.data.length > 0) {
          return 1;
        }
        return 0;
      });
    } catch (error) {
      console.error("Error swapping tokens:", error);
      throw error;
    }
  }
  public async find_plateform(coin_family: number) {
    try {
      const coingecko_platforms_ids = [
        {
          id: "ethereum",
          name: "ethereum",
          shortname: "ETH",
          coin_family: config.STATIC_COIN_FAMILY.ETH,
          symbol: GlblCoins.ETH,
        },
        {
          id: "bitcoin",
          name: "bitcoin",
          shortname: "BTC",
          coin_family: config.STATIC_COIN_FAMILY.BTC,
          symbol: GlblCoins.BTC,
        },
        {
          id: "TRON",
          name: "TRON",
          shortname: "TRON",
          coin_family: config.STATIC_COIN_FAMILY.TRX,
          symbol: GlblCoins.TRX,
        },
        {
          id: "binance",
          name: "BNB",
          shortname: "BNB",
          coin_family: config.STATIC_COIN_FAMILY.BNB,
          symbol: GlblCoins.BNB,
        },
      ];
      const platform_id: any = await coingecko_platforms_ids.find(
        (pd) => pd.coin_family == coin_family
      );
      return platform_id;
    } catch (err: any) {
      console.error("Error in findPlateForm helper", err);
      await commonHelper.save_error_logs("find_plateform", err.message);
      return null;
    }
  }
  public async get_token_image_from_cmc(data: any) {
    try {
      let params: any = data.symbol
        ? `info?symbol=${data.symbol}` : data.id
          ? `info?id=${data.id}` : `info?address=${data.token_address}`;
      let result: any = await cmcHelper.cmcApi(params);

      let image: any;
      let id: any;
      if (data.id) {
        id = data.id;
        image = result.data.data[id as keyof typeof String].logo;
      } else {
        id =
          result.data.data[data.symbol.toUpperCase() as keyof typeof String][0]
            .id;
        image =
          result.data.data[data.symbol.toUpperCase() as keyof typeof String][0]
            .logo;
      }
      let imageUrl: any = await this.UpdateCmcImgUrl(image);
      return { image: imageUrl, id: id };
    } catch (err: any) {
      console.error("Error in get_token_image_from_cmc", err);
      return null;
    }
  }
  public async UpdateCmcImgUrl(image_url: string) {
    try {
      if (image_url.includes("img/coins/16x16/")) {
        image_url = image_url.replace("16x16", "200x200");
      } else if (image_url.includes("img/coins/32x32/")) {
        image_url = image_url.replace("32x32", "200x200");
      } else if (image_url.includes("img/coins/64x64/")) {
        image_url = image_url.replace("64x64", "200x200");
      } else if (image_url.includes("img/coins/128x128/")) {
        image_url = image_url.replace("128x128", "200x200");
      }
      return image_url;
    } catch (err: any) {
      console.error(`UpdateCmcImgUrl error>>> `, err);
      return "null";
    }
  }
  public async get_wallet_balance(
    coinData: CoinInterface,
    wallet_address: string
  ) {
    try {
      let balance: string |any = "0";
      switch (coinData.coin_family) {
        case config.STATIC_COIN_FAMILY.BNB:
          balance = (
            await bscWeb3.get_balance(coinData, wallet_address)
          )?.toString();
          break;
        case config.STATIC_COIN_FAMILY.ETH:
          balance = (
            await ethWeb3.get_balance(coinData, wallet_address)
          )?.toString();
          break;
        case config.STATIC_COIN_FAMILY.BTC:
          //if (config.SERVER !== 'stage') {
          let fetchBalance = await utxobtc.get_balance(wallet_address)
          balance = fetchBalance != null ? fetchBalance?.toString() : null;
          //}

          break;
        case config.STATIC_COIN_FAMILY.TRX:
          balance = (
            await trxWeb3.Fetch_Balance(wallet_address, coinData)
          )?.toString();
          break;
      }

        if(balance==null){
          return { status: false, balance: balance };
        }
      return { status: true, balance: balance };
    } catch (err: any) {
      console.error("Error in get_wallet_balance.", err);
      await commonHelper.save_error_logs("get_wallet_balance", err.message);
      return { status: false, balance: "0" };
    }
  }
  public async fetch_data(method: string, url: string, header: Object) {
    try {
      let config_data: any = {
        method: method,
        url: url,
        headers: header,
      };
      let return_data: any;
      await axios(config_data)
        .then(function (response) {
          return_data = response?.data;
          return response?.data;
        })
        .catch(function (err: any) {
          console.error("axios catch error", err.message);
          return_data = null;
          return null;
        });
      return return_data;
    } catch (err: any) {
      console.error("🔥 ~ ~ fetch_data error", err);
      return null;
    }
  }
  public subtractDays(date: any, days: number) {
    date.setDate(date.getDate() - days);
    return date;
  }
  public subtractMonths(date: any, months: number) {
    date.setMonth(date.getMonth() - months);
    return date;
  }
  public async save_notification(object: NotificationInterface) {
    try {
      await Models.NotificationModel.create(object);
      return true;
    } catch (err: any) {
      console.error("Error in save_notification>>>>", err);
      return false;
    }
  }
  public async send_fcm_push_notification(
    to_user_id: number,
    object: FCMObject
  ) {
    let deviceTokens: any = await Models.DeviceTokenModel.findAll({
      attributes: ["device_token", "user_id"],
      where: {
        push: GlblBooleanEnum.true,
        user_id: to_user_id,
      },
      order: [
        ["updated_at", "DESC"],
        ["id", "DESC"],
      ],
      group: ["device_token"],
      raw: true,
    });
    let device_tokens = [];
    for await (let deviceToken of deviceTokens) {
      device_tokens.push(deviceToken.device_token);
    }
    let serverKey: string = config.FCM_SERVER_KEY;
    if (device_tokens && serverKey) {
      let fcm = new FCM(serverKey);
      let message: any;

      if (Array.isArray(device_tokens)) {
        message = {
          registration_ids: device_tokens,
          collapse_key: "type_a",
          notification: {
            title: object.title,
            body: object.details,
            sound: "default",
          },
          data: {
            body: object.details,
            title: object.title,
            announcement_title: object.title,
            announcement_message: object.details,
          },
        };
      } else {
        message = {
          registration_ids: device_tokens,
          collapse_key: "type_a",
          notification: {
            title: object.title,
            body: object.details,
            sound: "default",
          },
          data: {
            body: object.details,
            title: object.title,
            announcement_title: object.title,
            announcement_message: object.details,
          },
        };
      }
      fcm.send(message, function (err: any, messageId: number) {
        if (err) {
          console.error("Something has gone wrong!", err);
        } else {
          console.debug(`fcm push notification >>`, messageId);
        }
      });
    }
  }
  public async get_coin_family_from_blockchain(coin: string) {
    try {
      let coin_family: number = 0;
      coin = coin.toLowerCase();
      if (coin == "eth") {
        coin_family = config.STATIC_COIN_FAMILY.ETH;
      }
      if (coin == "btc") {
        coin_family = config.STATIC_COIN_FAMILY.BTC;
      }
      if (coin == "trx") {
        coin_family = config.STATIC_COIN_FAMILY.TRX;
      }
      if (coin == "bnb") {
        coin_family = config.STATIC_COIN_FAMILY.BNB;
      }
      return coin_family;
    } catch (err: any) {
      console.error("Error in get_coin_family_from_blockchain>>", err);
      throw 0;
    }
  }

  public checkNativeSymbol(coinName: String) {
    try {
      coinName = coinName?.toLowerCase();
      switch (coinName) {
        case "ethereum":
          return "eth";
        case "binance":
          return "bnb";
      }

      return null;
    } catch (error) {
      console.error(`error in checkNativeSymbol  ${error}`);
    }
  }

  // changes doing for various nodes

  public async checkNodeWorks(node: any) {
    try {
      console.log("checkNodeWorks::", node);
      const web3: any = new Web3.providers.HttpProvider(node);

      console.log("new Line ", web3);
      //   if (!web3 || typeof web3.eth !== "object") {
      //     return null;
      //   }
      //   console.log("web3.eth::", web3.eth);
      const blockNumber = await web3.eth.getBalance(
        "0x407d73d8a49eeb85d32cf465507dd71d507100c1"
      );
      // console.log("new Line ", blockNumber);

      return node;
    } catch (error) {
      console.log(`error in the checkNodeWork `, error);
      return null;
    }
  }

  public Nodes() {
    return [
      "https://ethereum-rpc.publicnode1.com",
      "https://mainnet.infura.io/v3/e80ad40af5834bafb4f2076669618dfe1",
      config.NODE.ETH_RPC_URL,
    ];
  }
  public async sendNewNotification(data: any) {
    try {
      if (data?.deviceTokens?.length > 0) {
        const messaging = firebaseAdmin.messaging();

        console.log("data::", data);

        if (Array.isArray(data.deviceTokens)) {
          messaging
            .sendMulticast({
              tokens: data.deviceTokens,
              collapse_key: "type_a",
              notification: data.notification,
            })
            .then((response: any) => {
              console.log("💥🚀 ~ firebase admin push notification", response);
              // console.log("responses>error", response?.responses[0]?.error);
            })
            .catch((error: any) => {
              console.error(
                "💥 ~ firebase admin sending notification error",
                error
              );
            });
        } else {
          messaging
            .sendMulticast({
              token: data.deviceTokens,
              collapse_key: "type_a",
              notification: data.notification,
            })
            .then((response: any) => {
              console.log("💥🚀 ~ firebase admin push notification", response);
            })
            .catch((error: any) => {
              console.error(
                "💥 ~ firebase admin sending notification error",
                error
              );
            });
        }
      }

      return true;
    } catch (error) {
      console.error(`🔥 ~ sendNewNotification utility.helper.ts error`, error);
      return false;
    }
  }
  // changes doing for various nodes
}
export const global_helper = new Global_helper();
