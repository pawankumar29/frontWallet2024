import { DataTypes, Model, Optional } from "sequelize";
import { ContactsInterface } from "../interface/interface.contacts";
import db from "../../helpers/common/db";

interface ContactsModel
    extends Optional<ContactsInterface, "id"> { }
interface ContactsInstance
    extends Model<ContactsInterface, ContactsModel>,
    ContactsInterface { }

let dataObj = {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    first_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    last_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    email: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    phone_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    company_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    message: {
        type: DataTypes.STRING,
        allowNull: false,
    },
};

let dataObjIndex = {
    indexes: [
        {
            unique: true,
            fields: ["email"],
        },
        {
            unique: false,
            fields: ["phone_number"],
        },
    ],
};

const ContactModel = db.db_write.define<ContactsInstance>(
    "contacts",
    dataObj,
    dataObjIndex
);

export default ContactModel;   