import { DataTypes, Model, Optional } from "sequelize";
import { PriceAlertsInterface } from "../interface/interface.priceAlerts";
import db from "../../helpers/common/db";
import CoinsModel from "./model.coins";

interface PriceAlertsCreationModel extends Optional<PriceAlertsInterface, "id"> { }
interface PriceAlertsDataInterface
  extends Model<PriceAlertsInterface, PriceAlertsCreationModel>,
  PriceAlertsInterface { }

const dataObj = {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  fiat_type: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  percentage: {
    type: DataTypes.DOUBLE,
    allowNull: false,
  },
  price: {
    type: DataTypes.DOUBLE,
    allowNull: false,
  },
  wallet_address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  price_in_usd_per_unit: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  coin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
};

const PriceAlertsDataModel = db.db_write.define<PriceAlertsDataInterface>(
  "price_alerts",
  dataObj
);


PriceAlertsDataModel.belongsTo(CoinsModel, { foreignKey: "coin_id", targetKey: "coin_id", as: "coin_data" })

export default PriceAlertsDataModel;