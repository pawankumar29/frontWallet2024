import { DataTypes, Model, Optional } from "sequelize";
import db from "../../helpers/common/db";
import { OnOffRampWebhookInterface } from '../interface/index.interface';
interface OnOffRampWebhookCreationModel extends Optional<OnOffRampWebhookInterface, "id"> { }
interface OnOffRampWebhookInstance
    extends Model<OnOffRampWebhookInterface, OnOffRampWebhookCreationModel>,
    OnOffRampWebhookInterface { }

let dataObj = {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    ramp_type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    encoded_webhook:{
        type: DataTypes.JSON,
        allowNull: true
    },
    webhook: {
        type: DataTypes.JSON,
        allowNull: true
    },
    webhook_id:{
        type: DataTypes.JSON,
        allowNull: true
    },
    status:{
        type: DataTypes.JSON,
        allowNull: true
    },
    created_at:{
        type:DataTypes.DATE,
        defaultValue:DataTypes.NOW
    },
    updated_at:{
        type:DataTypes.DATE,
        defaultValue:DataTypes.NOW
    }
};

const OnOffRampWebhookModel = db.db_write.define<OnOffRampWebhookInstance>(
    "on_off_ramp_webhooks",
    dataObj
);

export default OnOffRampWebhookModel;