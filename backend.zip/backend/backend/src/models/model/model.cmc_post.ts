import { DataTypes, Model, Optional } from "sequelize";
import { cmcPostInterface } from "../index";
import db from "../../helpers/common/db";
interface CmcPost extends Optional<cmcPostInterface, "id"> { }
interface CmcPostInstance
    extends Model<cmcPostInterface, cmcPostInterface>,
    cmcPostInterface { }
let dataObj = {
    id: {
        type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, 
    },
    nickname: {
        type: DataTypes.STRING,
        allowNull: false
    },
    text_content: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    post_id: {
        type: DataTypes.STRING,
        allowNull: false
    },
    post_time: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cmc_id: {
        type: DataTypes.STRING,
        allowNull: false
    },
    comment_url: {
        type: DataTypes.STRING,
        allowNull: false
    }

   
}

const CmcPostModel = db.db_write.define<CmcPostInstance>(
    "cmc_news",
    dataObj,
     {
        timestamps: true // Add this option
      }
);

export default CmcPostModel;

