import { DataTypes, Model, Optional } from "sequelize";
import db from "../../helpers/common/db";
import { AdminSettingInterface } from "../interface/interface.admin_setting.interface";

interface AdminSettingModel extends Optional<AdminSettingInterface, "id"> { }
interface AdminSettingInstance
    extends Model<AdminSettingInterface, AdminSettingModel>,
    AdminSettingInterface { }

let dataObj: any = {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    type_number: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    reward_amount: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
};

const AdminSettingModel = db.db_write.define<AdminSettingInstance>("reward_settings", dataObj);
export default AdminSettingModel;


