import { DataTypes, Model, Optional } from "sequelize";
import { UserInterface } from "../interface/interface.users";
import db from "../../helpers/common/db";
import WalletModel from "./model.wallets";
import { RewardHistoryModel } from "..";
interface UserCreationModel extends Optional<UserInterface, "user_id"> { }
interface UserInstance extends Model<UserInterface, UserCreationModel>, UserInterface { }

let dataObj = {
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  user_name: {
    type: DataTypes.STRING,
    allowNull: true
  },
  // email: {
  //   type: DataTypes.STRING,
  //   allowNull: true
  // },
  referral_type_id: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  referral_code: {
    type: DataTypes.STRING,
    allowNull: false
  },
  referral_count: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  device_id: {
    type: DataTypes.STRING,
    allowNull: true
  },
  login_time: {
    type: DataTypes.DATE,
    allowNull: true
  },
  request_rejected: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: false
  },
};


const UsersModel = db.db_write.define<UserInstance>(
  "users",
  dataObj
);
UsersModel.hasMany(WalletModel, {
  foreignKey: "user_id",
  as: "user_wallet_relation"
});

// UsersModel.hasMany(RewardHistoryModel, {
//   as: "user_rewards",
//   foreignKey: "user_id",
//   sourceKey:"user_id"
// });

// UsersModel.hasMany(CardUserModel, { foreignKey: "user_id", sourceKey: "user_id", as: "user_cardUser_data" })


export default UsersModel;