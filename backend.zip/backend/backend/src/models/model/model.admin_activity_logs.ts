import { DataTypes, Model, Optional } from "sequelize";
import { AdminActivityLogsInterface } from "../interface/index.interface";
import db from "../../helpers/common/db";

interface AdminActivityLogsCreationModel extends Optional<AdminActivityLogsInterface, "id"> { }
interface AdminActivityLogsInstance
    extends Model<AdminActivityLogsInterface, AdminActivityLogsCreationModel>,
    AdminActivityLogsInterface { }

const dataObj = {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    ip: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    action_type: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    role_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
};

const AdminActivityLogsModel = db.db_write.define<AdminActivityLogsInstance>("admin_activity_logs", dataObj);

export default AdminActivityLogsModel;


