
export interface cmcPostInterface {
    nickname: string,
    text_content: string,
    post_id: number,
    post_time:string,
    cmc_id:string,
    id?:number,
    comment_url:string

}