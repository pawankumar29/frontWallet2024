export interface SettingsInterface {
  id?: number,
  title: string,
  value: string,
  created_at: Date,
  updated_at: Date
}
