export interface AdminSettingInterface {
    id: number;
    type: string;
    type_amount: number;
    reward_amount: number;
}
