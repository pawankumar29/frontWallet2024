export { AddressBookInterface } from './interface.address_book';
export { CoinPriceInFiatInterface } from './interface.coinPriceInFiat';
export { CoinPriceInFiatGraphInterface } from './interface.coinPriceInFiatGraph';
export { CoinInterface } from './interface.coins';
export { CurrencyFiatInterface } from './interface.currencyFiat';
export { CustomSwapInterface } from './interface.customSwapList';
export { DappInterface } from './interface.dapp';
export { DeviceTokenInterface } from './interface.deviceToken';
export { GasPriceInterface } from './interface.gasprice';
export { NotificationInterface } from './interface.notifications';
export { PriceAlertsInterface } from './interface.priceAlerts';
export { SettingsInterface } from './interface.settings';
export { SwapInterface } from './interface.swapList';
export { ITrnxHistoryInterface } from './interface.trnxHistory';
export { UserInterface } from './interface.users';
export { WalletInterface } from './interface.wallets';
export { WatchlistInterface } from './interface.watchlists';
export { CustomTokenInterface } from './interface.custom_token';
export { AnnouncementInterface } from './interface.announcements'
export { AnnouncementStatusInterface } from './interface.announcement_status';
export { CatchErrorMsgsInterface } from './interface.catch_error_logs'
export { AppLanguagesInterface } from './interface.app_languages';
export { ReferralInterface } from './interface.referrals';
export { SwapSettingsInterface } from './interface.swap_settings';
export { OnOffRampFiatsInterface } from './interface.on_off_ramp_fiats';
export { OnOffRampWebhookInterface } from './interface.on_off_Ramp_Webhooks';
export { AdminActivityLogsInterface } from './interface.admin_activity_logs';
export { AdminInterface } from './interface.admin';
export {cmcPostInterface} from './interface.cmc_post';









