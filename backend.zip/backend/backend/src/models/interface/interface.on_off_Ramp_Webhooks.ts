export interface OnOffRampWebhookInterface {
    id: number;
    ramp_type: string,
    encoded_webhook: {} | null,
    webhook: {} | null,
    webhook_id: {} | null,
    status: {} | null,
    created_at: Date,
    updated_at: Date
}