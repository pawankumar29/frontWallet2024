export interface AppLanguagesInterface {
    id: number;
    name: string;
    code: string;
    image: string;
    status: string;
}
