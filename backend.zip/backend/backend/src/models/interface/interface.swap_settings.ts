export interface SwapSettingsInterface {
    id?: number,
    address: string,
    percentage: string
}
