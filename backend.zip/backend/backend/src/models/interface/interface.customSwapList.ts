export interface CustomSwapInterface {
    id?: number;
    user_id: number;
    coin_id:number;
    wallet_address: string;
    swap_list_id: string;
    created_at?: string
    updated_at?: string
  }
  