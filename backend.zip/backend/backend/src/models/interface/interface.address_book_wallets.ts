export interface AddressBookWalletInterface {
    id: number;
    address_book_id: number;
    wallet_address: string;
    coin_family: number;
    name: string;
}
