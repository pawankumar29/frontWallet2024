export interface JwtsInterface {
    id: number;
    user_id: number;
    device_token: string;
    device_token_id: string;
    token: string;
    refresh: string;
}
