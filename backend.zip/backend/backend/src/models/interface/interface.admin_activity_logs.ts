export interface AdminActivityLogsInterface {
    id: number;
    email: string;
    ip: string | null;
    action_type: string | null;
    role_id: number,
    active: number | 0;
    created_at: Date;
    updated_at: Date
}