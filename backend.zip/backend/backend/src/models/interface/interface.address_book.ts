export interface AddressBookInterface {
  id: number;
  user_id: number;
  address: string;
  name: string;
  created_at: Date,
  updated_at: Date

}
