export interface AnnouncementStatusInterface {
    id: number;
    user_id: number;
    view_status: number | null;
    created_at?: string;
    updated_at?: string;
}
