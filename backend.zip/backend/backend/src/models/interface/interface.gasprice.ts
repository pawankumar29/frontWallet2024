export interface GasPriceInterface {
    id: number,
    coin_family: number;
    safe_gas_price: number,
    propose_gas_price: number,
    fast_gas_price: number
}