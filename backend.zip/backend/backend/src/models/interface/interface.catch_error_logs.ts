export interface CatchErrorMsgsInterface {
    id: number;
    fx_name: string,
    error_msg: string | {} | null
}