export interface PriceAlertsInterface {
  id: number;
  fiat_type: string;
  percentage?: number | 0;
  price?: number;
  wallet_address: string;
  user_id?: number;
  price_in_usd_per_unit?: number | 0;
  status?: string;
  coin_id: number | undefined;
 }
