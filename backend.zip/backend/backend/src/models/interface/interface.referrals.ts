export interface ReferralInterface {
    id: number;
    referrer_from: number;
    referrer_to: number;
    referral_code: string;
    to_device_id: string;
}
