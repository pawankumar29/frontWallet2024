import { Request, Response, NextFunction } from "express";
import jwtHelper from "../helpers/common/jwt";
import response from "../helpers/response/response.helpers";
var CryptoJS = require("crypto-js");
import { config } from "../config";
import userhelper from "../modules/user/helper";
import { language } from "../constants";
import * as model from "../models/index";

class AdminMiddleware {
  public async maintenanceMode(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const method = req.method;

      // let flag = 0;
      // let status = 0;

      // if (req.originalUrl == `/api/v1/admin/auth/maintenance_mode`) {
      //   flag = 1;
      // }

      // if (req.originalUrl == `/api/v1/admin/auth/maintenance_mode_status`) {
      //   status = 1;
      // }

      const checkAdminMaintenanceMode = await model.AdminModel.findOne({});
      console.log(
        "checkAdminMaintenanceMode",
        checkAdminMaintenanceMode?.maintenance_mode
      );
      if (checkAdminMaintenanceMode?.maintenance_mode) {
        console.log("inside maintenance ");
        if (req.originalUrl.includes("admin")) {
          next();
        } else {
          return res.status(503).json({
            code: 503,
            message: "App is under Maintenance ",
          });
        }
      } else {
        next();
      }
    } catch (err: any) {
      console.error("ERROR IN Maintenance Server ");
      return response.error(res, {
        data: {
          message: language[lang].UNAUTHORIZED_ACCESS,
          data: err,
        },
      });
    }
  }
}

const serverMaintenance = new AdminMiddleware();
export default serverMaintenance;
