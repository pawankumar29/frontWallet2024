import express from "express";
import response from "../helpers/response/response.helpers";
import { validationResult } from "express-validator";
import { language } from "../constants";

export const validate = (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
): void => {
  let lang: any = req.headers['content-language'] || 'en';
  const errors = validationResult(req);
  console.log("errors validate:",errors)
  if (!errors.isEmpty()) {
    response.error(res, {
      data: { message: language[lang].VALIDATION_FAILED, data: errors },
    });
  }

  next();
};
