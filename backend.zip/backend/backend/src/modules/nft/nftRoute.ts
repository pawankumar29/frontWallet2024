import express from "express";
import { ControllerInterface } from "../../interfaces/controller.interface";
import jwtVerification from "../../middlewares/verify.middleware";
import { nftControllers } from "./controller.nft"
import { validate } from "express-validation"
import validator from "./../../middlewares/validator"

class NFTRoute implements ControllerInterface {
    public path = "/nft";
    public router = express.Router();

    constructor() {
        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router.post(`${this.path}/add`, jwtVerification.verifyToken, nftControllers.addNFTToken);
        this.router.get(`${this.path}/list`, jwtVerification.verifyToken, nftControllers.getNFTList);
        this.router.post(`${this.path}/gas-estimation`, jwtVerification.verifyToken, nftControllers.getGasEstimation);
        this.router.post(`${this.path}/addNFT`, jwtVerification.verifyToken, nftControllers.addNFT_Token);
    }

}

export default NFTRoute;
