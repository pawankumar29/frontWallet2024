import { String } from "aws-sdk/clients/cloudsearchdomain";
import Web3 from "web3";
import { AbiItem } from "web3-utils";
import { config } from "../../config";
import response from "../../helpers/response/response.helpers";
import { HelpersInterface } from "../../interfaces/helpers.interface";
import { Response } from "express";

class NFTHelpers implements HelpersInterface {
  public web3: Web3;
  public abi: AbiItem[] | string;
  public token_address: string | null | undefined;

  public bscWeb3: Web3;
  public bscAbi: AbiItem[] | string;
  public bscTokenAddress: string | null | undefined;

  constructor(abi: AbiItem[] | string = "", contractAddress: string = "") {
    var provider = new Web3.providers.HttpProvider(config.NODE.ETH_RPC_URL || "");
    this.web3 = new Web3(provider);
    this.abi = abi != "" ? abi : "";
    this.token_address = !contractAddress ? contractAddress : "";

    var bscProvider = new Web3.providers.HttpProvider(config.NODE.BNB_RPC_URL || "");
    this.bscWeb3 = new Web3(bscProvider);
    this.bscAbi = abi != "" ? abi : "";
    this.bscTokenAddress = !contractAddress ? contractAddress : "";

  }

  initialize() { }

  async getUserERC721TokenBalance(walletAddress: string, tokenAddress: string) {
    try {
      let contract = new this.web3.eth.Contract(
        config.ERC721ABI as AbiItem[],
        tokenAddress
      );
      const balance = await contract.methods.balanceOf(walletAddress).call();

      return balance;
    } catch (error) {
      console.error("getUserERC721TokenBalance catch error: ", error);
      return false;
    }
  }

  async getERC721ContractData(tokenAddress: string) {
    try {
      let contract = new this.web3.eth.Contract(
        config.ERC721ABI as AbiItem[],
        tokenAddress
      );
      const name = await contract.methods.name().call();
      const symbol = await contract.methods.symbol().call();
      if (name && symbol) {
        return { name, symbol };
      } else {
        return false;
      }
    } catch (error) {
      console.error("error error", error);
    }
  }

  async getTokenDetail(tokenId: String, tokenAddress: string) {
    let contract = new this.web3.eth.Contract(
      config.ERC721ABI as AbiItem[],
      tokenAddress
    );
    let tokenUri = "";
    let name = "";
    let symbol = "";
    tokenUri = await contract.methods.tokenURI(tokenId).call();
    name = await contract.methods.name().call();
    symbol = await contract.methods.symbol().call();
    return { tokenUri: tokenUri, name: name, symbol: symbol };
  }

  async checkTokenOwner(tokenId: number, tokenAddress: string) {
    try {
      let contract = new this.web3.eth.Contract(
        config.ERC721ABI as AbiItem[],
        tokenAddress
      );

      let ownerAddress = await contract.methods.ownerOf(tokenId).call();

      if (ownerAddress) {
        return ownerAddress;
      } else {
        return false;
      }
    } catch (error) {
      console.error("error", error);
    }
  }

  async getErc721TokenTransferGasEstimationCost(
    toAddress: string,
    fromAddress: string,
    tokenValue: string,
    tokenAddress: string
  ) {
    var nonce = await this.web3.eth.getTransactionCount(fromAddress, "pending");

    let contract = new this.web3.eth.Contract(
      config.ERC721ABI as AbiItem[],
      tokenAddress
    );
    let data = await contract.methods
      .transferFrom(fromAddress, toAddress, tokenValue)
      .encodeABI();

    var gasLimit = await this.web3.eth.estimateGas({
      from: fromAddress,
      nonce: nonce,
      to: tokenAddress,
      data: data,
    });

    return gasLimit * 2;
  }

  async getBEP721TokenDetail(tokenId: String, tokenAddress: string) {
    let contract = new this.bscWeb3.eth.Contract(
      config.ERC721ABI as AbiItem[],
      tokenAddress
    );
    let tokenUri = "";
    let name = "";
    let symbol = "";
    tokenUri = await contract.methods.tokenURI(tokenId).call();
    name = await contract.methods.name().call();
    symbol = await contract.methods.symbol().call();
    return { tokenUri: tokenUri, name: name, symbol: symbol };
  }

  async checkBEP721TokenOwner(tokenId: number, tokenAddress: string) {
    try {
      let contract = new this.bscWeb3.eth.Contract(
        config.ERC721ABI as AbiItem[],
        tokenAddress
      );

      let ownerAddress = await contract.methods.ownerOf(tokenId).call();

      if (ownerAddress) {
        return ownerAddress;
      } else {
        return false;
      }
    } catch (error) {
      console.error("error", error);
    }
  }

  async getBEP721TokenTransferGasEstimationCost(
    toAddress: string,
    fromAddress: string,
    tokenValue: string,
    tokenAddress: string
  ) {
    var nonce = await this.bscWeb3.eth.getTransactionCount(
      fromAddress,
      "pending"
    );

    let contract = new this.bscWeb3.eth.Contract(
      config.ERC721ABI as AbiItem[],
      tokenAddress
    );
    let data = await contract.methods
      .transferFrom(fromAddress, toAddress, tokenValue)
      .encodeABI();

    var gasLimit = await this.bscWeb3.eth.estimateGas({
      from: fromAddress,
      nonce: nonce,
      to: tokenAddress,
      data: data,
    });

    return gasLimit * 2;
  }

  async getBEP721ContractData(tokenAddress: string) {
    try {
      let contract = new this.bscWeb3.eth.Contract(
        config.ERC721ABI as AbiItem[],
        tokenAddress
      );
      const name = await contract.methods.name().call();
      const symbol = await contract.methods.symbol().call();
      if (name && symbol) {
        return { name, symbol };
      } else {
        return false;
      }
    } catch (error) {
      console.error("error error", error);
    }
  }

  async checkTokenData(tokenData: any, res: Response) {
    try {
      if (tokenData.coinFamily == config.STATIC_COIN_FAMILY.BNB) {
        let ownerAddress = await nftHelper.checkBEP721TokenOwner(
          tokenData.tokenId,
          tokenData.tokenAddress
        );


        if (ownerAddress.toLowerCase() != tokenData.walletAddress.toLowerCase()) {
          return response.error(res, {
            data: {
              status: false,
              message: "You are not the owner of this collectible.",
            },
          });
        }

        if (ownerAddress.toLowerCase() == tokenData.walletAddress.toLowerCase()) {
          let tokenDetail = await nftHelper.getBEP721TokenDetail(
            tokenData.tokenId.toString(),
            tokenData.tokenAddress
          );


          let contractData = (await nftHelper.getBEP721ContractData(
            tokenData.tokenAddress
          )) as { name: string; symbol: string };

          let data = { tokenDetail, contractData }
          return data

        }
      } else {
        let ownerAddress = await nftHelper.checkTokenOwner(
          tokenData.tokenId,
          tokenData.tokenAddress
        );


        if (ownerAddress.toLowerCase() != tokenData.walletAddress.toLowerCase()) {
          return response.error(res, {
            data: {
              status: false,
              message: "You are not the owner of this collectible.",
            },
          });
        }

        if (ownerAddress.toLowerCase() == tokenData.walletAddress.toLowerCase()) {
          let tokenDetail = await nftHelper.getTokenDetail(
            tokenData.tokenId.toString(),
            tokenData.tokenAddress
          );


          let contractData = (await nftHelper.getERC721ContractData(
            tokenData.tokenAddress
          )) as { name: string; symbol: string };


          let data = { tokenDetail, contractData }
          return data
        }

      }
    } catch (error) {
      console.error("error error", error);
    }
  }

}

export const nftHelper = new NFTHelpers();
