import axios from "axios";
import { Request, Response } from "express";
import response from "../../helpers/response/response.helpers";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import { NFTInterface } from "../../models/interface/interface.nft";
import { nftHelper } from "./helper.nft";
import _ from "lodash";
import { QueryTypes } from "sequelize";
import db from "../../helpers/common/db";
import redisHelper from "../../helpers/common/redis";
import { config } from "../../config";
import * as Models from '../../models/model/index';

class NFTController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() { }
  public async addNFTToken(req: Request, res: Response) {
    const userId = req.userId;
    let {
      tokenId,
      tokenAddress,
      coinFamily,
      walletAddress,
    }: {
      tokenId: number;
      walletAddress: string;
      tokenAddress: string;
      coinFamily: number;
      name: string;
      symbol: string;
      image: string;
      description: string;
    } = req.body;

    try {
      let tokenNftExist = await Models.NFTModelModel.findOne({
        attributes: ["id", "user_id", "token_id"],
        where: {
          token_address: tokenAddress,
          token_id: tokenId,
          user_id: userId,
          coin_family: coinFamily,
        },
      });

      if (tokenNftExist) {
        return response.error(res, {
          data: {
            status: false,
            message: "This collectable already exists.",
          },
        });
      }

      if (coinFamily == config.STATIC_COIN_FAMILY.BNB) {
        let ownerAddress = await nftHelper.checkBEP721TokenOwner(
          tokenId,
          tokenAddress
        );

        if (ownerAddress.toLowerCase() != walletAddress.toLowerCase()) {
          return response.error(res, {
            data: {
              status: false,
              message: "You are not the owner of this collectible.",
            },
          });
        }

        if (ownerAddress.toLowerCase() == walletAddress.toLowerCase()) {
          let tokenDetail = await nftHelper.getBEP721TokenDetail(
            tokenId.toString(),
            tokenAddress
          );
        

          let contractData = (await nftHelper.getBEP721ContractData(
            tokenAddress
          )) as { name: string; symbol: string };
         

          const coin = await Models.CoinsModel.findOne({
            where: {
              token_address: tokenAddress,
              coin_family: coinFamily,
            },
          });
        

          const splitData = tokenDetail.tokenUri.split("ipfs://");

          const result = await axios.get(
            splitData[1]
              ? `https://ipfs.io/ipfs/${splitData[1]}`
              : tokenDetail.tokenUri
          );

          let tokenImage = null;
          let tokenDescription = null;

          if (result && result.data && result.data.image) {
            const splitDataImageDa = result.data.image.split("ipfs://");
            tokenImage = splitDataImageDa[1]
              ? `https://ipfs.io/ipfs/${splitDataImageDa[1]}`
              : result.data.image;
            tokenDescription = result.data.description;
          } else {
            tokenImage = splitData[1] ? tokenDetail.tokenUri.replace("ipfs://", "https://ipfs.io/ipfs/") : tokenDetail.tokenUri;
          }


          if (!coin) {
            await Models.CoinsModel.create({
              coin_name: contractData.name,
              coin_symbol: contractData.symbol.toLowerCase(),
              coin_image: null,
              coin_gicko_alias: "",
              coin_family: coinFamily,
              coin_status: 1,
              is_token: 1,
              token_type: "BEP721",
              decimals: 0,
              token_address: tokenAddress,
              created_at: Date.now().toLocaleString(),
              updated_at: Date.now().toLocaleString(),
            });

            var query = `SELECT coin_symbol,token_address, decimals FROM coins WHERE is_token=1 AND coin_status=1 AND coin_family = :coin_family AND token_type LIKE 'BEP721'`;

            var tokensList = await db.db_read.query(query, {
              type: QueryTypes.SELECT,
              replacements: {
                coin_family: config.STATIC_COIN_FAMILY.BNB,

              },
            });
            await redisHelper.setRedisSting(
              "bep721Tokens",
              JSON.stringify(tokensList)
            );


            const nftTokenData: NFTInterface = {
              coin_id: 1,
              user_id: userId,
              wallet_address: walletAddress,
              token_id: tokenId.toString(),
              token_address: tokenAddress,
              coin_family: coinFamily,
              image: tokenImage,
              description: tokenDescription,
              token_uri: tokenDetail.tokenUri,
              name: tokenDetail.name,
              available: 1,
            };
           

            const writtenData = await Models.NFTModelModel.create(
              nftTokenData
            );

            return response.success(res, { data: writtenData });
          } else {
            /*const splitData = tokenDetail.tokenUri.split("ipfs://");

            const result = await axios.get(
              splitData[1]
                ? `https://ipfs.io/ipfs/${splitData[1]}`
                : tokenDetail.tokenUri
            );

            const splitData1 = result.data.image.split("ipfs://");

            const tokenImage = splitData1[1]
              ? `https://ipfs.io/ipfs/${splitData1[1]}`
              : result.data.image;

            const tokenDescription = result.data.description;*/

            const nftTokenData: NFTInterface = {
              coin_id: 1,
              user_id: userId,
              wallet_address: walletAddress,
              token_id: tokenId.toString(),
              token_address: tokenAddress,
              coin_family: coinFamily,
              image: tokenImage,
              description: tokenDescription,
              token_uri: tokenDetail.tokenUri,
              name: tokenDetail.name,
              available: 1,
            };

            

            const writtenData = await Models.NFTModelModel.create(
              nftTokenData
            );

            return response.success(res, { data: writtenData });
          }
        }
      } else {
        let ownerAddress = await nftHelper.checkTokenOwner(
          tokenId,
          tokenAddress
        );
      

        if (ownerAddress.toLowerCase() != walletAddress.toLowerCase()) {
          return response.error(res, {
            data: {
              status: false,
              message: "You are not the owner of this collectible.",
            },
          });
        }

        if (ownerAddress.toLowerCase() == walletAddress.toLowerCase()) {
          let tokenDetail = await nftHelper.getTokenDetail(
            tokenId.toString(),
            tokenAddress
          );
       

          let contractData = (await nftHelper.getERC721ContractData(
            tokenAddress
          )) as { name: string; symbol: string };
        

          // const splitData = tokenDetail.tokenUri.split('ipfs://');

          // const result = await axios.get(
          //   splitData[1]
          //     ? `https://ipfs.io/ipfs/${splitData[1]}`
          //     : tokenDetail.tokenUri
          // );

        

          const coin = await Models.CoinsModel.findOne({
            where: {
              token_address: tokenAddress,
              coin_family: coinFamily,
            },
          });
       
          const splitData = tokenDetail.tokenUri.split("ipfs://");

          const result = await axios.get(
            splitData[1]
              ? `https://ipfs.io/ipfs/${splitData[1]}`
              : tokenDetail.tokenUri
          );

          let tokenImage = null;
          let tokenDescription = null;

          if (result && result.data && result.data.image) {
            const splitDataImageDa = result.data.image.split("ipfs://");
            tokenImage = splitDataImageDa[1]
              ? `https://ipfs.io/ipfs/${splitDataImageDa[1]}`
              : result.data.image;
            tokenDescription = result.data.description;
          } else {
            tokenImage = splitData[1] ? tokenDetail.tokenUri.replace("ipfs://", "https://ipfs.io/ipfs/") : tokenDetail.tokenUri;
          }


          if (!coin) {
            await Models.CoinsModel.create({
              coin_name: contractData.name,
              coin_symbol: contractData.symbol.toLowerCase(),
              coin_image: null,
              coin_gicko_alias: "",
              coin_family: 1,
              coin_status: 1,
              is_token: 1,
              token_type: "ERC721",
              decimals: 0,
              token_address: tokenAddress,
              created_at: Date.now().toLocaleString(),
              updated_at: Date.now().toLocaleString(),
            });

            var query = `SELECT coin_symbol,token_address, decimals FROM coins WHERE is_token=1 AND coin_status=1 AND coin_family=1 AND token_type LIKE 'ERC721'`;

            var tokensList = await db.db_read.query(query, {
              type: QueryTypes.SELECT,
            });
            await redisHelper.setRedisSting(
              "erc721Tokens",
              JSON.stringify(tokensList)
            );

            // const splitData = tokenDetail.tokenUri.split("ipfs://");

            // const result = await axios.get(
            //   splitData[1]
            //     ? `https://ipfs.io/ipfs/${splitData[1]}`
            //     : tokenDetail.tokenUri
            // );
            // const tokenImage = result.data.image;
            // const tokenDescription = result.data.description;

            const nftTokenData: NFTInterface = {
              coin_id: 2,
              user_id: userId,
              wallet_address: walletAddress,
              token_id: tokenId.toString(),
              token_address: tokenAddress,
              coin_family: coinFamily,
              image: tokenImage,
              description: tokenDescription,
              token_uri: tokenDetail.tokenUri,
              name: tokenDetail.name,
            };
           

            const writtenData = await Models.NFTModelModel.create(
              nftTokenData
            );

            return response.success(res, { data: writtenData });
          } else {
            // const splitData = tokenDetail.tokenUri.split("ipfs://");

            // const result = await axios.get(
            //   splitData[1]
            //     ? `https://ipfs.io/ipfs/${splitData[1]}`
            //     : tokenDetail.tokenUri
            // );
            // const tokenImage = result.data.image;
            // const tokenDescription = result.data.description;

            const nftTokenData: NFTInterface = {
              coin_id: 2,
              user_id: userId,
              wallet_address: walletAddress,
              token_id: tokenId.toString(),
              token_address: tokenAddress,
              coin_family: coinFamily,
              image: tokenImage,
              description: tokenDescription,
              token_uri: tokenDetail.tokenUri,
              name: tokenDetail.name,
            };

          
            const writtenData = await Models.NFTModelModel.create(
              nftTokenData
            );

            let data = {
              data: writtenData,
              status: true,
              code: 200,
              message: "Success",
            };
            return res.status(data.code).send(data);
          }
        }
      }
    } catch (error:any) {
      console.error("catch error addBSCNFTToken :", error);

      response.error(res, {
        data: {
          message: "Something went wrong.",
        },
      });
    }
  };

  public async getNFTList(req: Request, res: Response) {
    const walletAddress = req.query.walletAddress as string;
    try {
      // const data = await NFTModel.NFTModelRead.findAll({
      //   where: {
      //     wallet_address: walletAddress,
      //   },
      //   raw: true,
      // });
      // const tokenAddresses = data.map((el) => el.token_address);
   
      // const freshData = Array.from(new Set(tokenAddresses));
   
      // const finalData = [];
      // const coins = await Coins.CoinsRead.findAll({
      //   where: {
      //     token_address: {
      //       [Op.or]: freshData,
      //     },
      //   },
      // });
      // for await (let address of freshData) {
      //   const coin = coins.find((el) => el.token_address === address);
      //   const nft = data.find((el) => el.token_address === address);
      //   if (nft && coin) {
      //     const mappedData = {
      //       description: nft.description,
      //       name: coin.coin_name,
      //       symbol: coin.coin_symbol,
      //       created_at: coin.created_at,
      //       nfts: data.filter((el) => {
      //         if (el.token_address === address) {
      //           return el;
      //         }
      //       }),
      //     };
   
      //     finalData.push(mappedData);
      //   }
      // }
      // response.success(res, { data: finalData });
      let paging;
      let pages = 0;
      let nfts;
      if (
        req.query.perPage &&
        req.query.page &&
        req.query.page !== "" &&
        req.query.perPage !== ""
      ) {
        nfts = await Models.NFTModelModel.findAndCountAll({
          attributes: [
            "id",
            "token_id",
            "wallet_address",
            "name",
            "token_uri",
            "image",
            "description",
            "created_at",
          ],
          include: [
            {
              model: Models.CoinsModel,
              attributes: ["coin_image", "token_address", "coin_symbol"],
              required: false,
              as: "coinData",
            },
          ],
          where: {
            wallet_address: walletAddress,
          },
          order: [[req.query.sortBy as string, req.query.order as string]],
          limit: parseInt(req.query.perPage as string),
          offset:
            (parseInt(req.query.page.toString()) - 1) *
            parseInt(req.query.perPage.toString()),
        });
      } else {
        nfts = await Models.NFTModelModel.findAndCountAll({
          attributes: [
            "id",
            "token_id",
            "wallet_address",
            "name",
            "token_uri",
            "image",
            "description",
            "created_at",
          ],
          include: [
            {
              model: Models.CoinsModel,
              attributes: ["coin_image", "token_address", "coin_symbol"],
              required: false,
              as: "coinData",
            },
          ],
          where: {
            wallet_address: walletAddress,
          },
        });
      }

      let returnOp = {
        status: true,
        statusCode: 200,
        message: "Nft token listed get successfully",
        data: nfts.rows,
        meta: {
          field: req.query.sortBy,
          page: req.query.page,
          pages: pages,
          perPage: req.query.perPage,
          sort: req.query.order,
        },
      };
      return res.json(returnOp);
    } catch (error) {
      response.error(res, { data: "Something went wrong" });
    }
  };

  public async getGasEstimation(req: Request, res: Response) {
    const { toAddress, fromAddress, tokenValue, tokenAddress } = req.body;
    try {
      const gasEstimation =
        await nftHelper.getErc721TokenTransferGasEstimationCost(
          toAddress,
          fromAddress,
          tokenValue,
          tokenAddress
        );

      response.success(res, { data: { gasEstimation } });
    } catch (error) {
      response.error(res, { data: "Something went wrong" });
    }
  };


  public async addNFT_Token(req: Request, res: Response) {
    const userId = req.userId;
    let {
      tokenId,
      tokenAddress,
      coinFamily,
      walletAddress,
    }: {
      tokenId: number;
      walletAddress: string;
      tokenAddress: string;
      coinFamily: number;
      name: string;
      symbol: string;
      image: string;
      description: string;
    } = req.body;

    try {
      let tokenNftExist = await Models.NFTModelModel.findOne({
        attributes: ["id", "user_id", "token_id"],
        where: {
          token_address: tokenAddress,
          token_id: tokenId,
          user_id: userId,
          coin_family: coinFamily,
        },
      });

      if (tokenNftExist) {
        return response.error(res, {
          data: {
            status: false,
            message: "This collectable already exists.",
          },
        });
      }
      let tokenData = {
        coinFamily,
        tokenId,
        tokenAddress,
        walletAddress
      }
      let check_token_data: any = await nftHelper.checkTokenData(tokenData, res);
      const coin = await Models.CoinsModel.findOne({
        where: {
          token_address: tokenAddress,
          coin_family: coinFamily,
        },
      });
   
      const splitData = check_token_data?.tokenDetail.tokenUri.split("ipfs://");

      let splitDataUrl = splitData[1] ? `https://ipfs.io/ipfs/${splitData[1]}` : check_token_data?.tokenDetail.tokenUri;


      const result = await axios.get(splitDataUrl).then((result) => {
        return result;
      }).catch((error) => {
        console.error('axios error >>>>', error);
        return null;
      });

      let tokenImage = null;
      let tokenDescription = null;

      if (result && result.data && result.data.image) {
        const splitDataImageDa = result.data.image.split("ipfs://");
        tokenImage = splitDataImageDa[1]
          ? `https://ipfs.io/ipfs/${splitDataImageDa[1]}`
          : result.data.image;
        tokenDescription = result.data.description;
      } else {
        tokenImage = splitData[1] ? check_token_data.tokenDetail.tokenUri.replace("ipfs://", "https://ipfs.io/ipfs/") : check_token_data.tokenDetail.tokenUri;
      }
      if (!coin) {
        await Models.CoinsModel.create({
          coin_name: check_token_data.contractData.name,
          coin_symbol: check_token_data.contractData.symbol.toLowerCase(),
          coin_image: null,
          coin_gicko_alias: "",
          coin_family: coinFamily,
          coin_status: 1,
          is_token: 1,
          token_type: coinFamily == 1 ? "BEP721" : "ERC721",
          decimals: 0,
          token_address: tokenAddress,
          created_at: Date.now().toLocaleString(),
          updated_at: Date.now().toLocaleString(),
        });
        let findCoin = await Models.CoinsModel.findOne({
          attributes: ['coin_symbol', 'token_address', 'decimals'],
          where: {
            is_token: 1,
            coin_status: 1,
            coin_family: coinFamily == 1 ? config.STATIC_COIN_FAMILY.BNB : config.STATIC_COIN_FAMILY.ETH,
            token_type: coinFamily == 1 ? 'BEP721' : 'ERC721'
          },
          raw: true
        })
        let string = coinFamily == 1 ? "bep721Tokens" : "erc721Tokens";
        await redisHelper.setRedisSting(string,
          JSON.stringify(findCoin)
        );
      }
      const nftTokenData: NFTInterface = {
        coin_id: coinFamily == 1 ? 1 : 2,
        user_id: userId,
        wallet_address: walletAddress,
        token_id: tokenId.toString(),
        token_address: tokenAddress,
        coin_family: coinFamily,
        image: tokenImage,
        description: tokenDescription,
        token_uri: check_token_data.tokenDetail.tokenUri,
        name: check_token_data.tokenDetail.name,
        available: 1,
      };
   
      const writtenData = await Models.NFTModelModel.create(
        nftTokenData
      );
      let data = {
        data: writtenData,
        status: true,
        code: 200,
        message: "Success",
      };
      return res.status(data.code).send(data);
    } catch (error) {
      console.error("catch error addBSCNFTToken :", error);

      response.error(res, {
        data: {
          message: "Something went wrong.",
        },
      });
    }
  };
}

export const nftControllers = new NFTController();
