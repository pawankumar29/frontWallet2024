import express from 'express';
import { validate as validateExpress } from "express-validation"
import { ControllerInterface } from '../../interfaces/controller.interface';
import jwtVerification from '../../middlewares/verify.middleware';
import validator from "../../middlewares/validator"
import { transactController } from './controller';

class TransactRoute implements ControllerInterface {
    public path = '/on_off_ramp';
    public router = express.Router();

    constructor() {
        this.initializeRoutes();
    }

    public initializeRoutes() {
        // 1 transak add than alchemy add 
        // this.router.post(`${this.path}/add_transact_fiats`, transactController.add_transact_fiats);
        // this.router.post(`${this.path}/add_alchemy_fiats`, transactController.add_alchemy_fiats);
        this.router.post(`${this.path}/fiat_list`, [validateExpress(validator.on_of_ramp_fiat_list)], jwtVerification.verifyToken, transactController.get_fiat_list); // fiat list from db
        // this.router.post(`${this.path}/fetch_price`, [validateExpress(validator.fetch_price)], jwtVerification.verifyToken, transactController.fetch_price);
        this.router.post(`${this.path}/initiateTx`, [validateExpress(validator.initiateTx)], jwtVerification.verifyToken, transactController.initiate_txn);
        this.router.post(`${this.path}/transak_webhook`, transactController.transak_webhook);
        // this.router.post(`${this.path}/alchemy_webhook`, transactController.alchemy_webhook);
        // this.router.get(`${this.path}/alchemy_webhook`, transactController.alchemy_webhook); // Not used
        /** Old alchemy flow save trnx */
        // this.router.post(`${this.path}/alchemy/initaiteTx`, transactController.initaiteTx);

    }
}
export default TransactRoute;
