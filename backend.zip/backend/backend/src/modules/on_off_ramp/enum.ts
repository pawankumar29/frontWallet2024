export enum Messages {
  TRNX_UPDATED = 'Transaction updated successfully.',
  CHECK_URL = 'Check TRANSACT_BASE_URL and FIAT.',
  CHECK_ALCHEMY_URL='Check CHECK_ALCHEMY_URL and FIAT.',
  DONE = 'Successfully Done.'
}
export enum TYPE {
  BUY = 'BUY',
  SELL = 'SELL'
}
export enum Blockchains {
  eth = "ethereum",
  matic = "polygon",
  bitcoin = "Bitcoin",
  btc = "BTC",
  trx = "tron"
}
export enum TxReqTypesEnum {
  APP = 'APP',
  EXNG = 'EXNG',
  TRANSAK = 'TRANSAK',
  ALCHEMY = 'ALCHEMY',
  NOTPRESET = 'NOT_PRESENT'
}