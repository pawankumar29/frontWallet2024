import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from '../../models/model/index';
import axios from "axios";
import { GlblBlockchainTxStatusEnum, GlblCode, GlblMessages, GlblStatus } from "../../constants/global_enum";
import { Messages, TYPE, TxReqTypesEnum } from "./enum";
import { OnOffRampHelpers } from "./helper";
import { Op, Sequelize } from "sequelize";
import { config } from "../../config/config";
import jwt from "jsonwebtoken";
import moment from "moment";
import { language } from "../../constants";
import commonHelper from "../../helpers/common/common.helpers";
class TransactController implements OnlyControllerInterface {

    constructor() {
        this.initialize();
    }

    public initialize() { }
    // public async add_transact_fiats(req: Request, res: Response) {
    //     try {
    //         console.log("Entered into add_transact_fiats>>>")
    //         let config_url: any = {
    //             method: 'get',
    //             url: `${config.TRANSAK.TRANSAK_URL}${config.TRANSAK.TRANSAK_FIAT_CURRENCIES_URL}`,
    //             headers: {}
    //         }
    //         await axios(config_url).then(async (response) => {
    //             let result: any = response.data.response
    //             for (let i: number = 0; i < result.length; i++) {
    //                 let check_fiat_exist: any = await OnOffRampHelpers.check_transak_fiat_exist({ fiat_currency: result[i].symbol })
    //                 if (!check_fiat_exist) {
    //                     if (result[0].supportingCountries) {
    //                         for (let j: number = 0; j < result[i].supportingCountries.length; j++) {
    //                             let check_supporting_countries_and_symbol: any = await OnOffRampHelpers.check_transak_fiat_exist({ country_code: result[i].supportingCountries[j], fiat_currency: result[i].symbol })
    //                             if (!check_supporting_countries_and_symbol) {
    //                                 let country_name: any = await OnOffRampHelpers.get_country_name(result[i].supportingCountries[j])
    //                                 const filterPaymentOptions: any = result[i].paymentOptions.map((option: any) => ({ id: option.id, name: option.name, displayMessage: option.displayMessage ? option.displayMessage : null, processingTime: option.processingTime, minAmount: option.minAmount, maxAmount: option.maxAmount, icon: option.icon }))
    //                                 await Models.OnOffRampFiatsModel.create({
    //                                     country_name: country_name,
    //                                     country_code: result[i].supportingCountries[j],
    //                                     fiat_currency: result[i].symbol,
    //                                     transak_payment_detials: filterPaymentOptions
    //                                 })
    //                             } else {
    //                                 console.log("supporting country and country symbol exist")
    //                             }
    //                         }
    //                     } else {
    //                         console.log("No supportiung countries")
    //                     }
    //                 } else {
    //                     console.log("This fiat symbol exist>>>> ")
    //                 }
    //             }
    //         }).catch(err => {
    //             console.error("Error in axios >> add_transact_fiats.", err)
    //             return res.status(GlblCode.ERROR_CODE).send({
    //                 status: false,
    //                 code: GlblCode.ERROR_CODE,
    //                 message: GlblMessages.CATCH_MSG,
    //             });
    //         })
    //         return res.status(GlblCode.SUCCESS).send({
    //             status: true,
    //             code: GlblCode.SUCCESS,
    //             message: GlblMessages.SUCCESS,
    //         });
    //     } catch (err: any) {
    //         console.error("Error in add_transact_fiats>>", err)
    //         await commonHelper.save_error_logs({ fx_name: "add_transact_fiats", error_msg: err.message })
    //         return res.status(GlblCode.ERROR_CODE).send({
    //             status: false,
    //             code: GlblCode.ERROR_CODE,
    //             message: GlblMessages.CATCH_MSG,
    //         });
    //     }

    // }
    // public async add_alchemy_fiats(req: Request, res: Response) {
    //     try {
    //         console.log("Entered into add_alchemy_alchemy>>>")
    //         let headers: any = {
    //             appId: config.APP_ID,
    //             timestamp: new Date().getTime(),
    //         };
    //         const signature = await OnOffRampHelpers.alchemySign(headers.timestamp);
    //         (headers as any).sign = signature;
    //         let result: any;
    //         let result1: any;
    //         await axios.get(`${config.ALCHEMY_BASE_URL}/merchant/fiat/list?type=BUY`, { headers: headers }).then(response => {
    //             result = response;
    //         }).catch(err => {
    //             console.error("Error in add_alchemy_alchemy.", err)
    //             let data = {
    //                 status: false,
    //                 code: GlblCode.ERROR_CODE,
    //                 message: Messages.CHECK_ALCHEMY_URL
    //             };
    //             return res.status(data.code).send(data);
    //         })
    //         await axios.get(`${config.ALCHEMY_BASE_URL}/merchant/fiat/list?type=SELL`, { headers: headers }).then(response => {
    //             result1 = response;
    //         }).catch(err => {
    //             console.error("Error in add_alchemy_alchemy.", err)
    //             let data = {
    //                 status: false,
    //                 code: GlblCode.ERROR_CODE,
    //                 message: Messages.CHECK_ALCHEMY_URL
    //             };
    //             return res.status(data.code).send(data);
    //         })
    //         let groupedData: any;
    //         let data;
    //         if (result.data.returnCode == "0000" && result1.data.returnCode == "0000") {
    //             let obj: any = result.data.data;
    //             obj = obj.concat(result1.data.data)
    //             // console.log("object>>>>",obj)
    //             let groupedArray: any = await OnOffRampHelpers.get_grouped_data_alchemy(obj)
    //             // console.log("groupedArray>>", groupedArray)
    //             for (let i: number = 0; i < groupedArray.length; i++) {
    //                 let check_exit: any = await OnOffRampHelpers.checkAlchemyFiatExit({ country_name: groupedArray[i].countryName, country_code: groupedArray[i].country, fiat_currency: groupedArray[i].currency, })
    //                 if (!check_exit) {
    //                     await Models.OnOffRampFiatsModel.create({
    //                         country_name: groupedArray[i].countryName,
    //                         country_code: groupedArray[i].country,
    //                         fiat_currency: groupedArray[i].currency,
    //                         alchemy_payment_details: groupedArray[i].items
    //                     })
    //                 } else {
    //                     await Models.OnOffRampFiatsModel.update({ alchemy_payment_details: groupedArray[i].items }, { where: { country_name: groupedArray[i].countryName, country_code: groupedArray[i].country, fiat_currency: groupedArray[i].currency, } })
    //                     console.log("IT exist>>")
    //                 }
    //             }
    //         }
    //         data = {
    //             data: groupedData,
    //             status: true,
    //             code: GlblCode.SUCCESS,
    //             message: result.data.returnMsg,
    //         };
    //         return res.status(data.code).send(data);

    //     } catch (err: any) {
    //         console.error("Error in add_transact_fiats>>", err)
    //         await commonHelper.save_error_logs({ fx_name: "add_alchemy_fiats", error_msg: err.message })
    //         return res.status(GlblCode.ERROR_CODE).send({
    //             status: false,
    //             code: GlblCode.ERROR_CODE,
    //             message: GlblMessages.CATCH_MSG,
    //         });
    //     }

    // }
    public async get_fiat_list(req: Request, res: Response) {
        let lang: any = req.headers['content-language'] || 'en';
        try {
            console.log("Entered into get_fiat_list>>>")
            let search: string | null = req.body.search;
            let where_clause: any;
            if (search) {
                search = (req.body.search = "%" + req.body.search + "%");
                where_clause = {
                    ...where_clause, [Op.or]: [
                        { country_name: { [Op.like]: search } },
                        { country_code: { [Op.like]: search } },
                        { fiat_currency: { [Op.like]: search } },
                    ]
                };
            }
            let fiat_data: any = await Models.OnOffRampFiatsModel.findAll({
                attributes: ["id", "country_name", "country_code", "fiat_currency", "alchemy_payment_details", "transak_payment_detials"],
                where: where_clause,
                order: [
                    Sequelize.literal(`CASE WHEN fiat_currency = 'USD' THEN 0 WHEN fiat_currency = 'EUR' THEN 1 ELSE 2 END`),
                ],
            })
            let data: any;
            if (fiat_data) {
                data = {
                    status: true,
                    length: fiat_data.length,
                    code: GlblCode.SUCCESS,
                    data: fiat_data,
                    message: language[lang].SUCCESS
                };
            } else {
                data = {
                    status: false,
                    code: GlblCode.ERROR_CODE,
                    data: {},
                    message: language[lang].FAILED
                };
            }
            return res.status(data.code).send(data);

        } catch (err: any) {
            console.error("Error in get_fiat_list>>", err)
            await commonHelper.save_error_logs("on_off_ramp_get_fiat_list", err.message);
            return res.status(GlblCode.ERROR_CODE).send({
                status: false,
                code: GlblCode.ERROR_CODE,
                message: language[lang].CATCH_MSG
            });
        }

    }
    public async fetch_price(req: Request, res: Response) {
        let lang: any = req.headers['content-language'] || 'en';
        try {
            console.log("Entered into fetch_price>>>")
            let transak_response_data: any = await OnOffRampHelpers.fetch_data(`${config.TRANSAK.TRANSAK_URL}${config.TRANSAK.TRANSAK_FETCH_PRICE_URL}${req.body?.transak_url}`)
            console.log("transak>>>>", transak_response_data)
            /*let headers = {
                appId: config.ALCHEMY.APP_ID,
                timestamp: new Date().getTime(),
            };
            const params: any = {
                crypto: req.body.crypto,
                fiat: req.body.fiat,
                amount: req.body.amount,
                side: req.body.side,
                network: req.body.network
            };
            console.log("data>>>>>>")
            if (req.body.side == TYPE.BUY) {
                params.country = req.body.country,
                    params.payWayCode = req.body.payWayCode
            }
            const signature = await OnOffRampHelpers.alchemySign(headers.timestamp);
            (headers as any).sign = signature;
            let alchemy_response_data: any = await OnOffRampHelpers.post_data('post', `${config.ALCHEMY.ALCHEMY_BASE_URL}/merchant/order/quote`, headers, params)
            console.log("alchemy_response_data>>>>", alchemy_response_data)*/
            let data: any = {
                status: true,
                code: GlblCode.SUCCESS,
                message: language[lang].SUCCESS,
                data: {
                    transak: transak_response_data,
                    // alchemy: alchemy_response_data
                }
            };
            return res.status(data.code).send(data);

        } catch (err: any) {
            console.error("Error in fetch_price>>", err)
            await commonHelper.save_error_logs("on_off_ramp_fetch_price", err.message);
            return res.status(GlblCode.ERROR_CODE).send({
                status: false,
                code: GlblCode.ERROR_CODE,
                message: language[lang].CATCH_MSG
            });
        }

    }
    public async initiate_txn(req: Request, res: Response) {
        let lang: any = req.headers['content-language'] || 'en';
        try {
            console.log("Entered into transak_initiate_txn>>>")
            let { ramp_type, coin_id, coin_family, tx_type, wallet_address, amount, fiat_price, fiat_type, merchant_id, order_id, alchemy_order_id }: { ramp_type: string, coin_id: number, coin_family: number, tx_type: string, wallet_address: string, amount: number, fiat_price: number, fiat_type: string, merchant_id: string, order_id: string | null, alchemy_order_id: string | null } = req.body;
            const user_id: number = req.userId;
            let obj: any = {
                user_id: user_id,
                coin_id: coin_id,
                coin_family: coin_family,
                type: tx_type.toLowerCase(),
                to_adrs: wallet_address,
                status: GlblBlockchainTxStatusEnum.PENDING,
                blockchain_status: GlblBlockchainTxStatusEnum.PENDING,
                amount: amount,
                fiat_price: fiat_price,
                fiat_type: fiat_type,
                merchant_id: merchant_id,
                order_id: order_id ? order_id : null,
                alchemy_order_id: alchemy_order_id ? alchemy_order_id : null,
                to_user_id: 0
            }
            obj.req_type = (ramp_type == TxReqTypesEnum.TRANSAK) ? TxReqTypesEnum.TRANSAK : (ramp_type == TxReqTypesEnum.ALCHEMY) ? TxReqTypesEnum.ALCHEMY : TxReqTypesEnum.NOTPRESET
            let check_history_exist: any = await Models.TrnxHistoryModel.findOne({
                attributes: ["id", "tx_id"],
                where: {
                    req_type: obj.req_type,
                    order_id: order_id
                },
                raw: true
            })
            if (!check_history_exist) {
                await Models.TrnxHistoryModel.create(obj)
            }
            let data: any = {
                status: true,
                code: GlblCode.SUCCESS,
                message: language[lang].INITIATE_TXN_CREATED
            };
            return res.status(data.code).send(data);

        } catch (err: any) {
            console.error("Error in transak_initiate_txn>>", err)
            await commonHelper.save_error_logs("on_off_ramp_initiate_txn", err.message);
            return res.status(GlblCode.ERROR_CODE).send({
                status: false,
                code: GlblCode.ERROR_CODE,
                message: language[lang].CATCH_MSG
            });
        }

    }
    public async transak_webhook(req: Request, res: Response) {
        try {
            let token: any;
            let webhook: any = req.body;
            if (webhook) {
                await Models.OnOffRampWebhookModel.create({
                    ramp_type: TxReqTypesEnum.TRANSAK,
                    encoded_webhook: webhook,
                    created_at: new Date(),
                    updated_at: new Date()
                })
                let transak_data: any = await Models.SettingsModel.findOne({
                    attributes: ["value", "created_at", "updated_at"],
                    where: { title: TxReqTypesEnum.TRANSAK },
                    raw: true
                })
                if (!transak_data) {
                    console.log(" no transak_data in setting tabe >>>>")
                    token = await OnOffRampHelpers.create_access_token()
                    await Models.SettingsModel.create({
                        title: TxReqTypesEnum.TRANSAK,
                        value: token,
                        created_at: new Date(),
                        updated_at: new Date()
                    })
                } else {
                    let updated_date: any = moment(transak_data.updated_at)
                    let current_data: any = moment(new Date());
                    let blockDiff: number = Math.abs(updated_date.diff(current_data, 'days'))
                    console.log(blockDiff)
                    if (blockDiff <= 5) {
                        console.log("Block difference is smaller than or equal to 5 days.")
                        token = transak_data?.value
                    } else {
                        console.log("Block difference is more than 5 days.")
                        token = await OnOffRampHelpers.create_access_token()
                        await Models.SettingsModel.update({ value: token, updated_at: new Date() }, { where: { title: TxReqTypesEnum.TRANSAK } })
                    }
                }
                let webhookData: any = jwt.verify(req.body.data, token)
                if (webhookData) {
                    let data: any = webhookData.webhookData;
                    await Models.OnOffRampWebhookModel.update({
                        webhook_id: webhookData.webhookData?.id,
                        webhook: webhookData,
                        status: webhookData.webhookData?.status,
                        updated_at: new Date()
                    }, {
                        where: {
                            ramp_type: TxReqTypesEnum.TRANSAK,
                            encoded_webhook: webhook
                        }
                    })
                    console.log("exit into webhookData>>")

                    if (data) {
                        console.log("transak webhook data.status >>>>", data.status, "partnerOrderId >>>>", data?.partnerOrderId, "data?.orderId >>", data?.id)
                        let status: string = 'pending';
                        // console.log("data>>>>", data)
                        if (data.status != undefined) {
                            status = (data.status == 'COMPLETED') ? 'completed' : (data.status == 'FAILED' || data.status == 'EXPIRED' || data.status == 'CANCELLED') ? 'failed' : 'pending';
                        }
                        if (status == 'completed' || status == 'failed') {
                            console.log("status == completed || status == failed>> order id", data?.id)
                            await Models.TrnxHistoryModel.update({
                                merchant_id: data?.partnerOrderId,
                                amount: data?.cryptoAmount,
                                type: data?.isBuyOrSell.toLowerCase(),
                                fiat_price: data?.fiatAmount,
                                fiat_type: data?.fiatCurrency,
                                tx_id: data?.transactionHash ? data.transactionHash : null,
                                status: status,
                                blockchain_status: (status == GlblStatus.COMPLETED) ? GlblBlockchainTxStatusEnum.CONFIRMED : GlblBlockchainTxStatusEnum.FAILED
                            }, {
                                where: { order_id: data?.id },
                                logging: true
                            })
                        } else {
                            console.log("no statuscompleted || status == failed>> order id", data?.id)
                        }


                        return res.status(GlblCode.SUCCESS).send({
                            status: true,
                            code: GlblCode.SUCCESS,
                            message: GlblMessages.SUCCESS,
                        });
                    }
                }
            }
        } catch (err: any) {
            console.error("Error in transak_webhook>>", err)
            await commonHelper.save_error_logs("transak_webhook", err.message)
            return res.status(GlblCode.ERROR_CODE).send({
                status: false,
                code: GlblCode.ERROR_CODE,
                message: GlblMessages.CATCH_MSG,
            });
        }

    }
    public async alchemy_webhook(req: Request, res: Response) {
        try {
            console.log("Entered into on_off_ramp alchemy_webhook>>>")
            console.log("💥 -----Entered into on_off_ramp alchemy_webhook data >>>", req.body)
            let data: any = req.body;
            await Models.OnOffRampWebhookModel.create({
                ramp_type: TxReqTypesEnum.ALCHEMY,
                webhook: data,
                webhook_id: data.orderNo ? data.orderNo : null,
                status: data.status ? data.status : null,
                created_at: new Date(),
                updated_at: new Date()
            })
            if (data) {
                let status: string = 'pending';
                if (data?.merchantOrderNo !== "") {
                    console.log("Enterd into data?.merchantOrderNo !== >>>")
                    if (data?.status !== undefined) {
                        console.log("Enterd into data?.status !== undefined")
                        status = (data.status == 'FINISHED') ? 'completed' : (data.status == 'PAY_FAIL') ? 'failed' : 'pending';
                    }
                    console.log("Outside of data?.status !== undefined")
                } else {
                    console.log("Enterd into else of data?.merchantOrderNo !== >>>")
                    if (data?.status !== undefined) {
                        console.log("Enterd into data?.status !== undefined")
                        status = (data.status == '4') ? 'completed' : (data.status == '5') ? 'failed' : 'pending';
                    }
                    console.log("Outside of data?.status else !== undefined")
                }
                console.log("Outside all if else conditions")
                await Models.TrnxHistoryModel.update({
                    merchant_id: data?.merchantOrderNo ? data.merchantOrderNo : null,
                    amount: data?.amount,
                    fiat_type: data?.fiat,
                    tx_id: data?.txHash ? data.txHash : null,
                    status: status,
                    blockchain_status: (status == GlblStatus.COMPLETED) ? GlblBlockchainTxStatusEnum.CONFIRMED : GlblBlockchainTxStatusEnum.FAILED
                }, { where: { alchemy_order_id: data?.orderNo } })
            }
            return res.status(GlblCode.SUCCESS).send({
                status: true,
                code: GlblCode.SUCCESS,
                message: GlblMessages.SUCCESS,
            });
        } catch (err: any) {
            console.error("Error in alchemy_webhook>>", err)
            await commonHelper.save_error_logs("alchemy_webhook", err.message)
            return res.status(GlblCode.ERROR_CODE).send({
                status: false,
                code: GlblCode.ERROR_CODE,
                message: GlblMessages.CATCH_MSG,
            });
        }

    }

}
export const transactController = new TransactController();