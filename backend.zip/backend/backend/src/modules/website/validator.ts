import { Joi } from 'express-validation';

export default class user_validator {
    static save_contact_data = {
        body: Joi.object({
            captcha_response_key: Joi.string().required(),
            first_name: Joi.string().required(),
            last_name: Joi.string().required(),
            email: Joi.string().required(),
            phone_number: Joi.number().required(),
            company_name: Joi.string().required(),
            message: Joi.string().required()
        })
    }
}