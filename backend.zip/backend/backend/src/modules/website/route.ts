import express from "express";
import { validate } from "express-validation"
import { ControllerInterface } from "../../interfaces/controller.interface";
import { siteController } from "./controller";
import validator from "./validator";

class WebsiteRoute implements ControllerInterface {
    public path = "/site";
    public router = express.Router();

    constructor() {
        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router.post(`${this.path}/save_contact_data`, [validate(validator.save_contact_data)], siteController.save_contact_data)
    }
}

export default WebsiteRoute;
