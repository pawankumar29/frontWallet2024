import { Request, Response } from "express";
import response from "../../helpers/response/response.helpers";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from '../../models/model/index';
import { language } from "../../constants";
import commonHelper from "../../helpers/common/common.helpers";
import axios from "axios";
import { config } from "../../config";


class SiteController implements OnlyControllerInterface {

    constructor() {
        this.initialize();
    }
    public initialize() { }

    public async save_contact_data(req: Request, res: Response) {
        let lang: any = req.headers['content-language'] || 'en';
        try {
            let { captcha_response_key, first_name, last_name, email, phone_number, company_name, message }: { captcha_response_key: string, first_name: string, last_name: string, email: string, phone_number: number, company_name: string, message: string } = req.body;
            const secret_key = config.GOOGLE_CAPTCHA_SECRET_KEY;
            // Hitting POST request to the URL, Google will
            // respond with success or error scenario.
            const url = config.GOOGLE_CAPTCHA_VERIFY_URL;
            let captchaData = {
                secret: secret_key,
                response: captcha_response_key
            }
            let axios_config: any = {
                method: 'post',
                url: url,
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                data: new URLSearchParams(Object.entries(captchaData)).toString(),
            };
            await axios(axios_config)
                .then(async function (captcha_resp) {
                    console.log('captcha response >>>', captcha_resp);
                    console.log('captcha response >>>', captcha_resp?.data);
                    if (captcha_resp?.data.success == true) {
                        let contact_data: any = {
                            first_name: first_name,
                            last_name: last_name,
                            email: email,
                            phone_number: phone_number,
                            company_name: company_name,
                            message: message
                        }
                        console.log('contact_data >>>>', contact_data);
                        await Models.ContactModel.create(contact_data);
                        return response.success(res, {
                            data: {
                                status: true,
                                // message: language[lang].SUCCESS
                                message: "Contact has been done successfully."
                            },
                        });
                    } else {
                        return response.error(res, {
                            data: {
                                status: false,
                                // message: language[lang].CATCH_MSG
                                message: "Invalid captcha."
                            }
                        });
                    }
                })
                .catch(function (error) {
                    console.error('captcha error >>>', error);
                    return response.error(res, { data: { status: false, error: error, message: language[lang].CATCH_MSG } });
                });

        } catch (err: any) {
            console.error("Error in user > save_contact_data.", err)
            await commonHelper.save_error_logs("save_contact_data", err.message);
            return response.error(res, { data: {} });
        }
    }
}

export const siteController = new SiteController();
