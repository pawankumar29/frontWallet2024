import UserRoute from "./user/route";
import WalletRoute from "./wallet/walletRoute";
import BtcRoute from "./btc/btcRoute";
import EthModule from "./eth/ethRoute";
import authRoute from "./auth/authRoute";
import NFTRoute from "./nft/nftRoute";
import DappRoute from "./dapp/dappRoute";
import TronRoute from "./tron/routes";
import BnbRoute from "./bsc/bscRoute";
import SwftcRoute from "./swftc/routes";
import OnChainRoute from "./on-chain/routes";



const controllers = [
  new UserRoute(),
  new WalletRoute(),
  new BtcRoute(),
  new EthModule(),
  new NFTRoute(),
  new DappRoute(),
  new authRoute(),
  new TronRoute(),
  new BnbRoute(),
  new SwftcRoute(),
  new OnChainRoute()
]

export default controllers;

import WebsiteRoute from "./website/route";
export const website = new WebsiteRoute();

