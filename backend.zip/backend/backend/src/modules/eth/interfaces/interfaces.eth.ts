export interface RawDataInterface {
  my_address: string;
  dest_address: string;
  coin_type: string;
  amount: number
}

