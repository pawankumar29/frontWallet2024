import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import redisHelper from "../../helpers/common/redis";
import * as Models from '../../models/model/index';
import { config } from "../../config";
import { GlblAddedBy, GlblBooleanEnum } from "../../constants/global_enum";
import { exponentialToDecimal } from "../../helpers/common/globalFunctions";
import dbHelper, { coin_price_in_fiat_graph_queries, coin_price_in_fiat_queries, coin_queries, custom_token_queries, resent_graph_data_queries } from "../../helpers/dbHelper";
import { language } from "../../constants";
import { global_helper } from "../../helpers/common/global_helper";
import commonHelper from "../../helpers/common/common.helpers";
import currency_fiat_queries from "../../helpers/dbHelper/currency_fiats";
import { wallet_queries } from "../../helpers/dbHelper";
import axios from "axios";
import cmcHelper from "../../helpers/common/cmc.helper";
class WalletHelpers implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() { }
  public async add_coin_to_table(isSwapList: number, data: any, symbol: any, name: any, coin_gicko_alias: any, decimals: any, lang: any,added_by:any=null) {
    try {
      let token_address: string = data?.token_address ? data?.token_address : null;
      let cmc_id: any = GlblBooleanEnum.false;
      let image: any = "";
      if (token_address && symbol) {
        let cmc_data: any = await global_helper.get_token_image_from_cmc({ symbol: symbol });
        cmc_id = cmc_data ? cmc_data.id : GlblBooleanEnum.false;
        image = cmc_data ? cmc_data.image : null;
      }
      console.log("symbol>>>", symbol, "token_type>>", data.token_type)
        let coin_data:any;
      if(added_by){
        coin_data = {
          coin_name: name,
          coin_symbol: symbol.toUpperCase(),
          coin_image: image,
          cmc_id: cmc_id,
          coin_gicko_alias: coin_gicko_alias,
          coin_family: data.coin_family,
          coin_status: GlblBooleanEnum.true,
          is_token: GlblBooleanEnum.true,
          is_on_cmc: GlblBooleanEnum.true,
          for_swap: isSwapList,
          added_by: GlblAddedBy.ADMIN,
          token_type: data.token_type.toUpperCase(),
          decimals: Math.pow(10, parseInt(decimals)),
          token_address: token_address,
          created_at: data.created_at,
          updated_at: data.updated_at,
        }

      }else{
         coin_data= {
          coin_name: name,
          coin_symbol: symbol.toUpperCase(),
          coin_image: image,
          cmc_id: cmc_id,
          coin_gicko_alias: coin_gicko_alias,
          coin_family: data.coin_family,
          coin_status: GlblBooleanEnum.true,
          is_token: GlblBooleanEnum.true,
          is_on_cmc: GlblBooleanEnum.true,
          for_swap: isSwapList,
          added_by: GlblAddedBy.USER,
          token_type: data.token_type.toUpperCase(),
          decimals: Math.pow(10, parseInt(decimals)),
          token_address: token_address,
          created_at: data.created_at,
          updated_at: data.updated_at,
        }

      }

     
      let response: any = await coin_queries.coin_create(coin_data)
      // coin_data = response.coin_id;
      await WalletHelper.update_token_in_redis(response, 0)
      data.coin_id = response.coin_id;
      data.image = image;
      if (cmc_id > GlblBooleanEnum.false) {
        await WalletHelper.insert_graph_reset_data(cmc_id)
        await WalletHelper.update_fiat_coin_price(cmc_id, symbol, name, data.coin_family, token_address, data.coin_id);
      }
      return { data: data, message: language[lang].TOKEN_ADDED }
    } catch (err: any) {
      console.error("Error in add_coin_to_table>>", err)
      await commonHelper.save_error_logs("add_coin_to_table", err.message)
      throw err;
    }
  }
  public async insert_graph_reset_data(cmc_id: number) {
    try {
      let currentUTCDate: string = new Date().toISOString().replace(/T/, " ").replace(/\..+/, "");
      let graph_data: any = await resent_graph_data_queries.resent_graph_data_find_one(["id"], { cmc_id: cmc_id })
      if (graph_data == null) {
        await resent_graph_data_queries.resent_graph_data_create({ cmc_id: cmc_id, graph_type: '1d', created_at: currentUTCDate, updated_at: null })
      }
    } catch (err: any) {
      console.error("Error in insert_graph_reset_data>>", err)
      await commonHelper.save_error_logs("insert_graph_reset_data", err.message)
      throw err;
    }

  }
  public async update_fiat_coin_price(cmc_id: number, coin_symbol: string, coin_name: string, coin_family: number, token_address: any, coin_id: number) {
    try {
      let coin_data: any = {
        coin_symbol: coin_symbol,
        coin_name: coin_name,
        coin_family: coin_family,
        token_address: token_address
      }
      console.log("coin_data>>", coin_data)
      let fiatCurrency: any = await currency_fiat_queries.currency_fiat_find_all(["currency_code", "status"], { status: 1 })
      if (fiatCurrency) {
        let codes: any = fiatCurrency.map((el: any) => el.currency_code);
        let currencyFormat: any = codes.toString().replace(/[\[\]']+/g, '');
        let result: any = await cmcHelper.cmcApi(`quotes/latest?id=${cmc_id}&convert=${currencyFormat}`);
        if (result?.data?.data) {
          let symbol: string = result.data.data[cmc_id].symbol
          for (let i: number = 0; i < fiatCurrency.length; i++) {
            // Check cmc data in coin price in fiat
            let data_exist: any = await coin_price_in_fiat_queries.coin_price_in_fiat_find_one(["id"], { cmc_id: cmc_id, fiat_type: (fiatCurrency[i].currency_code).toLowerCase() })
            if (!data_exist) {
              let latest_price: any = {
                price: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].price,
                timestamp: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].last_updated,
                volume_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].volume_24h,
                price_change_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].percent_change_24h
              }
              let data_to_insert: any = {
                coin_id: coin_id,
                coin_symbol: coin_data.coin_symbol,
                coin_name: coin_data.coin_name,
                coin_family: coin_data.coin_family,
                cmc_id: cmc_id,
                fiat_type: (fiatCurrency[i].currency_code).toLowerCase(),
                value: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].price,
                price_change_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].percent_change_24h,
                price_change_percentage_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].percent_change_24h,
                market_cap: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].market_cap,
                circulating: result.data.data[cmc_id].circulating_supply,
                total_supply: result.data.data[cmc_id].total_supply,
                rank: result.data.data[cmc_id].cmc_rank,
                volume_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].volume_24h,
                token_address: coin_data.token_address,
                max_supply: result.data.data[cmc_id].max_supply,
                latest_price: latest_price,
                roi: null,
                open: null,
                high: null,
                average: null,
                close: null,
                low: null,
                change_price: null,
              }
              await coin_price_in_fiat_queries.coin_price_in_fiat_create(data_to_insert)
            }
            let types = ['1d'];
            let graph_data_exist: any = await coin_price_in_fiat_graph_queries.coin_price_in_fiat_graph_find_one(["id"], { cmc_id: cmc_id, fiat_type: (fiatCurrency[i].currency_code).toLowerCase() })
            if (!graph_data_exist) {
              let latest_price_graph: any = [{
                price: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].price,
                timestamp: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].last_updated,
                volume_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].volume_24h,
                price_change_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].percent_change_24h
              }]

              let data_to_insert_graph: any = {
                coin_id: coin_id,
                cmc_id: cmc_id,
                sparkline: latest_price_graph,
                coin_type: coin_data.coin_symbol,
                // volume_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].volume_24h,
                type: types[0],
                fiat_type: (fiatCurrency[i].currency_code).toUpperCase(),
                latest_price: latest_price_graph,
                latest_price_source: types[0],
                value: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].price,
                price_change_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].percent_change_24h,
                price_change_percentage_24h: result.data.data[cmc_id].quote[(fiatCurrency[i].currency_code).toUpperCase()].percent_change_24h,
              }
              await coin_price_in_fiat_graph_queries.coin_price_in_fiat_graph_create(data_to_insert_graph)
            }
          }
        } else {
          console.log("no data in cmc")
        }
      } else {
        console.log("no fiat currency")
      }
    } catch (err: any) {
      console.error("Error in update_fiat_coin_price>>", err)
      await commonHelper.save_error_logs("update_fiat_coin_price", err.message)
      throw err;
    }
  }
  public async insert_entry_in_custom_token_table(coin_id: number, user_id: number, lang: any) {
    try {
      let message: any;
      let selectToken: any = await custom_token_queries.custom_token_find_one(["id", "user_id", "coin_id"], { coin_id: coin_id, user_id: user_id })
      if (selectToken == null) {
        await custom_token_queries.custom_token_create({ coin_id: coin_id, user_id: user_id })
        message = language[lang].TOKEN_ADDED;
      } else {
        message = language[lang].TOKEN_EXIST;
      }
      return message;
    } catch (err: any) {
      console.error("Error in insert_entry_in_custom_token_table>>", err)
      await commonHelper.save_error_logs("insert_entry_in_custom_token_table", err.message)
      throw err;
    }
  }
  public async create_wallet_for_coin(data: any) {
    try {
      let wallet_data: any = await wallet_queries.wallet_find_one(['wallet_id', 'status'], { wallet_address: data.wallet_address, coin_id: data.coin_id })
      if (!wallet_data) {
        wallet_data = {
          wallet_address: data.wallet_address,
          wallet_name: data.wallet_name,
          coin_id: data.coin_id,
          user_id: data.user_id,
          balance: Number(data.balance),
          default_wallet: 1,
          // login_type: data.login_type,
          // social_id: data.social_id,
          coin_family: data.coin_family,
          status: 1,
          // email: data.email,
          created_at: data.created_at,
          updated_at: data.updated_at,
        };
        await wallet_queries.wallet_create(wallet_data)
      } else {
        if (wallet_data.status == 1) {
          console.log("wallet already active for this coin")
        } else {
          await wallet_queries.wallet_update({ status: 1 }, { wallet_address: data.wallet_address, coin_id: data.coin_id })
        }
      }
    } catch (err: any) {
      console.error("error at create_wallet_for_coin================>", err);
      await commonHelper.save_error_logs("create_wallet_for_coin", err.message)
      throw err;
    }
  }
  public async update_token_in_redis(coin_data: any, coin_id: number) {
    try {
      let coin_family = coin_data.coin_family;
      let tokensList: any;
      let specific_token_data: any;
      if (coin_id > 0) {
        let token: any = await coin_queries.coin_find_one([], { coin_id: coin_id })
        specific_token_data = token
      } else {
        specific_token_data = coin_data
      }
      switch (coin_family) {
        case config.STATIC_COIN_FAMILY.ETH:
          tokensList = await redisHelper.getRedisSting(config.TOKENLIST.ETH.ERC20);
          tokensList = JSON.parse(tokensList)
          if (tokensList) {
            await tokensList.push(specific_token_data)
            await redisHelper.setRedisSting(config.TOKENLIST.ETH.ERC20, JSON.stringify(tokensList));
          } else {
            tokensList = await coin_queries.coin_find_all([], { coin_status: 1, coin_family: coin_family })
            await redisHelper.setRedisSting(config.TOKENLIST.ETH.ERC20, JSON.stringify(tokensList));
          }
          break;
        case config.STATIC_COIN_FAMILY.BNB:
          tokensList = await redisHelper.getRedisSting(config.TOKENLIST.BSC.BEP20);
          tokensList = JSON.parse(tokensList)
          if (tokensList) {
            await tokensList.push(specific_token_data)
            await redisHelper.setRedisSting(config.TOKENLIST.BSC.BEP20, JSON.stringify(tokensList));
          } else {
            tokensList = await coin_queries.coin_find_all([], { coin_status: 1, coin_family: coin_family })
            await redisHelper.setRedisSting(config.TOKENLIST.BSC.BEP20, JSON.stringify(tokensList));
          }
          break;
        case config.STATIC_COIN_FAMILY.TRX:
          tokensList = await redisHelper.getRedisSting(config.TOKENLIST.TRON.TRX20);
          tokensList = JSON.parse(tokensList)
          if (tokensList) {
            await tokensList.push(specific_token_data)
            await redisHelper.setRedisSting(config.TOKENLIST.TRON.TRX20, JSON.stringify(tokensList));
          } else {
            tokensList = await coin_queries.coin_find_all([], { coin_status: 1, coin_family: coin_family })
            await redisHelper.setRedisSting(config.TOKENLIST.TRON.TRX20, JSON.stringify(tokensList));
          }
          break;
      }
    } catch (err: any) {
      console.error("error at update_token_in_redis", err);
      await commonHelper.save_error_logs("update_token_in_redis", err.message)
      throw err;
    }
  }
  // public async send_mail(email: string, text: string, subject: string) {
  //   try {
  //     console.log("email >>>>.", email)
  //     const MAILGUN_API_KEY: string = ``;
  //     const MAILGUN_DOMAIN: string = ``;
  //     const MAILGUN_BASE_URL: string = ``;
  //     const response: any = await axios({
  //       method: 'post',
  //       url: `${MAILGUN_BASE_URL}/messages`,
  //       auth: {
  //         username: 'api',
  //         password: MAILGUN_API_KEY
  //       },
  //       params: {
  //         from: "",
  //         to: email,
  //         subject: subject,
  //         html: text
  //       }
  //     });
  //     console.log("response>>", response)
  //     return response;
  //   } catch (err: any) {
  //     console.error("send_mail", err)
  //     throw err;
  //   }
  // }


  public async min_coin_balance(wallet_data: any, fiat_currency: string, usd_value: any) {
    try {
      let fiat_currency_value: any = await Models.CoinPriceInFiatModel.findOne({
        attributes: ["value"],
        where: {
          coin_id: wallet_data.coin_id,
          fiat_type: fiat_currency
        },
        raw: true
      })
      let min_bal: number = 10 / usd_value;
      let min_bal_in_fiat: number = min_bal * fiat_currency_value.value;
      min_bal_in_fiat = min_bal_in_fiat < 0.000001 ? await WalletHelper.toFixedExp(min_bal_in_fiat, 8) : min_bal_in_fiat < 0.0001 ? await WalletHelper.toFixedExp(min_bal_in_fiat, 6) : await WalletHelper.toFixedExp(min_bal_in_fiat, 2)
      console.log("min_bal>>>>", min_bal_in_fiat)
      return { min_bal_in_fiat: min_bal_in_fiat, fiat_value: fiat_currency_value.value };
    } catch (err: any) {
      console.error("Error in min_coin_balance of wallet", err)
      throw err;
    }

  }
  public async toFixedExp(num: any, fixed: number) {
    try {
      if (num) {
        num = exponentialToDecimal(Number(num))
        let re = new RegExp('^-?\\d+(?:.\\d{0,' + (fixed || -1) + '})?');
        return num.toString().match(re)[0];
      } else {
        return '0.00';
      }

    } catch (err: any) {
      console.error("Error in toFixedExp>>", err)
      return '0.00';
    }

  }



}
export const WalletHelper = new WalletHelpers();
