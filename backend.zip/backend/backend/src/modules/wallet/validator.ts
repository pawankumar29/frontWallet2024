import { Joi } from 'express-validation';

export default class wallet_validator {
    static addToken_validate = {
        body: Joi.object({
            name: Joi.string().required(),
            symbol: Joi.string().required(),
            coin_gicko_alias: Joi.string().required(),
            decimals: Joi.string().required(),
            token_address: Joi.string().required(),
            coin_family: Joi.number().required(),
            wallet_address: Joi.string().required(),
            //login_type: Joi.string().optional(),
            //social_id: Joi.string().optional(),
            wallet_name: Joi.string().allow(null, '').optional(),
            isSwapList: Joi.bool().required(),
            token_type: Joi.string().required()
        })
    }


    static portfolio_validate = {
        body: Joi.object({
            page: Joi.number().optional(),
            limit: Joi.number().optional(),
            coin_family: Joi.array().required(),
            search: Joi.string().allow(null, '').optional(),
            addressListKeys: Joi.array().required(),
            fiat_type: Joi.string().required()
        })
    }
    static toggleCoinList_validate = {
        body: Joi.object({
            page: Joi.number().optional(),
            limit: Joi.number().optional(),
            coinFamilyKeys: Joi.array().required(),
            search: Joi.string().allow(null, '').optional(),
            addrsListKeys: Joi.array().required(),
            currency_code: Joi.string().required(),
        })
    }
    static transactionList_validate = {
        body: Joi.object({
            addrsListKeys: Joi.array().required(),
            fiat_currency: Joi.string().allow(null, '').optional(),
            search: Joi.string().optional(),
            limit: Joi.number().optional(),
            page: Joi.number().optional(),
            coin_id: Joi.number().optional(),
            status: Joi.string().allow(null, '').optional(),
            date_from: Joi.string().allow(null, '').optional(),
            date_to: Joi.string().allow(null, '').optional(),
            trnx_type: Joi.string().allow(null, '').optional(),
            coin_family: Joi.array().required(),
            ///////////////////////////////////
            coin_type: Joi.string().allow(null, '').optional(),
            from_date: Joi.string().allow(null, '').optional(),
            to_date: Joi.string().allow(null, '').optional(),
        })
    }
    static searchToken_validate = {
        body: Joi.object({
            tokenAddress: Joi.string().required(),
            coinFamily: Joi.number().required(),
        })
    }

    static swap_list_validate = {
        body: Joi.object({
            coin_family: Joi.array().required(),
            addrsListKeys: Joi.array().required(),
            fiat_type: Joi.string().required()
        })
    }
    static updateWatchlist_validate = {
        body: Joi.object({
            data: Joi.array().optional()
            // coin_id: Joi.string().required(),
            // status: Joi.number().required(),
            // address: Joi.string().required(),
        })
    }
    static getWatchlist_validate = {
        body: Joi.object({
            fiat_type: Joi.string().required(),
            search: Joi.string().allow(null, '').optional(),
            page: Joi.number().optional(),
            limit: Joi.number().optional(),
            wallet_address: Joi.array().required(),
            is_fav: Joi.number().optional(),
            coin_family: Joi.array().required(),
        })
    }
    static findAddressFiat = {
        body: Joi.object({
            wallet_address: Joi.array().required(),
            fiatCurrency: Joi.string().required(),
        })
    }
    static checkFiatBalance = {
        body: Joi.object({
            coin_family: Joi.number().required(),
            fiat_currency: Joi.string().required(),
            coin_symbol: Joi.string().required()
        })
    }

}