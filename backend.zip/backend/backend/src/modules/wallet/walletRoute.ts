import express from 'express';
import { ControllerInterface } from '../../interfaces/controller.interface';
import { validate } from '../../middlewares/validate.middleware';
import jwtVerification from '../../middlewares/verify.middleware';
import { walletController } from './controller.wallet';
import { validate as validateExpress } from "express-validation"
import wallet_validator from './validator';

class WalletRoute implements ControllerInterface {
   public path = '/wallet';
   public router = express.Router();
   constructor() {
      this.initializeRoutes()
   }
   public initializeRoutes() {
      /** Testing */
      // this.router.post(`${this.path}/get_decimals`, walletController.get_decimals);
      // this.router.post(`${this.path}/validate_address`, walletController.validate_address);
      // this.router.post(`${this.path}/get_balance`, walletController.get_balance);
      // this.router.post(`${this.path}/check_swap`, walletController.check_swap);
      // this.router.post(`${this.path}/update_coin_price_in_fiat`, walletController.update_coin_price_in_fiat);
      // this.router.post(`${this.path}/create_testing`, walletController.create_testing);
      // this.router.post(`${this.path}/update_token_in_redis`, walletController.update_token_in_redis);
      // this.router.post(`${this.path}/distinct_data`, walletController.distinct_data);
      // this.router.post(`${this.path}/testing_mailgun`, walletController.testing_mailgun);


      /** Used in front end */
      this.router.post(`${this.path}/addtoken`, [validateExpress(wallet_validator.addToken_validate)], jwtVerification.verifyToken, walletController.addToken);
      this.router.post(`${this.path}/activeinactive`, jwtVerification.verifyToken, validate, walletController.activeInactiveWallet);
      this.router.post(`${this.path}/portfolio`, [validateExpress(wallet_validator.portfolio_validate)], jwtVerification.verifyToken, walletController.portfolio);
      this.router.post(`${this.path}/toggleCoinList`, [validateExpress(wallet_validator.toggleCoinList_validate)], jwtVerification.verifyToken, walletController.toggleCoinList);
      this.router.post(`${this.path}/transaction/list`, [validateExpress(wallet_validator.transactionList_validate)], jwtVerification.verifyToken, walletController.transactions);
      this.router.post(`${this.path}/order/update`, jwtVerification.verifyToken, walletController.updateWalletOrder);
      this.router.post(`${this.path}/search`, [validateExpress(wallet_validator.searchToken_validate)], jwtVerification.verifyToken, walletController.searchToken);
      this.router.post(`${this.path}/swap_coinlist`, [validateExpress(wallet_validator.swap_list_validate)], jwtVerification.verifyToken, walletController.swap_list);
      this.router.get(`${this.path}/rpcUrl`, walletController.getRpcUrl)
      this.router.post(`${this.path}/updateWatchlist`, [validateExpress(wallet_validator.updateWatchlist_validate)], jwtVerification.verifyToken, walletController.updateWatchlist);
      this.router.post(`${this.path}/getWatchlist`, [validateExpress(wallet_validator.getWatchlist_validate)], jwtVerification.verifyToken, walletController.getWatchlist);
      this.router.get(`${this.path}/transaction/downloadcsv/:id`, walletController.downloadCsv);
      this.router.get(`${this.path}/currencyfiatlist`, walletController.getCurrencyFiat);
      this.router.post(`${this.path}/getFiatPrice`, jwtVerification.verifyToken, walletController.getFiatPrice);
      this.router.post(`${this.path}/updateBalance`, jwtVerification.verifyToken, walletController.updateBalance);
      this.router.post(`${this.path}/fee`, jwtVerification.verifyToken, walletController.get_fee);
      this.router.post(`${this.path}/coin/details`, jwtVerification.verifyToken, walletController.getCoinsDetails);
      this.router.post(`${this.path}/nativeCoinFiatPrice`, jwtVerification.verifyToken, walletController.NativeCoinFiatPrice);
      this.router.post(`${this.path}/get_balance_fiat`, [validateExpress(wallet_validator.findAddressFiat)], jwtVerification.verifyToken, walletController.getBalanceFiat);
      this.router.get(`${this.path}/fetchValue`, jwtVerification.verifyToken, walletController.fetchValue);
      this.router.post(`${this.path}/checkFiatBalance`, [validateExpress(wallet_validator.checkFiatBalance)], jwtVerification.verifyToken, walletController.checkFiatBalance);
      this.router.post(`${this.path}/creating_private_key`, walletController.creating_private_key);
      // this.router.post(`${this.path}/encrypt_decrypt`, walletController.encrypt_decrypt);
   }
}
export default WalletRoute;
