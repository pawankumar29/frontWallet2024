import { Request, Response } from "express";
import { Op, Sequelize } from "sequelize";
import jwtHelper from "../../helpers/common/jwt";
import response from "../../helpers/response/response.helpers";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";
import userhelper from "./helper";
import moment from "moment";
import {
  GlblBooleanEnum,
  GlblCode,
  LoginType,
  CoinFamily,
  Fiat_Currency,
  WalletName,
  GlblMessages,
} from "../../constants/global_enum";
import { global_helper } from "../../helpers/common/global_helper";
import { language } from "../../constants";
import commonHelper from "../../helpers/common/common.helpers";
import {
  address_book_queries,
  address_book_wallet_queries,
  device_token_queries,
  notification_queries,
  wallet_queries,
} from "../../helpers/dbHelper/index";
import { ethWeb3 } from "../../helpers/common/web3_eth_helpers";
import { bscWeb3 } from "../../helpers/common/web3.bsc_helper";
import { trxWeb3 } from "../../helpers/common/web3_trx_helper";
import * as stream from "stream";
import csv from "csv-parser";

class UserController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() {}

  public async createWallet(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let {
        wallet_address,
        addressList,
        wallet_name,
        device_token,
        device_id,
        referral_code,
      }: {
        wallet_address: string;
        addressList: any;
        wallet_name: string;
        device_token: string;
        device_id: string;
        referral_code: string;
      } = req.body;

      // If login_type = jwt than we need to convert it to email type
      //req.body.login_type = (req.body.login_type == LoginType.JWT) ? LoginType.EMAIL : req.body.login_type;

      // if(wallet_name){
      //   if(wallet_name?.length>30||wallet_name?.length<3){
      //     throw new Error("wallet Name should be greater than 3 and less than 31");
      //   }

      // }

      if (referral_code) {
        /** check referral code is valid */
        let referral_code_invalid = await userhelper.referral_code_is_valid(
          referral_code,
          lang
        );
        if (referral_code_invalid.status) {
          return response.error(res, {
            data: {
              status: false,
              message: referral_code_invalid.message,
            },
          });
        }
      }

      // Check whether same wallet address exist
      let checkAddressExists: any = null;

      if (wallet_address) {
        checkAddressExists = await wallet_queries.wallet_find_one(["user_id"], {
          wallet_address: wallet_address,
        });
      }

      // If Wallet Address exist
      let userId: any = GlblBooleanEnum.false;
      let user_referral_code: string = "";
      if (checkAddressExists) {
        userId = checkAddressExists?.user_id;
        // Adding users all active coins to queue to update balance
        // try {
        //   await userhelper.adding_coins_to_queue(checkAddressExists?.user_id)
        // } catch (err: any) {
        //   console.error("Error in adding_coins_to_queue>>>> ", err)
        // }

        // Insert device id and referral code if not there
        if (device_id) {
          user_referral_code = await userhelper.old_user_generate_referral(
            device_id,
            userId
          );
        }
      } else {
        // Create New User
        let code_userId: any = await userhelper.create_new_user(
          device_id,
          wallet_name
        );
        if (device_id) {
          user_referral_code = code_userId.code;
        }
        userId = code_userId.user_id;
      }
      /** save referral data */
      if (referral_code) {
        /** check referral code already used */
        let referral_already_exist = await userhelper.referral_already_used(
          { device_id: device_id, address: wallet_address, user_id: null },
          lang
        );

        if (referral_already_exist.status) {
          return response.error(res, {
            data: {
              status: false,
              message: referral_already_exist.message,
            },
          });
        }

        let save_referral_data = await userhelper.save_referral_code(
          {
            user_id: userId,
            referral_code: referral_code,
            device_id: device_id,
          },
          lang
        );

        if (!save_referral_data.status) {
          return response.error(res, {
            data: {
              status: false,
              message: save_referral_data.message,
            },
          });
        }
      }

      // Updating balance
      await userhelper.updating_balance(
        addressList,
        userId,
        req,
        wallet_name,
        lang
      );
      await wallet_queries.wallet_update(
        { login_type: req.body.login_type },
        { user_id: userId }
      );

      let token: string;
      let refreshToken: string;

      token = await jwtHelper.createJSONWebToken(userId, device_token);

      refreshToken = await jwtHelper.createJSONRefreshToken(
        userId,
        device_token
      );

      if (device_token) {
        await userhelper.device_token_helper(device_token, userId, lang);
      }
      const newObject: any = {
        token,
        refreshToken,
        userId: userId,
        referral_code: user_referral_code,
        wallet_name: wallet_name,
      };
      return response.success(res, {
        data: {
          status: true,
          data: newObject,
        },
      });
    } catch (err: any) {
      console.error("Error in user > create wallet (2).", err);
      await commonHelper.save_error_logs("users_createWallet", err.message);
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async notificationList(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let per_page: number = Number(
        req.body?.limit == undefined ? (req.body.limit = "10") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - 1) * per_page;

      let notifications_data =
        await notification_queries.notifications_joint_find_all_count_all(
          [
            "wallet_address",
            "amount",
            "notification_type",
            "tx_type",
            "state",
            "message",
            "alert_price",
            "fiat_type",
            "coin_symbol",
            "created_at",
          ],
          ["coin_name", "coin_symbol"],
          ["currency_code", "currency_symbol"],
          { coin_family: { [Op.in]: req.body.coin_family } },
          {
            [Op.or]: [
              { wallet_address: { [Op.in]: req?.body?.addrsListKeys } },
              { to_user_id: req.userId },
            ],
          },
          per_page,
          offset
        );

      return response.success(res, {
        data: {
          success: true,
          data: notifications_data?.rows,
          meta: {
            page: page,
            pages: Math.ceil(notifications_data.count / per_page),
            perPage: per_page,
            total: notifications_data.count,
          },
          message: language[lang].SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in user > notificationList.", err);
      await commonHelper.save_error_logs("users_notificationList", err.message);
      return response.error(res, { data: {} });
    }
  }

  public async userLogout(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let { deviceToken }: { deviceToken: string } = req.body;
      let userId: number = req.userId;

      let checkUserDeviceToken: any =
        await device_token_queries.device_token_find_one(["id"], {
          device_token: deviceToken,
          user_id: userId,
        });

      if (checkUserDeviceToken) {
        await device_token_queries.device_token_destroy({
          device_token: deviceToken,
          user_id: userId,
        });
      }
      return response.success(res, {
        data: {
          status: true,
          data: {
            message: language[lang].LOGOUT,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in user > userLogout.", err);
      await commonHelper.save_error_logs("users_userLogout", err.message);
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async add_address_book(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let user_id: number = req.userId;
      let { wallet_address, contact_name, address, coin_family, wallet_name } =
        req.body;

      let wallet_address_exist: any =
        await address_book_wallet_queries.address_book_wallets_with_address_book(
          ["address_book_id"],
          ["id"],
          { wallet_address: wallet_address, coin_family: coin_family },
          { address: address }
        );

      if (wallet_address_exist) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].SAME_WALLET_ADDRESS_EXIST,
          },
        });
      }

      let address_book: any = await address_book_queries.address_books_find_one(
        ["id", "name", "address"],
        { address: address, user_id: user_id, name: contact_name }
      );

      if (!address_book) {
        address_book = await address_book_queries.address_book_create({
          address: address,
          user_id: user_id,
          name: contact_name,
          created_at: new Date(),
          updated_at: new Date(),
        });
      }
      let address_book_id = address_book?.id;

      let wallet_name_exist: number =
        await address_book_wallet_queries.address_book_wallet_get_count({
          address_book_id: address_book_id,
          name: wallet_name,
        });

      if (wallet_name_exist > GlblBooleanEnum.false) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].SAME_WALLET_NAME_EXIST,
          },
        });
      }
      let name: any;
      if (!wallet_name) {
        name = await userhelper.wallet_name(
          address_book_id,
          coin_family,
          wallet_name
        );
      } else {
        name = wallet_name;
      }
      wallet_name = name;
      const addressValidity: any = await global_helper.validate_address({
        wallet_address,
        coin_family,
      });
      if (!addressValidity)
        throw new Error(`${language[lang].INVALID_ADDRESS} (${coin_family})`);
      let total_wallets: any =
        await address_book_wallet_queries.address_book_wallets_find_all(
          ["name"],
          { address_book_id: address_book_id }
        );
      if (total_wallets.length == 10) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].MAX_LIMIT,
          },
        });
      }
      await address_book_wallet_queries.address_book_wallet_create({
        address_book_id: address_book_id,
        name: wallet_name,
        wallet_address: wallet_address,
        coin_family: coin_family,
      });
      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].ADDRESS_BOOK_SAVED,
        },
      });
    } catch (err: any) {
      console.error("Error in user > add_address_book.", err);
      await commonHelper.save_error_logs("users_add_address_book", err.message);
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async address_book(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let per_page: number = Number(
        req.body?.limit == undefined ? (req.body.limit = "10") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - 1) * per_page;
      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");
      let set_order_by: string =
        req.body?.order_by == undefined || req.body?.order_by == "undefined"
          ? "created_at"
          : (req.body?.order_by as string);
      let set_order_type: string =
        req.body?.order_type == "undefined" || req.body?.order_type == undefined
          ? "DESC"
          : (req.body?.order_type as string);
      let { address, coin_family }: { address: string; coin_family: number } =
        req.body;
      let user_id: number = req.userId;

      let address_book_data: any =
        await address_book_queries.address_book_with_address_book_wallet_coins_joint(
          ["id", "name", "address", "created_at"],
          [
            "id",
            "address_book_id",
            "wallet_address",
            "name",
            "coin_family",
            "created_at",
          ],
          {
            coin_family: coin_family,
            [Op.or]: [
              { "$wallet_data.name$": { [Op.like]: search } },
              { "$address_books.name$": { [Op.like]: search } },
            ],
          },
          ["coin_image"],
          { is_token: GlblBooleanEnum.false },
          { address: address, user_id: user_id },
          per_page,
          offset,
          set_order_by,
          set_order_type
        );

      let address_book_data_number: any =
        await address_book_queries.address_book_count({
          name: { [Op.like]: search },
          address: address,
          user_id: user_id,
        });

      return response.success(res, {
        data: {
          data: address_book_data,
          meta: {
            page: page,
            pages: Math.ceil(address_book_data_number / per_page),
            perPage: per_page,
            total: address_book_data_number,
          },
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].GET_ADDRESS_BOOK,
        },
      });
    } catch (err: any) {
      console.error("Error in user > address_book.", err);
      await commonHelper.save_error_logs("users_address_book", err.message);
      return response.error(res, {
        data: {
          data: [],
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async get_wallet_name(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let {
        contact_name,
        coin_family,
        wallet_name,
        address,
      }: {
        contact_name: string;
        coin_family: number;
        wallet_name: string;
        address: string;
      } = req.body;
      let user_id: number = req.userId;

      let address_book: any = await address_book_queries.address_books_find_one(
        ["id", "name", "address"],
        { address: address, user_id: user_id, name: contact_name }
      );

      if (address_book) {
        let address_book_id: any = address_book?.id;
        let name: any = await userhelper.wallet_name(
          address_book_id,
          coin_family,
          wallet_name
        );
        wallet_name = name;
      } else {
        if (coin_family == CoinFamily.ETH) {
          wallet_name = WalletName.ETH;
        } else if (coin_family == CoinFamily.BTC) {
          wallet_name = WalletName.BTC;
        } else if (coin_family == CoinFamily.TRX) {
          wallet_name = WalletName.TRX;
        } else if (coin_family == CoinFamily.BNB) {
          wallet_name = WalletName.BNB;
        }
      }
      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          wallet_name: wallet_name,
        },
      });
    } catch (err: any) {
      console.error("Entered in user > get_wallet_name.", err);
      await commonHelper.save_error_logs("users_get_wallet_name", err.message);
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async search(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let user_id: number = req.userId;
      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");

      let address_book: any = await address_book_queries.address_books_find_all(
        ["name"],
        { user_id: user_id, name: { [Op.like]: search } }
      );

      if (!address_book) {
        address_book = null;
      }
      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          contact_name: address_book,
        },
      });
    } catch (err: any) {
      console.error("Error in user > search.", err);
      await commonHelper.save_error_logs("users_search", err.message);
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async delete_address_book_wallet_address(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const { id, address_book_id }: { id: number; address_book_id: number } =
        req.body;
      let address_book_wallet: number =
        await address_book_wallet_queries.address_book_wallet_get_count({
          address_book_id: address_book_id,
        });

      if (address_book_wallet == GlblBooleanEnum.false) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].NO_WALLET_ADDRESS_EXIST,
          },
        });
      } else if (address_book_wallet == GlblBooleanEnum.true) {
        await address_book_wallet_queries.address_book_wallet_destroy({
          id: id,
          address_book_id: address_book_id,
        });
        await address_book_queries.address_book_destroy({
          id: address_book_id,
        });
      } else {
        await address_book_wallet_queries.address_book_wallet_destroy({
          id: id,
          address_book_id: address_book_id,
        });
      }

      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].DELETED_ADDRESSBOOK_WALLET,
        },
      });
    } catch (err: any) {
      console.error("Error in user > delete_address_book_wallet_address.", err);
      await commonHelper.save_error_logs(
        "users_delete_address_book_wallet_address",
        err.message
      );
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async delete_address_book(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const { id }: { id: number } = req.body;
      let address_book: any = await address_book_queries.address_book_count({
        id: id,
      });
      if (address_book == GlblBooleanEnum.false) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].NO_ADDRESSBOOK_EXIST,
          },
        });
      }
      await address_book_queries.address_book_destroy({ id: id });
      let address_book_wallet_data: number =
        await address_book_wallet_queries.address_book_wallet_get_count({
          address_book_id: id,
        });
      if (address_book_wallet_data > 0) {
        await address_book_wallet_queries.address_book_wallet_destroy({
          address_book_id: id,
        });
      }
      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].ADDRESSBOOK_DELETED,
        },
      });
    } catch (err: any) {
      console.error("Error in user > delete_address_book.", err);
      await commonHelper.save_error_logs(
        "users_delete_address_book",
        err.message
      );
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async edit_address_book_contact_name(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const {
        address_book_id,
        address_book_name,
      }: { address_book_id: number; address_book_name: string } = req.body;

      let user_id: number = req.userId;

      // Check same name exist or not
      let address_book_exist: any =
        await address_book_queries.address_books_find_one(["id"], {
          user_id: user_id,
          name: address_book_name,
          id: { [Op.ne]: address_book_id },
        });

      if (address_book_exist) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].ADDRESS_BOOK_WITH_SAME_CONTACT_NAME_EXIST,
          },
        });
      }

      await address_book_queries.address_book_update(
        { name: address_book_name },
        { id: address_book_id }
      );

      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].ADDRESS_BOOK_CONTACT_NAME_EDIT_SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in user > edit_address_book_contact_name.", err);
      await commonHelper.save_error_logs(
        "edit_address_book_contact_name",
        err.message
      );
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async edit_address_book_wallet(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const {
        address_book_id,
        address_book_wallet_id,
        address_book_wallet_name,
        address_book_wallet_address,
      }: {
        address_book_id: number;
        address_book_wallet_id: number;
        address_book_wallet_name: string;
        address_book_wallet_address: string;
      } = req.body;

      // Check same name exist or not
      let address_book_name_exist: any =
        await address_book_wallet_queries.address_book_wallets_find_one(
          ["id"],
          {
            address_book_id: address_book_id,
            name: address_book_wallet_name,
            id: { [Op.ne]: address_book_wallet_id },
          }
        );

      if (address_book_name_exist) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].ADDRESS_BOOK_WITH_SAME_WALLET_NAME_EXIST,
          },
        });
      }
      let address_book_address_exist: any =
        await address_book_wallet_queries.address_book_wallets_find_one(
          ["id"],
          {
            address_book_id: address_book_id,
            wallet_address: address_book_wallet_address,
            id: { [Op.ne]: address_book_wallet_id },
          }
        );
      if (address_book_address_exist) {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].ADDRESS_BOOK_WITH_SAME_ADDRESS_EXIST,
          },
        });
      }

      await address_book_wallet_queries.address_book_wallet_update(
        {
          wallet_address: address_book_wallet_address,
          name: address_book_wallet_name,
        },
        { id: address_book_wallet_id }
      );

      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].ADDRESS_BOOK_CONTACT_NAME_EDIT_SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in user > edit_address_book_wallet.", err);
      await commonHelper.save_error_logs(
        "edit_address_book_wallet",
        err.message
      );
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  // To correct them
  public async announcements(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let { page, limit }: { page: number; limit: number } = req.body;
      let pageNo: number = page || GlblBooleanEnum.true;
      let limitNo: number = limit || 10;
      let offset: number = GlblBooleanEnum.false;
      if (pageNo != GlblBooleanEnum.true) {
        offset = (pageNo - GlblBooleanEnum.true) * limitNo;
      }
      let user_id: number = req.userId;
      let announcements: any = await Models.AnnouncementModel.findAndCountAll({
        attributes: [
          "id",
          "user_id",
          "title",
          "message",
          "created_at",
          "updated_at",
        ],
        where: Sequelize.literal(`FIND_IN_SET('${user_id}',user_id)`),
        order: [["id", "DESC"]],
        raw: true,
        limit: limitNo,
        offset: offset,
      });
      if (announcements) {
        return response.success(res, {
          data: {
            code: GlblCode.SUCCESS,
            status: true,
            data: announcements.rows,
            meta: {
              page: pageNo,
              pages: Math.ceil(announcements.count / limitNo),
              perPage: limitNo,
              total: announcements.count,
            },
          },
        });
      } else {
        return response.error(res, {
          data: {
            code: GlblCode.ERROR_CODE,
            status: false,
            message: language[lang].NO_ANNOUNEMENT,
          },
        });
      }
    } catch (err: any) {
      console.error("error in user > getting announcements", err);
      await commonHelper.save_error_logs("users_announcements", err.message);
      return response.error(res, { data: {} });
    }
  }

  public async announcement_view_status(req: Request, res: Response) {
    try {
      let key: number = req.body.key; // 0 or 1
      let data: any;
      let view_status: any;
      if (key == GlblBooleanEnum.true) {
        // if send 1
        view_status = await Models.NotificationModel.findAll({
          attributes: ["notification_id", "view_status"],
          where: {
            wallet_address: { [Op.in]: req?.body?.addrsListKeys },
            [Op.or]: [{ view_status: 0 }, { view_status: null }],
          },
          raw: true,
        });
        if (view_status.length !== 0) {
          data = {
            new_notifications: 1,
          };
        } else {
          let ann_data: any = await Models.AnnouncementStatusModel.findOne({
            attributes: ["user_id"],
            where: {
              user_id: req.userId,
            },
            raw: true,
          });
          if (ann_data) {
            let seen_data: any = await Models.AnnouncementStatusModel.findOne({
              attributes: ["user_id"],
              where: {
                user_id: req.userId,
                view_status: 1,
              },
              raw: true,
            });
            if (seen_data) {
              data = {
                new_notifications: 0,
              };
            } else {
              data = {
                new_notifications: 1,
              };
            }
          } else {
            data = {
              new_notifications: GlblBooleanEnum.false,
            };
          }
        }
      } else {
        // if send 0 it means all view status to be updated as 1
        await Models.NotificationModel.update(
          {
            view_status: 1,
          },
          {
            where: {
              wallet_address: { [Op.in]: req?.body?.addrsListKeys },
              [Op.or]: [{ view_status: 0 }, { view_status: null }],
            },
          }
        );
        await Models.AnnouncementStatusModel.update(
          {
            view_status: 1,
          },
          {
            where: {
              user_id: req.userId,
            },
          }
        );
        data = {
          new_notifications: 0,
        };
      }
      response.success(res, { data: data });
    } catch (err: any) {
      console.error("Error in announcement_view_status API", err);
      await commonHelper.save_error_logs("users_announcements", err.message);
      return response.error(res, { data: {} });
    }
  }

  /** update user app lanaguage */
  public async update_language(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let user_id: number = req.userId;
      let device_token: string = req.device_token;
      let fiat_currency: string = req.body.fiat_currency
        ? req.body.fiat_currency.toLowerCase()
        : Fiat_Currency.USD;
      await Models.DeviceTokenModel.update(
        { language: lang, fiat_currency: fiat_currency },
        { where: { device_token: device_token, user_id: user_id } }
      );
      return res.status(GlblCode.SUCCESS).send({
        status: true,
        code: GlblCode.SUCCESS,
        message: language[lang].SUCCESS,
        data: {
          language: lang,
          fiat_currency: fiat_currency,
        },
      });
    } catch (err: any) {
      console.error("Error in user > update_language", err);
      await commonHelper.save_error_logs("user_update_language", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  /** get user app language */
  public async get_language(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let data: any = await Models.DeviceTokenModel.findOne({
        attributes: ["language", "device_token", "user_id", "fiat_currency"],
        where: {
          user_id: req.userId,
          device_token: req.device_token,
        },
        raw: true,
        order: [["updated_at", "desc"]],
      });
      return res.status(GlblCode.SUCCESS).send({
        status: true,
        code: GlblCode.SUCCESS,
        message: language[lang].SUCCESS,
        data: {
          language: data.language,
          fiat_currency: data.fiat_currency,
        },
      });
    } catch (err: any) {
      console.error("Error in user > get_language", err);
      await commonHelper.save_error_logs("user_get_language", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  /** get app languages */
  public async app_language(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let data: any = await Models.AppLanguagesModel.findAll({
        attributes: ["name", "code", "image"],
        where: { status: "1" },
      });
      return res.status(GlblCode.SUCCESS).send({
        status: true,
        code: GlblCode.SUCCESS,
        message: language[lang].SUCCESS,
        data: data,
      });
    } catch (err: any) {
      console.error("Error in user > app_language", err);
      await commonHelper.save_error_logs("user_app_language", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async save_referral_code(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let user_id: number = req.userId;
      let device_id: string = req.body.device_id;
      let referral_code: string = req.body.referral_code;
      /** check referral code is valid or not */
      let check_referral_code = await userhelper.referral_code_is_valid(
        referral_code,
        lang
      );
      if (check_referral_code.status) {
        return response.error(res, {
          data: {
            status: false,
            message: check_referral_code.message,
          },
        });
      }
      /** check referral code already exist or not */
      let check_referral_already_used = await userhelper.referral_already_used(
        { device_id: device_id, wallet_address: null, user_id: user_id },
        lang
      );
      if (check_referral_already_used.status) {
        return response.error(res, {
          data: {
            status: false,
            message: check_referral_already_used.message,
          },
        });
      }

      let save_referral_data = await userhelper.save_referral_code(
        {
          user_id: user_id,
          referral_code: referral_code,
          device_id: device_id,
        },
        lang
      );
      if (!save_referral_data.status) {
        return response.error(res, {
          data: {
            status: false,
            message: save_referral_data.message,
          },
        });
      } else {
        return res.status(GlblCode.SUCCESS).send({
          status: true,
          code: GlblCode.SUCCESS,
          message: language[lang].SUCCESS,
        });
      }
    } catch (err: any) {
      console.error("save_referral_code", err);
      await commonHelper.save_error_logs("save_referral_code", err.message);
      return response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async reward_list(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let user_id: number = req.userId;

      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "25") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;

      let where_clause: any = { user_id: user_id };

      let total_amount: number = await Models.RewardHistoryModel.sum("amount", {
        where: where_clause,
      });

      if (search) {
        where_clause = {
          ...where_clause,
          [Op.and]: {
            address: {
              [Op.like]: search,
            },
          },
        };
      }
      let query: any = {
        attributes: [
          "id",
          "address",
          "currency",
          "amount",
          "status",
          "created_at",
        ],
        where: where_clause,
        order: [["id", "DESC"]],
        limit: limit,
        offset: offset,
      };
      let transaction_data: any =
        await Models.RewardHistoryModel.findAndCountAll(query);
      return response.success(res, {
        data: {
          success: true,
          message: GlblCode.SUCCESS,
          data: transaction_data.rows,
          total_amount: total_amount,
          meta: {
            page: page,
            pages: Math.ceil(transaction_data.count / limit),
            perPage: limit,
            total: transaction_data.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > reward_list.", err);
      await commonHelper.save_error_logs("reward_list", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async check_device_id(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let {
        device_id,
        wallet_address,
      }: { device_id: string; wallet_address: string } = req.body;
      /** check referral code already exist or not */
      let check_referral_already_used = await userhelper.referral_already_used(
        { device_id: device_id, wallet_address: wallet_address, user_id: 0 },
        lang
      );
      if (check_referral_already_used.status) {
        return response.success(res, {
          // changed status code as 400 was going
          data: {
            status: false,
            message: check_referral_already_used.message,
          },
        });
      } else {
        return res.status(GlblCode.SUCCESS).send({
          status: true,
          code: GlblCode.SUCCESS,
          message: `Referral code cann't used by anyone.`,
        });
      }
      // let device_check: any = await dbHelper.checkIfuserReferred({ to_device_id: device_id })
      // let message: number;
      // if (device_check) {
      //   message = GlblBooleanEnum.false
      // } else {
      //   let wallet_check: any = await dbHelper.find_one_wallet_table(["email", "user_id", "wallet_id"], { wallet_address: wallet_address })
      //   if (wallet_check) {
      //     let user_took_reward: any = await dbHelper.checkIfuserReferred({ referred_id: wallet_check.user_id })
      //     if (user_took_reward) {
      //       message = GlblBooleanEnum.false
      //     } else {
      //       message = GlblBooleanEnum.true
      //     }
      //   } else {
      //     message = GlblBooleanEnum.false
      //   }
      // }
      // return res.status(GlblCode.SUCCESS).send({
      //   status: true,
      //   code: GlblCode.SUCCESS,
      //   message: message
      // });
    } catch (err: any) {
      console.error("Error in check_device_id.", err);
      await commonHelper.save_error_logs("check_device_id", err.message);
      return response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async add_admin_tokens(req: Request, res: Response) {
    try {
      const file: any = req?.files;
      const buffer: Buffer = file.files.data; // Assuming files.data contains the uploaded file data

      const csvRows: any[] = await new Promise((resolve, reject) => {
        const rows: any[] = [];
        const bufferStream = stream.Readable.from(buffer);

        bufferStream
          .pipe(csv({ headers: false }))
          .on("data", (row) => {
            console.log("CSV Row:", row);
            rows.push(row);
          })
          .on("end", () => resolve(rows))
          .on("error", (err) => reject(err));
      });

      for (const csvRow of csvRows) {
        const cmc_id: number = parseInt(csvRow[0]);
        const coin_name: string = csvRow[1];
        const coin_symbol: string = csvRow[2];
        const network: string = csvRow[5];
        const token_address: string = csvRow[6];

        if (network == "ETH" || network == "TRX" || network == "BNB") {
          const data_exist: any = await Models.CoinsModel.findOne({
            where: { token_address: token_address },
            raw: true,
          });
          if (!data_exist) {
            console.log("network >>,", network);
            let image: string | null = null;
            const symbol: string = coin_symbol;

            const data: any = await global_helper.get_token_image_from_cmc({
              symbol,
              token_address,
            });
            console.log(
              "data>>",
              data,
              "token address >>,",
              token_address,
              "symbol>>>>",
              symbol
            );
            if (data != null) {
              image = data.image;
            }
            if (image) {
              let token_type: string;
              let coin_family: number;
              let token_data: any;

              if (network == "ETH") {
                token_type = "ERC20";
                coin_family = 2;
                token_data = await ethWeb3.searchToken(
                  token_address,
                  "en",
                  true
                );
              } else if (network == "BNB") {
                token_type = "BEP20";
                coin_family = 1;
                token_data = await bscWeb3.searchToken(
                  token_address,
                  "en",
                  true
                );
              } else {
                token_type = "TRC20";
                coin_family = 6;
                token_data = await trxWeb3.searchToken(
                  token_address,
                  "en",
                  true
                );
              }
              if (token_data.decimals) {
                const arrayObj: any = {
                  cmc_id: cmc_id,
                  is_on_cmc: 1,
                  coin_name: coin_name,
                  coin_symbol: coin_symbol,
                  token_address: token_address,
                  decimals: Math.pow(10, parseInt(token_data.decimals)),
                  coin_family: coin_family,
                  coin_image: image,
                  coin_status: GlblBooleanEnum.true, // Assuming GlblBooleanEnum is defined elsewhere
                  is_token: GlblBooleanEnum.true,
                  token_type: token_type,
                  added_by: "admin",
                };

                await Models.CoinsModel.create(arrayObj);
              } else {
                console.log("not getting decimals");
              }
            } else {
              console.log("no image present");
            }
          } else {
            console.log("data exist");
          }
        } else {
          console.log("network not exist");
        }
      }

      return response.success(res, {
        data: {
          success: true,
          message: "success",
        },
      });
    } catch (err: any) {
      console.error("ERROR in user > updating csv", err);
      return response.error(res, { data: (err as Error).message });
    }
  }
  public async add_tokens_for_swap(req: Request, res: Response) {
    try {
      const tokens = req.body.tokens;
      const coin_family = req.body.coin_family;
      if (tokens.length > 0) {
        for await (let token of tokens) {
          const data_exist: any = await Models.CoinsModel.findOne({
            attributes: ["coin_id"],
            where: { token_address: token, coin_family: coin_family },
            raw: true,
          });
          if (data_exist) {
            const arrayObj: any = { for_swap: 1 };
            await Models.CoinsModel.update(arrayObj, {
              where: { coin_id: data_exist.coin_id },
            });
          } else {
            console.log("coin doesn't exist >>>", token);
          }
        }
      }
      return response.success(res, {
        data: {
          success: true,
          message: "success",
        },
      });
    } catch (err: any) {
      console.error("ERROR in tokens > add_tokens_for_swap", err);
      return response.error(res, { data: (err as Error).message });
    }
  }
  // public async add_swap_supported_tokens(req: Request, res: Response) {
  //   try {
  //     const file: any = req?.files;
  //     const buffer = file.files.data;
  //     const csvStr = buffer.toString('utf8');
  //     await csv({
  //       noheader: true,
  //       output: "csv"
  //     })
  //       .fromString(csvStr)
  //       .then(async (csvRow) => {
  //         for (let i = 0; i < csvRow.length; i++) {
  //           let coin_name: string = csvRow[i][3]
  //           let coin_symbol: string = csvRow[i][4]
  //           let coin_image: string = csvRow[i][5]
  //           let decimals: any = csvRow[i][6]
  //           let token_address: string = csvRow[i][7]
  //           let coin_family: number = csvRow[i][10]
  //           let image: any = "";
  //           let data: any;
  //           let cmcId: any;
  //           let cmc: number = GlblBooleanEnum.false;
  //           if (token_address && coin_symbol) {
  //             if (!image) {
  //               let symbol: string = coin_symbol
  //               data = await global_helper.get_token_image_from_cmc({ symbol, token_address });
  //               if (data) {
  //                 if (!coin_image || coin_image == null) {
  //                   coin_image = data.coinImage;
  //                 }
  //                 cmcId = data.cmc_id;
  //                 if (cmcId) {
  //                   cmc = GlblBooleanEnum.true;
  //                 }
  //               }

  //             }
  //           }

  //           if (coin_family == 2) {
  //             let token_type = GlblTokens.ERC20;
  //             let arrayObj: any = {
  //               coin_name: coin_name,
  //               coin_symbol: coin_symbol,
  //               mainnet_token_address: token_address,
  //               coin_image: coin_image ? coin_image : '',
  //               coin_family: 2,
  //               coin_status: GlblBooleanEnum.true,
  //               is_token: GlblBooleanEnum.true,
  //               token_type: token_type,
  //               decimals: Math.pow(10, parseInt(decimals)),
  //               cmc_id: cmcId,
  //               is_on_cmc: cmc,
  //               token_address: token_address,
  //               for_swap: GlblBooleanEnum.true,
  //               added_by: GlblAddedBy.SWAP
  //             }
  //             let data_exist: any = await Models.CoinsModel.findOne({ where: { token_address: token_address }, raw: true });
  //             if (data_exist) {
  //               await Models.CoinsModel.update({
  //                 mainnet_token_address: token_address,
  //                 coin_image: coin_image,
  //                 token_type: token_type,
  //                 decimals: Math.pow(10, parseInt(decimals)),
  //                 cmc_id: cmcId,
  //                 is_on_cmc: cmc,
  //                 for_swap: GlblBooleanEnum.true
  //               }, {
  //                 where: {
  //                   token_address: token_address
  //                 }
  //               });

  //             }

  //             if (!data_exist) {
  //               await Models.CoinsModel.create(arrayObj);
  //             }
  //           }
  //         }
  //       });
  //     return response.success(res, {
  //       data: {
  //         success: true,
  //         message: GlblMessages.SUCCESS,
  //       }
  //     });
  //   } catch (err: any) {
  //     console.error("ERROR in user > updating csv", err)
  //     return response.error(res, { data: (err as Error).message });
  //   }
  // }

  public async update_user_login_time(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const findUser = await Models.UsersModel.findOne({
        where: {
          user_id: req?.userId,
        },
      });

      //--------------------------
      let userId = req?.userId;
      if (findUser) {
        if (findUser.login_time) {
          let newDateObj = moment(findUser?.login_time).add(2, "h").toDate();

          let newDateObj1 = moment(new Date()).toDate();

          if (newDateObj < newDateObj1) {
            console.log("if login_time is not up to  2 hrs ");
            await Models.UsersModel.update(
              {
                login_time: moment(new Date()).toDate(),
              },
              {
                where: {
                  user_id: userId,
                },
              }
            );
          } else {
            console.log("Login time is before 2 hours ");
          }
        } else {
          await Models.UsersModel.update(
            {
              login_time: moment(new Date()).toDate(),
            },
            {
              where: {
                user_id: userId,
              },
            }
          );
        }
      }

      return response.success(res, {
        data: {
          code: GlblCode.SUCCESS,
          status: true,
          message: language[lang].UPDATED,
        },
      });
    } catch (err: any) {
      console.error("Error in user > add_login_time.", err);
      await commonHelper.save_error_logs("add_login_time", err.message);
      return response.error(res, {
        data: {
          data: [],
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async editWalletName(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const wallet_name = req.body.wallet_name;

      if (!wallet_name) {
        throw new Error("No Wallet Name Provided");
      }

      if (wallet_name) {
        if (wallet_name?.length > 25 || wallet_name?.length < 3) {
          throw new Error(
            "wallet Name should be greater than 3 and less than 25"
          );
        }
      }

      console.log("userId::", wallet_name + " " + req.userId);
      const userUpdated = await Models.UsersModel.update(
        {
          user_name: wallet_name,
        },
        {
          where: {
            user_id: req.userId,
          },
        }
      );

      const walletUpdated = await Models.WalletModel.update(
        {
          wallet_name: wallet_name,
        },
        {
          where: {
            user_id: req.userId,
          },
        }
      );

      console.log("userUpdated::", userUpdated);
      console.log("walletUpdated::", walletUpdated);

      return response.success(res, {
        data: {
          status: true,
          data: {
            message: language[lang].EDIT_SUCCESSFULLY,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in user > editWalletName.", err);
      await commonHelper.save_error_logs("editWalletName", err.message);
      return response.error(res, {
        data: {
          code: GlblCode.ERROR_CODE,
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
}

export const userController = new UserController();
