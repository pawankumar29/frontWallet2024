import { Joi } from 'express-validation';

export default class user_validator {
    static create_wallet_validate = {
        body: Joi.object({
            // email: Joi.string().required(),
            wallet_address: Joi.string().required(),
            device_token: Joi.string().required(),
            wallet_name: Joi.string().required(),
            addressList: Joi.array().required(),
            // login_type: Joi.string().optional(),
            // social_id: Joi.string().optional(),
            referral_code: Joi.string().allow(null, '').optional(),
            device_id: Joi.string().allow(null, '').optional(),
            fiat_currency: Joi.string().allow(null, '').optional(),
            lang: Joi.string().allow(null, '').optional()
        })
    }
    static notificationList_validate = {
        body: Joi.object({
            limit: Joi.number().optional(),
            page: Joi.number().optional(),
            addrsListKeys: Joi.array().required(),
            coin_family: Joi.array().required(),
        })
    }
    static logout_validate = {
        body: Joi.object({
            deviceToken: Joi.string().required(),
        })
    }
    static add_address_book_validate = {
        body: Joi.object({
            contact_name: Joi.string().required(),
            wallet_address: Joi.string().required(),
            address: Joi.string().required(),
            coin_family: Joi.number().required(),
            wallet_name: Joi.string().allow(null, '').optional(),
        })
    }
    static page_list_validate = {
        body: Joi.object({
            limit: Joi.number().required(),
            page: Joi.number().required(),
            address: Joi.array().required(),
            coin_family: Joi.array().optional(),
            search: Joi.string().allow(null, '').optional(),
        })
    }
    static get_wallet_name = {
        body: Joi.object({
            contact_name: Joi.string().required(),
            coin_family: Joi.number().optional(),
            wallet_name: Joi.string().allow(null, '').optional(),
            address: Joi.string().required(),
        })
    }
    static search = {
        body: Joi.object({
            search: Joi.string().allow(null, '').optional(),
        })
    }
    static delete_address_book_wallet_address = {
        body: Joi.object({
            id: Joi.number().required(),
            address_book_id: Joi.number().required()
        })
    }
    static delete_address_book = {
        body: Joi.object({
            id: Joi.number().required(),
        })
    }
    static edit_address_book_contact_name = {
        body: Joi.object({
            address_book_id: Joi.number().required(),
            address_book_name: Joi.string().required()
        })
    }
    static edit_address_book_wallet = {
        body: Joi.object({
            address_book_id: Joi.number().required(),
            address_book_wallet_name: Joi.string().required(),
            address_book_wallet_address: Joi.string().required(),
            address_book_wallet_id: Joi.number().required()
        })

    }
    static announcements = {
        body: Joi.object({
            limit: Joi.number().optional(),
            page: Joi.number().optional(),
        })
    }
    static announcement_view_status = {
        body: Joi.object({
            key: Joi.number().required(),
            addrsListKeys: Joi.array().required()
        })
    }
    static contact_admin = {
        body: Joi.object({
            name: Joi.string().required(),
            email: Joi.string().required(),
            subject: Joi.string().required(),
            message: Joi.string().required(),
            category: Joi.string().required(),
            wallet_address: Joi.string().allow('').optional(),
            trnx_links: Joi.string().allow('').optional(),
            screenshots: Joi.array().optional()
        })
    }
    static queries = {
        body: Joi.object({
            status: Joi.number().required(),
            page: Joi.number().optional(),
            limit: Joi.number().optional()
        })
    }
    static update_language = {
        body: Joi.object({
            fiat_currency: Joi.string().required()
        })
    }
    static check_device_id = {
        body: Joi.object({
            device_id: Joi.string().required(),
            wallet_address: Joi.string().required()
        })
    }
    static save_referral_code = {
        body: Joi.object({
            device_id: Joi.string().required(),
            referral_code: Joi.string().required()
        })
    }
}