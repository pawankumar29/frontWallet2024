import express from "express";
import { validate } from "express-validation"
import { ControllerInterface } from "../../interfaces/controller.interface";
import jwtVerification from "../../middlewares/verify.middleware";
import { userController } from "./controller";
import validator from "./validator";

class UserRoute implements ControllerInterface {
  public path = "/user";
  public router = express.Router();

  constructor() {
    this.initializeRoutes();
  }

  public initializeRoutes() {
    // this.router.post(`${this.path}/add_coins_through_script`, userController.add_admin_tokens)
    // this.router.post(`${this.path}/add_tokens_for_swap`, userController.add_tokens_for_swap)

    this.router.post(`${this.path}/check_device_id`, [validate(validator.check_device_id)], userController.check_device_id);

    this.router.post(`${this.path}/create/wallet`, [validate(validator.create_wallet_validate)], userController.createWallet);
    this.router.post(`${this.path}/notification/list`, [validate(validator.notificationList_validate)], jwtVerification.verifyToken, userController.notificationList);
    this.router.post(`${this.path}/logout`, [validate(validator.logout_validate)], jwtVerification.verifyToken, userController.userLogout);
    this.router.post(`${this.path}/add_address_book`, [validate(validator.add_address_book_validate)], jwtVerification.verifyToken, userController.add_address_book);
    this.router.post(`${this.path}/address_book`, [validate(validator.page_list_validate)], jwtVerification.verifyToken, userController.address_book);
    this.router.post(`${this.path}/get_wallet_name`, [validate(validator.get_wallet_name)], jwtVerification.verifyToken, userController.get_wallet_name);
    this.router.post(`${this.path}/search`, [validate(validator.search)], jwtVerification.verifyToken, userController.search);
    this.router.post(`${this.path}/delete_address_book_wallet_address`, [validate(validator.delete_address_book_wallet_address)], jwtVerification.verifyToken, userController.delete_address_book_wallet_address);
    this.router.post(`${this.path}/delete_address_book`, [validate(validator.delete_address_book)], jwtVerification.verifyToken, userController.delete_address_book);
    
    this.router.post(`${this.path}/edit_address_book_contact_name`,
      [validate(validator.edit_address_book_contact_name)],
      jwtVerification.verifyToken,
      userController.edit_address_book_contact_name);

    this.router.post(`${this.path}/edit_address_book_wallet`,
      [validate(validator.edit_address_book_wallet)],
      jwtVerification.verifyToken,
      userController.edit_address_book_wallet);

    // this.router.post(`${this.path}/add_admin_tokens`, userController.add_admin_tokens)
    // this.router.post(`${this.path}/add_swap_supported_tokens`, userController.add_swap_supported_tokens)
    this.router.post(`${this.path}/announcements`, [validate(validator.announcements)], jwtVerification.verifyToken, userController.announcements);
    this.router.post(`${this.path}/announcement/view_status`, [validate(validator.announcement_view_status)], jwtVerification.verifyToken, userController.announcement_view_status);
    this.router.post(`${this.path}/update_language`, [validate(validator.update_language)], jwtVerification.verifyToken, userController.update_language);
    this.router.get(`${this.path}/get_language`, jwtVerification.verifyToken, userController.get_language);
    this.router.get(`${this.path}/app_language`, jwtVerification.verifyToken, userController.app_language);
    this.router.post(`${this.path}/save_referral_code`, [validate(validator.save_referral_code)], jwtVerification.verifyToken, userController.save_referral_code);
    this.router.post(`${this.path}/reward_list`, jwtVerification.verifyToken, userController.reward_list);
    this.router.post(`${this.path}/edit`, jwtVerification.verifyToken, userController.editWalletName);
    this.router.post(`${this.path}/update_user_login_time`, jwtVerification.verifyToken,userController.update_user_login_time);


  }
}

export default UserRoute;
