
import { config } from "../../../config";
import axios, { AxiosInstance } from "axios";

//class UTXO {
let utxoClass = class UTXO {
    // private clientUrl = config.NODE.BTC_RPC_URL;
    // private axiosClient: AxiosInstance;
    public config: any;

    constructor() {
        this.config = {
            method: 'get',
            headers: {
                'apikey': `${config.NODE.BTC_API_KEY}`,
                'Content-Type': 'application/json',
            }
        };
        // this.axiosClient = axios.create({
        //     baseURL: this.clientUrl,
        //     headers: {
        //         // Authorization: this.clineAPIKEY,
        //         "Content-Type": "application/json",
        //     },
        // });
    }

    public async sendRawTransaction(raw: string) {
        try {
            this.config.url = `${config.NODE.BTC_RPC_URL}api/v2/sendtx/${raw}`
            let response: any = await axios(this.config);
            return response.data;
        } catch (err: any) {
            return (err as Error).message;
        }
    }
};

let utxo = new utxoClass();

export const BtcHelper = utxo;
