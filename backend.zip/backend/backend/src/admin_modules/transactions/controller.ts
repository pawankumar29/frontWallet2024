import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";
import moment from "moment";
import {
  Fiat_Currency,
  GlblBlockchainTxStatusEnum,
  GlblBooleanEnum,
  GlblMessages,
  GlblCode,
  TxTypesEnum,
} from "./../../constants/global_enum";
import commonHelper from "../../helpers/common/common.helpers";
import { Op, Sequelize } from "sequelize";
import response from "../../helpers/response/response.helpers";
import { language } from "../../constants";
import { Parser } from "json2csv";
import { MakeFirstLettarCapital, formatDateWithAmPm } from "../helper/helper";
const IP = require("ip");

class TransactionController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() {}
  public async transactions(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      //searchBy

      // for frontend changes to lowercase
      let orderBy =
        req.body.orderBy?.toLowerCase() === "ascending" ? "ASC" : "DESC";
      //-----------
      let filterType = req.body.filterType;

      let entityType = req.body.entity_type || null;

      // for frontend changes to lowercase
      let orderByofEntity =
        req.body.entity_type_order?.toLowerCase() === "ascending"
          ? "ASC"
          : "DESC";
      //-----------------------
      let setOrder: any = null;

      //searchBy

      let address_list: any = req.body.addrsListKeys
        ? req.body.addrsListKeys
        : [];
      let searchBy: any =
        req.body.searchBy == undefined
          ? (req.body.searchBy = "%%")
          : (req.body.searchBy = "%" + req.body.searchBy + "%");
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "25") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let coin_id: number =
        req.body.coin_id == undefined
          ? (req.body.coin_id = GlblBooleanEnum.false)
          : req.body.coin_id;
      let status: GlblBlockchainTxStatusEnum | any =
        req.body.status == undefined
          ? (req.body.status = null)
          : req.body.status;
      let date_from: number = req.body.date_from ? req.body.date_from : null;
      let date_to: number = req.body.date_to ? req.body.date_to : null;
      let type: any = req.body.trnx_type ? req.body.trnx_type : "All";
      // let coin_family: any = req.body.coin_family ? req.body.coin_family : [];

      let where_clause: any = {};

      console.log("filterType:", filterType);
      console.log("searchBy:", searchBy);

      // convert into lowercase for the frontend changes
      type = type?.toLowerCase();
      status = status?.toLowerCase();
     // filterType=filterType?.toLowerCase();

      if (type == TxTypesEnum.DEPOSIT) {
        where_clause = {
          // to_adrs: {
          //   [Op.in]: address_list,
          // },
          blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
          type: TxTypesEnum.DEPOSIT,

          // [Op.or]: [
          //   { type: TxTypesEnum.WITHDRAW },
          //   { type: TxTypesEnum.DEPOSIT },
          // ],
        };
      }
      if (type == TxTypesEnum.WITHDRAW) {
        where_clause = {
          // from_adrs: {
          //   [Op.in]: address_list,
          // },
          type: TxTypesEnum.WITHDRAW,
          [Op.or]: [
            { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
            { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
            { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
            { blockchain_status: null },
          ],
          // [Op.or]: [
          //   { type: TxTypesEnum.WITHDRAW },
          //   { type: TxTypesEnum.DEPOSIT },
          // ],
        };
      }

      if (type == TxTypesEnum.DEPOSIT && searchBy !== "") {
        where_clause = {
          [Op.or]: [
            {
              to_adrs: {
                [Op.like]: searchBy,
              },
            },
            // {
            //   from_adrs: {
            //     [Op.like]: searchBy,
            //   },
            // },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },

            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],

          blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
          type: TxTypesEnum.DEPOSIT,
        };
      }
      if (type == TxTypesEnum.WITHDRAW && searchBy !== "") {
        where_clause = {
          [Op.or]: [
            {
              from_adrs: {
                [Op.like]: searchBy,
              },
            },
            // {
            //   to_adrs: {
            //     [Op.like]: searchBy,
            //   },
            // },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],

          type: TxTypesEnum.WITHDRAW,
          [Op.or]: [
            { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
            { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
            { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
            { blockchain_status: null },
          ],
        };
      }

      if (type == TxTypesEnum.SWAP) {
        where_clause = {
          [Op.and]: [
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DEPOSIT}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.WITHDRAW}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.BUY}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
          ],
          [Op.or]: [{ type: "Swap" }, { type: "cross_chain" }],

          // [Op.or]: [
          //   { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
          //   { blockchain_status: null },
          // ],
        };
      }

      if (type == TxTypesEnum.SWAP && searchBy !== "") {
        where_clause = {
          [Op.and]: [
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DEPOSIT}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.WITHDRAW}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.BUY}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
          ],
          [Op.or]: [{ type: "Swap" }, { type: "cross_chain" }],
          [Op.or]: [
            {
              from_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },
            {
              to_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],

          // [Op.or]: [
          //   { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
          //   { blockchain_status: null },
          // ],
        };
      }

      //
      if (type == TxTypesEnum.DAPP || type==="DApp") {
        where_clause = {
          type: TxTypesEnum.DAPP
          // [Op.or]: [
          //   { type: TxTypesEnum.DAPP },
          //   // { type: TxTypesEnum.APPROVE },
          //   // { type: TxTypesEnum.SWAP },
          //   // { type: TxTypesEnum.CROSS_CHAIN },
          // ],
          // from_adrs: {
          //   [Op.like]: searchBy,
          // },
        };
      }
      if ((type == TxTypesEnum.DAPP ||  type==="DApp") && searchBy !== "") {
        where_clause = {
          [Op.or]: [
            {
              from_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              to_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },

            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],
          // [Op.or]: [
          //   { type: TxTypesEnum.DAPP },
          //   // { type: TxTypesEnum.APPROVE },
          //   // { type: TxTypesEnum.SWAP },
          //   // { type: TxTypesEnum.CROSS_CHAIN },
          // ]
          type: TxTypesEnum.DAPP
         
        };
      }
      if (type == TxTypesEnum.BUY) {
        where_clause = {
          to_adrs: {
            [Op.like]: searchBy,
          },
          type: TxTypesEnum.BUY,
        };
      }
      if (type == TxTypesEnum.SELL) {
        where_clause = {
          to_adrs: {
            [Op.like]: searchBy,
          },
          type: TxTypesEnum.SELL,
        };
      }
      // if (type == TxTypesEnum.CARDS) {
      //   where_clause = {
      //     [Op.or]: [
      //       { type: TxTypesEnum.CARD_FEES },
      //       { type: TxTypesEnum.CARD_RECHARGE },
      //     ],
      //     from_adrs: {
      //       [Op.in]: address_list,
      //     },
      //   };
      // }
      // if (type == TxTypesEnum.LEVEL_UPGRADE) {
      //   where_clause = {
      //     type: TxTypesEnum.LEVEL_UPGRADATION_LEVEL,
      //     from_adrs: {
      //       [Op.in]: address_list,
      //     },
      //   };
      // }
      if (status && status !== "all") {
        where_clause = {
          ...where_clause,
          blockchain_status: status,
        };
      }

      //   if (coin_family) {
      //     where_clause = {
      //       ...where_clause,
      //       coin_family: { [Op.in]: coin_family },
      //     };
      //   }
      if (date_from && date_to) {
        where_clause = {
          ...where_clause,
          [Op.and]: Sequelize.literal(
            `DATE(trnx_history.created_at) BETWEEN '${date_from}' and '${date_to}'`
          ),
        };
      }
      let coin_where: any = "";
      if (coin_id > GlblBooleanEnum.false) {
        where_clause = {
          ...where_clause,
          coin_id: coin_id,
        };
      }

      // search

      if (filterType === "FromAddress" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          from_adrs: {
            [Op.like]: searchBy,
          },
        };
      } else if (filterType === "ToAddress" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          to_adrs: {
            [Op.like]: searchBy,
          },
        };
      } else if (filterType === "CoinName" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          [Op.or]: [
            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],
        };
      } else if (filterType === "Hash" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          tx_id: {
            [Op.like]: searchBy,
          },
        };
      } else {
        if (filterType === "All" && searchBy !== "" && searchBy) {
          where_clause = {
            ...where_clause,
            [Op.or]: [
              {
                from_adrs: {
                  [Op.like]: searchBy,
                },
              },
              {
                to_adrs: {
                  [Op.like]: searchBy,
                },
              },
              {
                tx_id: {
                  [Op.like]: searchBy,
                },
              },
              {
                [Op.or]: [
                  {
                    "$coin_transation_data.coin_name$": {
                      [Op.like]: searchBy,
                    },
                  },
                  {
                    "$coin_transation_data.coin_symbol$": {
                      [Op.like]: searchBy,
                    },
                  },
                ],
              },
            ],
          };
        }
      }

      // search by entity type
      if (entityType && orderByofEntity) {
        orderByofEntity.toLowerCase() === "ascending" ? "ASC" : "DESC";
        switch (entityType) {
          case "DateOrder":
            setOrder = [["created_at", orderByofEntity]];
            break;

          case "UsdAmount":
            setOrder = [["usd_amount", orderByofEntity]];
            break;

          case "CryptoAmount":
            setOrder = [["amount", orderByofEntity]];
            break;
        }
      }

      // search by entity type

      console.log("where_clause::", where_clause);

      //console.log("sdjfjdsjfjds",filterType === "coin_name" && searchBy !== "" && searchBy);
      let query: any = {
        attributes: [
          "id",
          [
            Sequelize.literal(
              "(SELECT value FROM coin_price_in_fiats WHERE cmc_id = coin_transation_data.cmc_id AND fiat_type = 'usd') * amount"
            ),
            "usd_amount",
          ],
          "type",
          "tx_fee",
          "tx_id",
          "user_id",
          "req_type",
          "from_adrs",
          "to_adrs",
          "coin_family",
          "tx_raw",
          "order_id",
          "status",
          "blockchain_status",
          "coin_id",
          "amount",
          "fiat_price",
          "fiat_type",
          "created_at",
          "updated_at",
          "referral_upgrade_level",
        ],
        where: where_clause,
        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_symbol", "coin_name", "coin_image"],
            as: "coin_transation_data",
            //  where: Sequelize.literal(coin_where),
            where: coin_where,
            required: false,
            include: [
              {
                model: Models.CoinPriceInFiatModel,
                as: "fiat_price_data",
                attributes: [
                  "fiat_type",
                  "value",
                  "price_change_24h",
                  "price_change_percentage_24h",
                ],
                where: { fiat_type: "usd" },
                required: false,
              },
            ],
          },
        ],
        order: setOrder ? setOrder : [["created_at", orderBy]],
        limit: limit,
        offset: offset,
        // logging: true,
      };
      let transaction_data: any = await Models.TrnxHistoryModel.findAndCountAll(
        query
      );

      console.log("query Tx", query);

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: transaction_data?.rows,
          meta: {
            page: page,
            pages: Math.ceil(transaction_data?.count / limit),
            perPage: limit,
            total: transaction_data.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > transactions.", err);
      await commonHelper.save_error_logs("wallet_transactions", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async swap_transaction(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let fiat_currency: string = String(
        req.body.fiat_currency ? req.body.fiat_currency : Fiat_Currency.USD
      );
      let coin_ids: any =
        req.body.coin_ids == undefined ? [] : req.body.coin_ids;

      let where_clause: any = {
        coin_id: {
          [Op.in]: coin_ids,
        },
      };

      //   let query: any = {
      //     attributes: ["coin_symbol", "coin_name", "coin_image", "coin_id"],
      //     include: [
      //       {
      //         model: Models.TrnxHistoryModel,
      //         attributes: [
      //           "id",
      //           [Sequelize.literal(`SUM(amount)`), "total_swap_amount"],
      //           "fiat_price",
      //           "fiat_type",
      //         ],
      //         as: "coin_transation_data",
      //         where: {
      //           blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
      //           type: TxTypesEnum.SWAP,
      //         },
      //         required: false,
      //       },

      //       {
      //         model: Models.CoinPriceInFiatModel,
      //         as: "fiat_price_data",
      //         attributes: ["fiat_type", "value", "latest_price"],
      //         where: { fiat_type: fiat_currency },
      //         required: false,
      //       },
      //     ],
      //     group: ["coin_id"],
      //     where: where_clause,
      //     logging: true,
      //   };

      let query: any = {
        attributes: [
          "coin_symbol",
          "coin_name",
          "coin_image",
          "coin_id",
          "coin_family",
          "is_token",
          // [
          //   Sequelize.literal(
          //     `(case when coin_transation_data.coin_family=2 and coin_transation_data.is_token=1 then 'ERC20' when coin_transation_data.coin_family=1 and coin_transation_data.is_token=1 then 'BEP20' when coin_transation_data.coin_family=6 and coin_transation_data.is_token=1 then 'TRC20' END) `
          //   ),
          //   "token_type",
          // ],
          "token_type"
        ],
        include: [
          {
            model: Models.TrnxHistoryModel,
            attributes: [
              "id",
              [Sequelize.literal(`SUM(amount)`), "total_swap_amount"],
              "fiat_price",
              "fiat_type",
            ],
            as: "coin_transation_data",
            where: {
              blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
              type: "Swap",
            },
            required: false,
          },

          {
            model: Models.CoinPriceInFiatModel,
            as: "fiat_price_data",
            attributes: ["fiat_type", "value", "latest_price", "coin_id"],
            where: { fiat_type: fiat_currency },
            required: false,
          },
        ],
        group: ["coin_id"],
        where: where_clause,
        //logging: true,
      };
      //   console.log("query==>",query);
      let transaction_data: any = await Models.CoinsModel.findAll(query);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: transaction_data,
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > swap_transaction.", err);
      await commonHelper.save_error_logs("swap_transaction", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async swap_coins(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let coin_symbols: any = req.body.coin_symbols;
      let token_symbols: any = req.body.token_symbols;

      console.log("coin_symbols::", coin_symbols); //["eth","bnb","trx"]
      console.log("token_symbols::", token_symbols); //["usdt"]

      // Coin Data
      let coin_data: any = await Models.CoinsModel.findAll({
        attributes: ["coin_id", "coin_symbol"],
        where: {
          coin_symbol: { [Op.in]: req.body.coin_symbols },
          is_token: 0,
        },
      });

      // Token Data
      let token_data: any = await Models.CoinsModel.findAll({
        attributes: ["coin_id", "coin_symbol"],
        where: {
          coin_symbol: { [Op.in]: req.body.token_symbols },
          is_token: 1,
        },
      });

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: {
            coin_data: coin_data,
            token_data: token_data,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > swap_coins.", err);
      await commonHelper.save_error_logs("swap_coins", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async downloadCsv(req: Request | any, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      //searchBy

      let orderBy =
        req.query.orderBy?.toLowerCase() === "ascending" ? "ASC" : "DESC";

      let filterType = req.query.filterType;

      let entityType = req.query.entity_type;

      let orderByofEntity =
        req.query.entity_type_order?.toLowerCase() === "ascending"
          ? "ASC"
          : "DESC";

      let setOrder: any = null;
      //searchBy

      // let address_list: any = req.body.addrsListKeys
      //   ? req.body.addrsListKeys
      //   : [];
      let searchBy: any =
        req.query.searchBy == undefined
          ? (req.query.searchBy = "%%")
          : (req.query.searchBy = "%" + req.query.searchBy + "%");
      let limit: number = Number(
        req.query.limit == undefined
          ? (req.query.limit = "25")
          : req.query.limit
      );
      let page: number = Number(
        req.query.page == undefined ? (req.query.page = "1") : req.query.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let coin_id: number =
        req.query.coin_id == undefined
          ? (req.query.coin_id = GlblBooleanEnum.false)
          : req.query.coin_id;
      let status: GlblBlockchainTxStatusEnum | any =
        req.query.status == undefined
          ? (req.query.status = null)
          : req.query.status;
      let date_from: number = req.query.date_from ? req.query.date_from : null;
      let date_to: number = req.query.date_to ? req.query.date_to : null;
      let type: any = req.query.trnx_type ? req.query.trnx_type : "All";
      // let coin_family: any = req.body.coin_family ? req.body.coin_family : [];

      type = type?.toLowerCase();
      status = status?.toLowerCase();

      let where_clause: any = {};

    
      if (type == TxTypesEnum.DEPOSIT) {
        where_clause = {
          // to_adrs: {
          //   [Op.in]: address_list,
          // },
          blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
          type: TxTypesEnum.DEPOSIT,

          // [Op.or]: [
          //   { type: TxTypesEnum.WITHDRAW },
          //   { type: TxTypesEnum.DEPOSIT },
          // ],
        };
      }
      if (type == TxTypesEnum.WITHDRAW) {
        where_clause = {
          // from_adrs: {
          //   [Op.in]: address_list,
          // },
          type: TxTypesEnum.WITHDRAW,
          [Op.or]: [
            { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
            { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
            { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
            { blockchain_status: null },
          ],
          // [Op.or]: [
          //   { type: TxTypesEnum.WITHDRAW },
          //   { type: TxTypesEnum.DEPOSIT },
          // ],
        };
      }

      if (type == TxTypesEnum.DEPOSIT && searchBy !== "") {
        where_clause = {
          [Op.or]: [
            {
              to_adrs: {
                [Op.like]: searchBy,
              },
            },
            // {
            //   from_adrs: {
            //     [Op.like]: searchBy,
            //   },
            // },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },

            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],

          blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
          type: TxTypesEnum.DEPOSIT,
        };
      }
      if (type == TxTypesEnum.WITHDRAW && searchBy !== "") {
        where_clause = {
          [Op.or]: [
            {
              from_adrs: {
                [Op.like]: searchBy,
              },
            },
            // {
            //   to_adrs: {
            //     [Op.like]: searchBy,
            //   },
            // },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],

          type: TxTypesEnum.WITHDRAW,
          [Op.or]: [
            { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
            { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
            { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
            { blockchain_status: null },
          ],
        };
      }

      if (type == TxTypesEnum.SWAP) {
        where_clause = {
          [Op.and]: [
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DEPOSIT}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.WITHDRAW}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.BUY}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
          ],
          [Op.or]: [{ type: "Swap" }, { type: "cross_chain" }],

          // [Op.or]: [
          //   { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
          //   { blockchain_status: null },
          // ],
        };
      }

      if (type == TxTypesEnum.SWAP && searchBy !== "") {
        where_clause = {
          [Op.and]: [
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DEPOSIT}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.WITHDRAW}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.BUY}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
          ],
          [Op.or]: [{ type: "Swap" }, { type: "cross_chain" }],
          [Op.or]: [
            {
              from_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },
            {
              to_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],

          // [Op.or]: [
          //   { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
          //   { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
          //   { blockchain_status: null },
          // ],
        };
      }

      //
      if (type == TxTypesEnum.DAPP || type==="DApp") {
        where_clause = {
          type: TxTypesEnum.DAPP
          // [Op.or]: [
          //   { type: TxTypesEnum.DAPP },
          //   // { type: TxTypesEnum.APPROVE },
          //   // { type: TxTypesEnum.SWAP },
          //   // { type: TxTypesEnum.CROSS_CHAIN },
          // ],
          // from_adrs: {
          //   [Op.like]: searchBy,
          // },
        };
      }
      if ((type == TxTypesEnum.DAPP ||  type==="DApp") && searchBy !== "") {
        where_clause = {
          [Op.or]: [
            {
              from_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              to_adrs: {
                [Op.like]: searchBy,
              },
            },
            {
              tx_id: {
                [Op.like]: searchBy,
              },
            },

            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],
          // [Op.or]: [
          //   { type: TxTypesEnum.DAPP },
          //   // { type: TxTypesEnum.APPROVE },
          //   // { type: TxTypesEnum.SWAP },
          //   // { type: TxTypesEnum.CROSS_CHAIN },
          // ]
          type: TxTypesEnum.DAPP
         
        };
      }

      if (type == TxTypesEnum.BUY) {
        where_clause = {
          to_adrs: {
            [Op.like]: searchBy,
          },
          type: TxTypesEnum.BUY,
        };
      }
      if (type == TxTypesEnum.SELL) {
        where_clause = {
          to_adrs: {
            [Op.like]: searchBy,
          },
          type: TxTypesEnum.SELL,
        };
      }
      // if (type == TxTypesEnum.CARDS) {
      //   where_clause = {
      //     [Op.or]: [
      //       { type: TxTypesEnum.CARD_FEES },
      //       { type: TxTypesEnum.CARD_RECHARGE },
      //     ],
      //     from_adrs: {
      //       [Op.in]: address_list,
      //     },
      //   };
      // }
      // if (type == TxTypesEnum.LEVEL_UPGRADE) {
      //   where_clause = {
      //     type: TxTypesEnum.LEVEL_UPGRADATION_LEVEL,
      //     from_adrs: {
      //       [Op.in]: address_list,
      //     },
      //   };
      // }
      if (status && status !== "all") {
        where_clause = {
          ...where_clause,
          blockchain_status: status,
        };
      }

      //   if (coin_family) {
      //     where_clause = {
      //       ...where_clause,
      //       coin_family: { [Op.in]: coin_family },
      //     };
      //   }
      if (date_from && date_to) {
        where_clause = {
          ...where_clause,
          [Op.and]: Sequelize.literal(
            `DATE(trnx_history.created_at) BETWEEN '${date_from}' and '${date_to}'`
          ),
        };
      }
      let coin_where: any = "";
      if (coin_id > GlblBooleanEnum.false) {
        where_clause = {
          ...where_clause,
          coin_id: coin_id,
        };
      }

      // search

      if (filterType === "FromAddress" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          from_adrs: {
            [Op.like]: searchBy,
          },
        };
      } else if (filterType === "ToAddress" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          to_adrs: {
            [Op.like]: searchBy,
          },
        };
      } else if (filterType === "CoinName" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          [Op.or]: [
            {
              "$coin_transation_data.coin_name$": {
                [Op.like]: searchBy,
              },
            },
            {
              "$coin_transation_data.coin_symbol$": {
                [Op.like]: searchBy,
              },
            },
          ],
        };
      } else if (filterType === "Hash" && searchBy !== "" && searchBy) {
        where_clause = {
          ...where_clause,
          tx_id: {
            [Op.like]: searchBy,
          },
        };
      } else {
        if (filterType === "All" && searchBy !== "" && searchBy) {
          where_clause = {
            ...where_clause,
            [Op.or]: [
              {
                from_adrs: {
                  [Op.like]: searchBy,
                },
              },
              {
                to_adrs: {
                  [Op.like]: searchBy,
                },
              },
              {
                tx_id: {
                  [Op.like]: searchBy,
                },
              },
              {
                [Op.or]: [
                  {
                    "$coin_transation_data.coin_name$": {
                      [Op.like]: searchBy,
                    },
                  },
                  {
                    "$coin_transation_data.coin_symbol$": {
                      [Op.like]: searchBy,
                    },
                  },
                ],
              },
            ],
          };
        }
      }

      // search by entity type
      if (entityType && orderByofEntity) {
        orderByofEntity.toLowerCase() === "ascending" ? "ASC" : "DESC";
        switch (entityType) {
          case "DateOrder":
            setOrder = [["created_at", orderByofEntity]];
            break;

          case "UsdAmount":
            setOrder = [["usd_amount", orderByofEntity]];
            break;

          case "CryptoAmount":
            setOrder = [["amount", orderByofEntity]];
            break;
        }
      }

      // search by entity type

      console.log("where_clause::", where_clause);

      //console.log("sdjfjdsjfjds",filterType === "coin_name" && searchBy !== "" && searchBy);
      let query: any = {
        attributes: [
          "id",
          [
            Sequelize.literal(
              "(SELECT value FROM coin_price_in_fiats WHERE cmc_id = coin_transation_data.cmc_id AND fiat_type = 'usd') * amount"
            ),
            "usd_amount",
          ],
          "type",
          "tx_fee",
          "tx_id",
          "user_id",
          "req_type",
          "from_adrs",
          "to_adrs",
          "coin_family",
          "tx_raw",
          "order_id",
          "status",
          "blockchain_status",
          "coin_id",
          "amount",
          "fiat_price",
          "fiat_type",
          "created_at",
          "updated_at",
          "referral_upgrade_level",
        ],
        where: where_clause,
        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_symbol", "coin_name", "coin_image"],
            as: "coin_transation_data",
            //  where: Sequelize.literal(coin_where),
            where: coin_where,
            required: false,
            include: [
              {
                model: Models.CoinPriceInFiatModel,
                as: "fiat_price_data",
                attributes: [
                  "fiat_type",
                  "value",
                  "price_change_24h",
                  "price_change_percentage_24h",
                ],
                where: { fiat_type: "usd" },
                required: false,
              },
            ],
          },
        ],
        order: setOrder ? setOrder : [["created_at", orderBy]],
        limit: limit,
        offset: offset,
        // logging: true,
      };
      let transaction_data: any = await Models.TrnxHistoryModel.findAndCountAll(
        query
      );

      //  console.log("transaction_data", transaction_data);

      const data: any = [];

      transaction_data.rows.map(async (obj: any) => {
        obj.coin_name = obj.coin_transation_data?.coin_name;
        obj.usd_amount =
          obj.coin_transation_data?.fiat_price_data?.value * obj?.amount;
        let {
          from_adrs,
          to_adrs,
          coin_name,
          amount,
          usd_amount,
          tx_id,
          blockchain_status,
          type,
          created_at,
        }: any = obj;

        usd_amount = usd_amount.toFixed(4);
        amount = amount.toFixed(4);

        blockchain_status=MakeFirstLettarCapital(blockchain_status);
        if(type=="DApp"||type=="dapp"){
          type="DApp"
        }
        else
        {
          type=type=='withdraw'?"Withdrawal":MakeFirstLettarCapital(type);
        }
      
        let dateFormated = formatDateWithAmPm(created_at);

        // console.log("usd_amount::",usd_amount);
        await data.push({
          from_adrs,
          to_adrs,
          coin_name,
          amount,
          usd_amount,
          tx_id,
          blockchain_status,
          type,
          dateFormated,
        });
      });

      const opts = {
        fields: [
          { label: `${language[lang].FROM_ADRS}`, value: "from_adrs" },
          { label: `${language[lang].TO_ADRS}`, value: "to_adrs" },
          { label: `${language[lang].ASSET_NAME}`, value: "coin_name" },
          { label: `${language[lang].CRYPTO_AMOUNT}`, value: "amount" },
          { label: `${language[lang].USD_AMOUNT}`, value: "usd_amount" },
          { label: `${language[lang].HASH}`, value: "tx_id" },
          {
            label: `${language[lang].BLOCKCHAIN_STATUS}`,
            value: "blockchain_status",
          },
          { label: `${language[lang].TYPE}`, value: "type" },
          { label: `${language[lang].DATE}`, value: "dateFormated" },
        ],
      };

      const parser = new Parser(opts);
      const csvData = parser.parse(data);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=transaction_history.csv"
      );
      res.status(GlblCode.SUCCESS).end(csvData);
    } catch (err: any) {
      console.error("Error in wallet > transactions.", err);
      await commonHelper.save_error_logs("wallet_transactions", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
}

export const transactionController = new TransactionController();
