import express from "express";
import { validate as validateExpress } from "express-validation";
import { ControllerInterface } from "../../interfaces/controller.interface";
import { transactionController } from "./controller";
import transaction_validator from "./validator";
import jwtVerification from "../../middlewares/verify.middleware";
import adminMiddleware from "../middleware";

class TransactionRoute implements ControllerInterface {
  public path = "/admin/transaction";
  public router = express.Router();

  constructor() {
    
   // this.router.use(adminMiddleware.checkLogin);

    this.initializeRoutes();
  }
  public initializeRoutes() {
    this.router.post(
      `${this.path}/list`,
      [validateExpress(transaction_validator.transactionList_validate)],
      adminMiddleware.checkLogin,
      jwtVerification.verifyToken,
      transactionController.transactions
    );
    this.router.post(
      `${this.path}/swap_transaction`,
      [validateExpress(transaction_validator.swap_transaction)],
      adminMiddleware.checkLogin,
      jwtVerification.verifyToken,
      transactionController.swap_transaction
    );
    this.router.post(
      `${this.path}/swap_coins`,
      [validateExpress(transaction_validator.swap_coins)],
      adminMiddleware.checkLogin,
      jwtVerification.verifyToken,
      transactionController.swap_coins
    );
    this.router.get(
      `${this.path}/download`,
      transactionController.downloadCsv
    );
  }
}
export default TransactionRoute;
