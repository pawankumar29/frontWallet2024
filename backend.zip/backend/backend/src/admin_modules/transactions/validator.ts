import { Joi } from "express-validation";

export default class transaction_validator {
  static transactionList_validate = {
    body: Joi.object({
      addrsListKeys: Joi.array().required().optional(),
      fiat_currency: Joi.string().allow(null, "").optional(),
      searchBy: Joi.string().allow(null, "").optional(),
      limit: Joi.number().optional(),
      page: Joi.number().optional(),
      coin_id: Joi.number().optional(),
      status: Joi.string().allow(null, "").optional(),
      date_from: Joi.string().allow(null, "").optional(),
      date_to: Joi.string().allow(null, "").optional(),
      trnx_type: Joi.string().allow(null, "").optional(),
      coin_family: Joi.array().required().optional(),
      coin_type: Joi.string().allow(null, "").optional(),
      from_date: Joi.string().allow(null, "").optional(),
      to_date: Joi.string().allow(null, "").optional(),
      filterType: Joi.string().optional(),
      orderBy: Joi.string().allow(null, "").optional(),
      entity_type:Joi.string().allow(null, "").optional(),
      entity_type_order:Joi.string().allow(null, "").optional()

    }),
  };

    static swap_transaction = {
        body: Joi.object({
          fiat_currency: Joi.string().allow(null, "").optional(),
          coin_ids: Joi.array().required(),
        }),
      };
      static swap_coins = {
        body: Joi.object({
          coin_symbols: Joi.array().required(),
          token_symbols:Joi.array().required()

        }),
      };


}
