import moment from "moment";
import response from "../../helpers/response/response.helpers";
import commonHelper from "../../helpers/common/common.helpers";
import settings_queries from "../../helpers/dbHelper/settings";
import axios from "axios";
import { config } from "../../config";
import * as models from "../../models/index";
import { admin_queries } from "../../helpers/dbHelper";
import speakeasy from "speakeasy";
import { Messages } from "../auth/enum";
import { GlblCode, GlblMessages, Status } from "../../constants/global_enum";
import bcrypt from "bcryptjs";
import { Op } from "sequelize";

export function formatDate(dateString: any) {
  // Parse the date string using moment
  const date = moment(dateString);

  // Format the date to the desired format (21/03/2024 11:59)
  const formattedDate = date.format("DD/MM/YYYY HH:mm");

  return formattedDate;
}

export function getChain(coinFamily: any) {
  coinFamily = Number(coinFamily);
  switch (coinFamily) {
    case 1:
      return "bnb";
    case 2:
      return "eth";

    case 3:
      return "btc";

    case 6:
      return "tron";
  }
}

export function MakeFirstLettarCapital(text: string) {
  let firstChar = text[0];
  firstChar = firstChar?.toUpperCase();
  let sliceString = text?.slice(1);
  return firstChar + sliceString;
}

export function getAddress(
  from_adrs: string,
  to_adrs: any,
  walletAddressList: any[]
) {
  const d = walletAddressList.find((data: string) => from_adrs == data);
  if (d) return d;
  return to_adrs;
}

export async function cmc_news(coin_symbol: any) {
  try {

    let url: any = `${config.CMC.CMC_NEWS_API}?symbol=${coin_symbol}`;
    let result = await axios({
      method: "get",
      url: url,
      headers: { "X-CMC_PRO_API_KEY": `${config.CMC.CMC_KEY}` },
    });
    console.log("result::", result.data);
    if (result?.data) {
      return result.data;
    }
    return [];
  } catch (err: any) {
    console.error("Error in news_latest_function>>", err);
    throw err;
  }
}

export async function cmc_news_with_last_score(
  coin_symbol: any,
  last_score: any
) {
  try {
    let url: any = `${config.CMC.CMC_NEWS_API}?symbol=${coin_symbol}&last_score=${last_score}`;
    let result = await axios({
      method: "get",
      url: url,
      headers: { "X-CMC_PRO_API_KEY": `${config.CMC.CMC_KEY}` },
    });
    return result.data;
  } catch (err: any) {
    console.error("Error in news_latest_function>>", err);
    throw err;
  }
}

export function formatDateWithAmPm(dbDateStr: any) {
  try {
    const dateObj = moment(dbDateStr);

    // Extract hours considering AM/PM
    const hours = dateObj.format("h");

    const minutes = dateObj.minutes().toString().padStart(2, "0");
    const ampm = dateObj.format("A");

    const formattedDate = dateObj.format("DD/MM/YYYY");
    const formattedDateTime = `${formattedDate} ${hours}:${minutes} ${ampm}`;
    return formattedDateTime;
  } catch (err: any) {
    console.error("Error in formatDateWithAmPm>>", err);
    throw err;
  }
}
export async function news_latest() {
  try {
    const cmc_ids = [1839, 1027, 825, 1];

    let i;

    for (i = 0; i < cmc_ids.length; i++) {
      const result = await cmc_news_latest(cmc_ids[i]);

      // console.log("result::", result);
      if (result?.data) {
        for await (let data of result?.data) {
          // const data={
          //   nickname:result?.data?.list[0]?.owner?.nickname,
          //   post_id:result?.data?.list[0]?.post_id,
          //   text_content:result?.data?.list[0]?.text_content,
          //   post_time:result?.data?.list[0]?.post_time,
          //   symbol:coin_symbols[i]
          // }

          //console.log("data::",data);

          let dataValues1 = {
            nickname: data?.meta?.sourceName,
            post_id: data?.meta?.id,
            text_content: data?.meta?.subtitle,
            post_time: data?.meta?.releasedAt,
            cmc_id: cmc_ids[i].toString(),
            comment_url: data?.meta?.sourceUrl,
          };

          // console.log("data::", dataValues1);

          const check_post_exist = await models.CmcPostModel.findOne({
            where: {
              post_id: data?.meta?.id?.toString(),
              cmc_id: cmc_ids[i].toString(),
            },
          });

          // console.log("check_post_exist", check_post_exist?.dataValues?.id);
          // console.log("check_post_exist11", !check_post_exist?.dataValues?.id);

          let dataValues: any;
          if (!check_post_exist?.dataValues?.id) {
            dataValues = {
              nickname: data?.meta?.sourceName,
              post_id: data?.meta?.id,
              text_content: data?.meta?.subtitle,
              post_time: data?.meta?.releasedAt,
              cmc_id: cmc_ids[i].toString(),
              comment_url: data?.meta?.sourceUrl,
            };
            await models.CmcPostModel.create(dataValues);

            console.log("addedHere::");
          }

          //console.log("dataValues::",dataValues);
        }
      }
    }
  } catch (error) {
    console.log("errorInCMCNews>>>", error);
  }
}
export async function cmc_news_latest(cmc_id: any) {
  try {
    console.log("cmc_news_latest>>data", cmc_id);
    let result: any;
    const data: any = {
      mode: "LATEST",
      page: 1,
      size: 3,
      language: "en",
      coins: [cmc_id],
      newsTypes: ["NEWS", "ALEXANDRIA"],
    };

    console.log("number 1>>> old cmc ");
    let url: any = `${config.CMC.CMC_NEWS_API}`;
    console.log("url::", url);

    result = await axios({
      method: "post",
      url: url,
      data,
      headers: { "X-CMC_PRO_API_KEY": `${config.CMC.CMC_KEY}` },
    });
    console.log("result::", result?.data[0]?.meta);
    if (result?.data) {
      return result?.data;
    }
    return [];
  } catch (err: any) {
    console.error("Error in news_latest_function>>", err);
    throw err;
  }
}

export function getNextDate(date: any) {
  return new Date(date.setDate(date.getDate() + 1));
}

export async function google_2fa_verify_dashboard(
  token: any,
  admin_id: any,
  password: any
) {
  try {
    let data: any;

    let adminData: any = await admin_queries.find_one_admin(
      ["id", "username", "email", "google2fa_status", "google2fa_secret"],
      { id: admin_id, active: 1 }
    );

    let checkPassword: any = await bcrypt.compare(password, adminData.password);
    if (checkPassword == false) {
      data = {
        message: Messages.INCORRECT_PASS,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };

      return data;
    }
    let secretBase32: any = adminData.google2fa_secret;
    var verified: any = speakeasy.totp.verify({
      secret: secretBase32,
      encoding: "base32",
      token: token,
      window: 2,
      algorithm: "sha1",
    });
    if (typeof verified === "undefined") {
      data = {
        message: Messages.INVALID_2FA,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
    } else if (verified === null) {
      data = {
        message: Messages.INVALID_2FA,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
    } else if (verified == false) {
      data = {
        message: Messages.INVALID_2FA,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
    } else if (verified == true) {
      data = {
        message: GlblMessages.SUCCESS,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        details: `Token verified successfully.`,
      };
    } else {
      data = {
        message: Messages.INVALID_2FA,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
    }
    return data;
  } catch (err: any) {
    console.error("Error in google_2fa_verify API", err);
    let data: any = {
      message: err?.message || GlblMessages.CATCH_MSG,
      status: Status.FALSE,
      code: GlblCode.ERROR_CODE,
      data: {},
    };
    return data;
  }
}

export function fcm_handle_more_users(total_user: any) {
  try {
    let counter = parseInt(total_user) / 500;
    return Math.ceil(counter);
  } catch (err: any) {
    console.log("error In fcm_handle_more_users::", err);
  }
}

export async function getLatestFiveRecords() {
  try {
    let i;

    const cmc_ids = [1839, 1027, 825, 1];

    for (i = 0; i < cmc_ids.length; i++) {
      const latestArticles: any = await models.CmcPostModel.findAll({
        where: { cmc_id: cmc_ids[i].toString() },
        group: ["post_id"],
        order: [["updated_at", "DESC"]],
        limit: 5,
      });

      const latestIds = latestArticles.map((article: any) => article?.post_id);

      console.log("latestIds", latestIds);

      const getPostData = await models.CmcPostModel.findAll({
        where: {
          cmc_id: cmc_ids[i].toString(),
          post_id: {
            [Op.notIn]: latestIds,
          },
        },
        logging: true,
      });

      console.log("getPostData::", getPostData);

      const t = await models.CmcPostModel.destroy({
        where: {
          cmc_id: cmc_ids[i].toString(),
          post_id: {
            [Op.notIn]: latestIds,
          },
        },
        logging: true,
      });

      console.log(
        `Deleted old cmc news  successfully cmc_id ${cmc_ids[i]} ${t}`
      );
    }
  } catch (error) {
    console.error(`error in deleting cmc old news ${error}`);
  }
}

export function checkNativeSymbol(coinName: String) {
  try {
    coinName = coinName?.toLowerCase();
    switch (coinName) {
      case "ethereum":
        return "eth";
      case "binance":
        return "bnb";
    }

    return null;
  } catch (error) {
    console.error(`error in checkNativeSymbol  ${error}`);
  }
}
