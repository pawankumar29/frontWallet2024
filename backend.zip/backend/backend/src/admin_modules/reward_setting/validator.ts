import { Joi } from "express-validation";

export default class reward_validator {
  static referralListValidate = {
    body: Joi.object({
      search: Joi.string().allow(null, "").optional(),
      page: Joi.string().allow(null, "").optional(),
      limit: Joi.string().allow(null, "").optional(),    }),
  };

  static updateReward = {
    body: Joi.object({
      type_1: Joi.string().optional(),
      type_number_1: Joi.number().optional(),
      reward_amount_1:Joi.number().optional(),
      type_2: Joi.string().optional(),
      type_number_2: Joi.number().optional(),
      reward_amount_2:Joi.number().optional()
    }),
  };
}
