import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";
const crypto = require("crypto");
import {
  Fiat_Currency,
  GlblBlockchainTxStatusEnum,
  GlblBooleanEnum,
  GlblCode,
  GlblMessages,
  TxTypesEnum,
} from "./../../constants/global_enum";
import { Status, language } from "./../../constants";

import { Op, QueryTypes, Sequelize } from "sequelize";
import response from "../../helpers/response/response.helpers";
import commonHelper from "../../helpers/common/common.helpers";
import db from "../../helpers/common/db";
import { Parser } from "json2csv";
const IP = require("ip");

class RewardController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() {}

  public async referralList(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "25") : req.body.limit
      );

      let orderBy = req.body.orderBy === "ascending" ? "ASC" : "DESC";

      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;

      let query: any = {
        include: [
          {
            model: Models.UsersModel,
            required: false,
          },
        ],

        where: {
          [Op.or]: [
            {
              "$user.user_name$": {
                [Op.like]: search,
              },
            },
            {
              address: {
                [Op.like]: search,
              },
            },
          ],
        },
        order:[["updated_at",orderBy]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      let user_data: any = await Models.RewardHistoryModel.findAndCountAll(
        query
      );

      //console.log("userdata===>",user_data);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: user_data.rows,
          meta: {
            page: page,
            pages: Math.ceil(user_data.count / limit),
            perPage: limit,
            total: user_data.count,
          },
        },
      });
    } catch (err: any) {
      console.log("error", err);
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }

  public async exportCsv(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let search: any =
        req.query.search == undefined
          ? (req.query.search = "%%")
          : (req.query.search = "%" + req.query.search + "%");
      let limit: number = Number(
        req.query.limit == undefined ? (req.query.limit = "25") : req.query.limit
      );

      let orderBy = req.query.orderBy === "ascending" ? "ASC" : "DESC";

      let page: number = Number(
        req.query.page == undefined ? (req.query.page = "1") : req.query.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;

      let query: any = {
        include: [
          {
            model: Models.UsersModel,
            required: false,
          },
        ],

        where: {
          [Op.or]: [
            {
              "$user.user_name$": {
                [Op.like]: search,
              },
            },
            {
              address: {
                [Op.like]: search,
              },
            },
          ],
        },
        order:[["updated_at",orderBy]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      let user_data: any = await Models.RewardHistoryModel.findAndCountAll(
        query
      );

      let data: any = [];
      user_data.rows.map((obj: any) => {
        console.log("obj::", obj);


        const {
          dataValues: { address, wallet_name, total_user_balance, date },
        }: any = obj;

        data.push({
          date,
          address,
          wallet_name,
          total_user_balance,
        });
      });

      const opts = {
        fields: [
          { label: `${language[lang].DATE}`, value: "date" },

          {
            label: `${language[lang].WALLET_ADDRESS}`,
            value: "address",
          },
          { label: `${language[lang].WALLET_NAME}`, value: "wallet_name" },
          // { label: `${language[lang].COIN_NAME}`, value: "coin_name" },
          // { label: `${language[lang].COIN_IMAGE}`, value: "coin_image" },

          { label: `${language[lang].BALANCE}`, value: "total_user_balance" },
          // { label: `${language[lang].USD_AMOUNT}`, value: "value" },
          // { label: `${language[lang].DATE}`, value: "created_at" },
        ],
      };

      const parser = new Parser(opts);
      const csvData = parser.parse(data);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=transaction_history.csv"
      );
      res.status(GlblCode.SUCCESS).end(csvData);



    
    } catch (err: any) {
      console.log("error", err);
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }

  public async allRewards(req: Request, res: Response) {
    let lang: string = req.headers["content-language"] || "en";
    try {
      let query: any = {
        attributes: ["id", "type", "type_number", "reward_amount"],
        where: {},
      };

      const allRecords = await Models.AdminSettingModel.findAll(query);

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: allRecords,
        },
      });
    } catch (err: any) {
      console.error("error", err);
      response.error(res, {
        data: { status: false, message: err.message || "An error occurred" },
      });
    }
  }

  public async updateReward(req: Request, res: Response) {
    let lang: string = req.headers["content-language"] || "en";
    try {
      const {
        type_1,
        type_number_1,
        reward_amount_1,
        type_2,
        type_number_2,
        reward_amount_2,
      } = req.body;



      const type_1_updates: { [key: string]: any } = {};
      const type_2_updates: { [key: string]: any } = {};

      if (type_1 !== "" && type_1) {
        if (type_number_1 !== "" && type_number_1) {
          type_1_updates.type_number = type_number_1;
        }

        if (reward_amount_1 && reward_amount_1 != "") {
          type_1_updates.reward_amount = reward_amount_1;
        }

        const result = await Models.AdminSettingModel.update(type_1_updates, {
          where: {
            type: type_1,
          },
        });

        //console.log("r1::",result);
      }

      if (type_2 !== "" && type_2) {
        if (type_number_2 !== "" && type_number_2) {
          type_2_updates.type_number = type_number_2;
        }

        if (reward_amount_2 && reward_amount_2 !== "") {
          type_2_updates.reward_amount = reward_amount_2;
        }

        const result = await Models.AdminSettingModel.update(type_2_updates, {
          where: {
            type: type_2,
          },
        });
        //console.log("r2::",result);

      }


      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("error", err);
      response.error(res, {
        data: { status: false, message: err.message || "An error occurred" },
      });
    }
  }
}

export const RewardsController = new RewardController();
