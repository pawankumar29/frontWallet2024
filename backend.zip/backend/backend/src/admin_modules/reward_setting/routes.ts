import express from "express";
import { validate as validateExpress } from "express-validation";
import { ControllerInterface } from "../../interfaces/controller.interface";
import { RewardsController } from "./controller";

import reward_validator from "./validator";
import jwtVerification from "../../middlewares/verify.middleware";

class RewardRoute implements ControllerInterface {
    public path = "/admin/reward";
    public router = express.Router();

    constructor() {
        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router.post(
            `${this.path}/referralList`,
            [validateExpress(reward_validator.referralListValidate)],
            jwtVerification.verifyToken,
            RewardsController.referralList
        ).post(
            `${this.path}/updateReward`,
            [validateExpress(reward_validator.updateReward)],
            jwtVerification.verifyToken,
            RewardsController.updateReward
        ).get(
            `${this.path}/getAllRewards`,
           // [validateExpress(reward_validator.updateReward)],
            jwtVerification.verifyToken,
            RewardsController.allRewards
        )
    }
    
}
export default RewardRoute;
