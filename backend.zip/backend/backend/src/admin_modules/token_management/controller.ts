import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";
const crypto = require("crypto");
import { GlblBooleanEnum, GlblMessages } from "./../../constants/global_enum";
import { language } from "./../../constants";

import { Op, Sequelize } from "sequelize";
import response from "../../helpers/response/response.helpers";
import { WalletHelper } from "../../modules/wallet/wallet.helpers";
import { global_helper } from "../../helpers/common/global_helper";
import { coin_queries } from "../../helpers/dbHelper";
import commonHelper from "../../helpers/common/common.helpers";
import { checkNativeSymbol } from "../helper/helper";
const IP = require("ip");

class TokenController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() {}

  public async addToken(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let currentUTCDate: string = new Date()
        .toISOString()
        .replace(/T/, " ")
        .replace(/\..+/, "");
      let {
        coin_family,
        token_type,
        token_address,
        name,
        symbol,
        coin_gicko_alias,
        decimals,

        isSwapList,
      }: {
        coin_family: number;
        token_type: string;
        token_address: string;
        name: string;
        symbol: string;
        coin_gicko_alias: string;
        decimals: string;

        isSwapList: any;
      } = req.body;
      let message: any = language[lang].TOKEN_ADDED;

      let data: any = {
        coin_family: coin_family,
        token_type: token_type,
        created_at: currentUTCDate,
        updated_at: currentUTCDate,
        token_address: token_address,
      };

      let checkIfCoinExists: any = await coin_queries.coin_find_one(
        [
          "coin_id",
          "token_type",
          "for_swap",
          "cmc_id",
          "coin_status",
          "added_by",
        ],
        { coin_family: coin_family, token_address: token_address }
      );
      // Check coin exist
      let swap_supported: number = await global_helper.swap_supported(
        token_address,
        coin_family
      );
      if (!checkIfCoinExists) {
        let response: any = await WalletHelper.add_coin_to_table(
          swap_supported,
          data,
          symbol,
          name,
          coin_gicko_alias,
          decimals,
          lang,
          "admin"
        );
        data = response.data;
        message = response.message;
      } else {
        console.log("checkIfCoinExists", checkIfCoinExists);
        // console.log("checkIfCoinExists?.added_by",checkIfCoinExists?.added_by);
        message = language[lang].TOKEN_EXIST;

        if (checkIfCoinExists?.added_by === "user") {
          const update = await Models.CoinsModel.update(
            { added_by: "admin" },
            {
              where: { coin_id: checkIfCoinExists?.coin_id },
            }
          );

          console.log("update::", update);

          message = language[lang].TOKEN_UPDATED;
        }

        if (
          checkIfCoinExists.for_swap != swap_supported &&
          checkIfCoinExists.coin_status == 0
        ) {
          await coin_queries.coin_update(
            { coin_status: 1, for_swap: swap_supported },
            { coin_id: checkIfCoinExists.coin_id }
          );
          await WalletHelper.update_token_in_redis(
            { coin_family: coin_family },
            checkIfCoinExists.coin_id
          );
        } else if (checkIfCoinExists.for_swap != swap_supported) {
          await coin_queries.coin_update(
            { for_swap: swap_supported },
            { coin_id: checkIfCoinExists.coin_id }
          );
        } else if (checkIfCoinExists.coin_status == 0) {
          await coin_queries.coin_update(
            { coin_status: 1 },
            { coin_id: checkIfCoinExists.coin_id }
          );
          await WalletHelper.update_token_in_redis(
            { coin_family: coin_family },
            checkIfCoinExists.coin_id
          );
        } else {
          console.log("no need to update coin ");
        }
        data.coin_id = checkIfCoinExists.coin_id;
        data.token_type = checkIfCoinExists.token_type;
      }
      // message = await WalletHelper.insert_entry_in_custom_token_table(
      //   data.coin_id,
      //   req.userId,
      //   lang
      // );
      // await WalletHelper.create_wallet_for_coin(data);
      return response.success(res, {
        data: { message: message },
      });
    } catch (err: any) {
      console.error("Error in wallet > addToken.", err);
      await commonHelper.save_error_logs("wallet_addToken", err.message);
      //throw language[lang].CATCH_MSG;
      return response.error(res, {
        data: { message: language[lang].CATCH_MSG, data: {} },
      });
    }
  }

  public async tokenList(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let tokenType = req.query.token_type;
      // let searchBy: any =
      //   req.query.searchBy == undefined
      //     ? (req.query.searchBy = "%%")
      //     : (req.query.searchBy = req.query.searchBy + "%");

      let search: any = req?.query?.searchBy;
      search = search?.trim();
      let flag = checkNativeSymbol(search);
      let searchBy: string =
        req.query.searchBy == undefined
          ? (req.query.searchBy = "%%")
          : flag
          ? (req.query.searchBy = `%${flag}%`)
          : (req.query.searchBy = "%" + req.query.searchBy + "%");

      let whereClause: any;
      let limit: number = Number(
        req.query.limit == undefined
          ? (req.query.limit = "25")
          : req.query.limit
      );
      let page: number = Number(
        req.query.page == undefined ? (req.query.page = "1") : req.query.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let query: any;
      if (searchBy) {
        whereClause = {
          added_by: "admin",
          coin_status: 1,
          is_token: 1,

          [Op.or]: [
            {
              token_address: {
                [Op.like]: searchBy,
              },
            },
            {
              coin_symbol: {
                [Op.like]: searchBy,
              },
            },
            {
              coin_name: {
                [Op.like]: searchBy,
              },
            },
          ],
        };
      } else {
        whereClause = {
          added_by: "admin",
          coin_status: 1,
          is_token: 1,
        };
      }

      console.log("searchBy::", searchBy);

      if (tokenType) {
        switch (tokenType) {
          case "ERC20":
            whereClause = {
              ...whereClause,
              token_type: "ERC20",
            };
            break;

          case "TRC20":
            whereClause = {
              ...whereClause,
              token_type: "TRC20",
            };
            break;

          case "BEP20":
            whereClause = {
              ...whereClause,
              token_type: "BEP20",
            };
            break;
        }
      }

      query = {
        where: whereClause,
        order: [["updated_at", "DESC"]],
        limit,
        offset,
      };

      console.log("query::::", query);
      const coin_data = await Models.CoinsModel.findAndCountAll(query);

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: coin_data?.rows,
          meta: {
            page: page,
            pages: Math.ceil(coin_data?.count / limit),
            perPage: limit,
            total: coin_data.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > tokenList.", err);
      await commonHelper.save_error_logs("wallet_tokenList", err.message);
      //throw language[lang].CATCH_MSG;
      return response.error(res, {
        data: { message: language[lang].CATCH_MSG, data: {} },
      });
    }
  }

  public async searchToken(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let {
        tokenAddress,
        coinFamily,
      }: { tokenAddress: string; coinFamily: number } = req.body;
      let tokenDetails: { decimals: any; name: any; symbol: any } = {
        decimals: "0",
        name: "",
        symbol: "",
      };
      tokenDetails = await global_helper.return_decimals_name_symbol(
        coinFamily,
        tokenAddress,
        lang
      );
      tokenDetails.decimals = tokenDetails.decimals.toString();

      if (!tokenDetails || tokenDetails == null) {
        return response.error(res, {
          data: { message: language[lang].INVALID_TOKEN, data: {} },
        });
      }
      if (
        Object.keys(tokenDetails).length !== GlblBooleanEnum.false &&
        tokenDetails.constructor === Object
      ) {
        return response.success(res, {
          data: {
            message: language[lang].TOKENS_SEARCH,
            data: tokenDetails,
          },
        });
      }
      return response.error(res, {
        data: { message: language[lang].TOKENS_NOT_FOUND, data: {} },
      });
    } catch (err: any) {
      console.error("Error in wallet > searchToken.", err);
      await commonHelper.save_error_logs("wallet_searchToken", err.message);
      return response.error(res, {
        data: {
          data: { message: language[lang].CATCH_MSG, data: {} },
        },
      });
    }
  }

  public async deleteToken(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const coin_id = req.params.coin_id;

      await Models.CoinsModel.update(
        {
          added_by: "user",
        },
        { where: { coin_id: coin_id } }
      );
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > deleteToken.", err);
      await commonHelper.save_error_logs("deleteToken", err.message);
      return response.error(res, {
        data: {
          data: { message: language[lang].CATCH_MSG, data: {} },
        },
      });
    }
  }
}

export const tokenController = new TokenController();
