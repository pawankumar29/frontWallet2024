import express from "express";
import { validate as validateExpress } from "express-validation";
import { ControllerInterface } from "../../interfaces/controller.interface";
import { tokenController } from "./controller";

import token_validator from "./validator";
import jwtVerification from "../../middlewares/verify.middleware";
import adminMiddleware from "../middleware";


class TokenRoute implements ControllerInterface {
    public path = "/admin/token";
    public router = express.Router();

    constructor() {
        this.router.use(adminMiddleware.checkLogin);
        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router.post(
            `${this.path}/addtoken`,
            [validateExpress(token_validator.addToken_validate)],
            jwtVerification.verifyToken,
            tokenController.addToken
        ).get(
            `${this.path}/tokenList`,
            jwtVerification.verifyToken,
            tokenController.tokenList
        ).post(
            `${this.path}/searchToken`,
           [validateExpress(token_validator.searchToken_validate)],
            jwtVerification.verifyToken,
            tokenController.searchToken
        ).put(
            `${this.path}/deleteToken/:coin_id`,
          // [validateExpress(token_validator.searchToken_validate)],
            jwtVerification.verifyToken,
            tokenController.deleteToken
        );
    }
}
export default TokenRoute;
