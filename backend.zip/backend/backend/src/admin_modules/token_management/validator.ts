import { Joi } from "express-validation";

export default class token_validator {
  

    static addToken_validate = {
        body: Joi.object({
            name: Joi.string().required(),
            symbol: Joi.string().required(),
            //coin_gicko_alias: Joi.string().required(),
            decimals: Joi.string().required(),
            token_address: Joi.string().required(),
            coin_family: Joi.number().required(),
           // wallet_address: Joi.string().optional(),
            //login_type: Joi.string().optional(),
            //social_id: Joi.string().optional(),
           // wallet_name: Joi.string().allow(null, '').optional(),
            //isSwapList: Joi.bool().required(),
            token_type: Joi.string().required()
        })
    }

    static searchToken_validate = {
        body: Joi.object({
            tokenAddress: Joi.string().required(),
            coinFamily: Joi.number().required(),
        })
    }
}
