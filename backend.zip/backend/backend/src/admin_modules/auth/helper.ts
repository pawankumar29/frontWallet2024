import { config } from "../../config";
import AWS from "aws-sdk";
import { GlblBooleanEnum } from "../../constants/global_enum";
import { global_helper } from "../../helpers/common/global_helper";
import * as Models from "../../models/model/index";
import { fcm_handle_more_users } from "../helper/helper";
var FCM = require("fcm-node");

// AWS.config.update({
//     accessKeyId: config.S3_ACCESSID,
//     secretAccessKey: config.S3_SECRETKEY,
//     region: config.REGION
// })
const s3 = new AWS.S3();
class AdminHelper {

  public async multerInstance(file: any, fileName: string) {
    // const uploadParams: any = {
    //     Bucket: config.S3_BUCKET,
    //     Key: `${config.S3_FOLDER}/${Date.now()}_${fileName}`,
    //     Body: file.data,
    //     ContentType: file.mimetype,
    //     ACL: "public-read",
    // };
    // const data: any = await s3.upload(uploadParams).promise();
    // return data.Location;
  }

  public async capitalize_letters(currency_name: string) {
    try {
      let words = currency_name.split(" ");
      let capitalizedWords = words.map(
        (word) =>
          word.charAt(GlblBooleanEnum.false).toUpperCase() +
          word.slice(GlblBooleanEnum.true)
      );
      currency_name = capitalizedWords.join(" ");
      return currency_name;
    } catch (err: any) {
      console.error("Error in capitalize_letters > adminHelper.", err);
      return null;
    }
  }
  public async creating_new_password() {
    try {
      const length: number = 10;
      const chars: string =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      let newPassword: string = "";
      for (let i: number = GlblBooleanEnum.false; i < length; i++) {
        newPassword += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return newPassword;
    } catch (err: any) {
      console.error("Error in creating_new_password > admin_module.", err);
      return null;
    }
  }

  public async announcement_part(
    allValues: any,
    user_ids: any,
    title: any,
    details: any
  ) {
    try {
      for (let i = GlblBooleanEnum.false; i < allValues.length; i++) {
        let view_data: any = await Models.AnnouncementStatusModel.findOne({
          attributes: ["user_id"],
          where: {
            user_id: allValues[i],
          },
          raw: true,
        });
        if (view_data) {
          await Models.AnnouncementStatusModel.update(
            {
              view_status: GlblBooleanEnum.false,
            },
            {
              where: {
                user_id: allValues[i],
              },
            }
          );
        } else {
          await Models.AnnouncementStatusModel.create({
            view_status: GlblBooleanEnum.false,
            user_id: allValues[i],
          });
        }
      }

      let user_id_array: any = user_ids.split(",");

      // code changes
      let cnt: any = fcm_handle_more_users(user_id_array?.length);

      console.log("count::", cnt);

      if (user_id_array?.length > 500) {
        for (let i = 0; i < cnt; i++) {
          let deviceTokens: any = await Models.DeviceTokenModel.findAll({
            attributes: ["device_token", "user_id"],
            where: {
              push: GlblBooleanEnum.true,
              user_id: user_id_array,
            },
            order: [
              ["updated_at", "DESC"],
              ["id", "DESC"],
            ],
            group: ["device_token"],
            limit: 500,
            offset: 500 * i,
            raw: true,
          });
          let device_tokens = [];

          for await (let deviceToken of deviceTokens) {
            device_tokens.push(deviceToken.device_token);
          }
          if (device_tokens.length) {
            if (Array.isArray(device_tokens)) {
              //
              let data: any = {
                deviceTokens: device_tokens,
                notification: {
                  body: details,
                  title: title,
                },
              };
              await global_helper.sendNewNotification(data);
            }
          }

          // cnt--;
        }
      } else {
        //code changes
        let deviceTokens: any = await Models.DeviceTokenModel.findAll({
          attributes: ["device_token", "user_id"],
          where: {
            push: GlblBooleanEnum.true,
            user_id: user_id_array,
          },
          order: [
            ["updated_at", "DESC"],
            ["id", "DESC"],
          ],
          group: ["device_token"],
          raw: true,
        });
        let device_tokens = [];

        for await (let deviceToken of deviceTokens) {
          device_tokens.push(deviceToken.device_token);
        }
        if (device_tokens.length) {
          if (Array.isArray(device_tokens)) {
            let data: any = {
              deviceTokens: device_tokens,
              notification: {
                body: details,
                title: title,
              },
            };
            await global_helper.sendNewNotification(data);
          }
        }
      }

      return true;
    } catch (err: any) {
      console.error("Error in making announcements > admin_module.", err);
      return null;
    }
  }
}

export const adminHelper = new AdminHelper();
