import express from "express";
import { validate as validateExpress } from "express-validation";
import { ControllerInterface } from "../../interfaces/controller.interface";
import { adminController } from "./controller";
import adminMiddleware from "../middleware";
import admin_validator from "./validator";
import jwtVerification from "../../middlewares/verify.middleware";

class AdminRoute implements ControllerInterface {
  public path = "/admin/auth";
  public router = express.Router();

  constructor() {
    this.initializeRoutes();
  }

  public initializeRoutes() {
    // Login
    this.router.post(
      `${this.path}/encrypt_passowrd`,
      adminController.encrypt_passowrd
    );
    this.router.post(
      `${this.path}/creating/privatKey`,
      adminController.creating_private_key
    );
    this.router.post(`${this.path}/encrypt_data`, adminController.encrypt_data);
    this.router.post(
      `${this.path}/login`,
      [validateExpress(admin_validator.login)],
      adminController.login
    );
    this.router.get(
      `${this.path}/logout`,
      [validateExpress(admin_validator.logout)],
      adminMiddleware.checkLogin,
      adminController.logout
    );
    this.router.post(
      `${this.path}/change_password`,
      [validateExpress(admin_validator.change_password)],
      adminMiddleware.checkLogin,
      adminController.change_password
    );
    this.router.post(
      `${this.path}/forgot_password`,
      [validateExpress(admin_validator.forgot_password)],
      adminController.forgot_password
    );
    this.router.get(
      `${this.path}/google_auth_status`,
      adminMiddleware.checkLogin,
      adminController.google_auth_status
    );
    this.router.get(
      `${this.path}/google_auth_secretkey`,
      adminMiddleware.checkLogin,
      adminController.google_auth_secretkey
    );
    this.router.post(
      `${this.path}/google_auth_enabledisable`,
      [validateExpress(admin_validator.google_auth_enabledisable)],
      adminMiddleware.checkLogin,
      adminController.google_auth_enabledisable
    );
    this.router.post(
      `${this.path}/google_2fa_verify`,
      [validateExpress(admin_validator.google_2fa_verify)],
      adminMiddleware.checkLogin,
      adminController.google_2fa_verify
    );


    // this.router.post(
    //   `${this.path}/transaction/list`,
    //   [validateExpress(admin_validator.transactionList_validate)],
    //   jwtVerification.verifyToken,
    //   adminController.transactions
    // );

    this.router.get(
      `${this.path}/users/count`,
      adminMiddleware.checkLogin,

      jwtVerification.verifyToken,
      adminController.userCount
    );

    this.router.post(
      `${this.path}/users/list`,
      adminMiddleware.checkLogin,
      [validateExpress(admin_validator.userList_validate)],
      jwtVerification.verifyToken,
      adminController.users_wallets
    );

    this.router.post(
      `${this.path}/announcements`,
      adminMiddleware.checkLogin,
      [validateExpress(admin_validator.announcement_validate)],
      jwtVerification.verifyToken,
      adminController.sendAllNotifications
    );


    this.router.post(
      `${this.path}/announcement_history`,
      adminMiddleware.checkLogin,
      jwtVerification.verifyToken,
      adminController.announcement_history
    );

    this.router.get(
      `${this.path}/announcement_history/download`,
      adminController.downloadCsv
    );
    this.router.put(
      `${this.path}/maintenance_mode`,
      adminMiddleware.checkLogin,
      jwtVerification.verifyToken,
      adminController.maintenance_mode
    );
    this.router.get(
      `${this.path}/maintenance_mode_status`,
      adminMiddleware.checkLogin,
      jwtVerification.verifyToken,
      adminController.maintenance_mode_status
    );
  }
}
export default AdminRoute;
