import { Joi } from "express-validation";

export default class admin_validator {
  static login = {
    body: Joi.object({
      email: Joi.string().required(),
      password: Joi.string().required(),
    }),
  };
  static logout = {
    body: Joi.object({}),
  };
  static change_password = {
    body: Joi.object({
      old_password: Joi.string().required(),
      new_password: Joi.string().required(),
    }),
  };
  static forgot_password = {
    body: Joi.object({
      email: Joi.string().required(),
      name: Joi.string().required(),
    }),
  };
  static google_auth_enabledisable = {
    body: Joi.object({
      password: Joi.string().required(),
      action: Joi.number().required(),
      token: Joi.string().required(),
    }),
  };
  static google_2fa_verify = {
    body: Joi.object({
      token: Joi.string().required(),
    }),
  };

  static transactionList_validate = {
    body: Joi.object({
      addrsListKeys: Joi.array().required().optional(),
      fiat_currency: Joi.string().allow(null, "").optional(),
      search: Joi.string().optional(),
      limit: Joi.number().optional(),
      page: Joi.number().optional(),
      coin_id: Joi.number().optional(),
      status: Joi.string().allow(null, "").optional(),
      date_from: Joi.string().allow(null, "").optional(),
      date_to: Joi.string().allow(null, "").optional(),
      trnx_type: Joi.string().allow(null, "").optional(),
      coin_family: Joi.array().required().optional(),
      coin_type: Joi.string().allow(null, "").optional(),
      from_date: Joi.string().allow(null, "").optional(),
      to_date: Joi.string().allow(null, "").optional(),
    }),
  };

  static userList_validate = {
    body: Joi.object({
      limit: Joi.number().optional(),
      page: Joi.number().optional(),
      search: Joi.string().allow(null, "").optional(),
      from_date: Joi.string().allow(null, "").optional(),
      to_date: Joi.string().allow(null, "").optional(),
      filter: Joi.string().allow(null, "").optional(),
    }),
  };

  static announcement_validate = {
    body: Joi.object({
      title: Joi.string().optional(),
      details: Joi.string().required(),
      user_ids: Joi.array().optional(),
    }),
  };
}
