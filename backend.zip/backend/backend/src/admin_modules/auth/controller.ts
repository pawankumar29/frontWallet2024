import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";
import { config } from "../../config";
const crypto = require("crypto");
import { adminHelper } from "./helper";
import bcrypt from "bcryptjs";
import QRCode from "qrcode";
import jwtHelper from "../../helpers/common/jwt";
import speakeasy from "speakeasy";
import { Messages, Status } from "./enum";
import {
  Fiat_Currency,
  GlblBlockchainTxStatusEnum,
  GlblBooleanEnum,
  GlblCode,
  GlblMessages,
  TxTypesEnum,
} from "./../../constants/global_enum";
import { ActivityHeads, language } from "./../../constants";
import redisClient from "../../helpers/common/redis";
import commonHelper from "../../helpers/common/common.helpers";
import adminMiddleware from "../middleware";
import dbHelper, { admin_queries } from "../../helpers/dbHelper";
import { Op, Sequelize } from "sequelize";
import response from "../../helpers/response/response.helpers";
import {
  fcm_handle_more_users,
  formatDateWithAmPm,
  getNextDate,
  google_2fa_verify_dashboard,
} from "../helper/helper";
import { Parser } from "json2csv";
var FCM = require("fcm-node");

const IP = require("ip");

class AdminController implements OnlyControllerInterface {
  public base32: string;
  constructor() {
    this.initialize();
  }

  public async initialize() {
    console.log("initialize function call");
    return config.GOOGLE_CAPTCHA_SECRET_KEY;
    // if (!this.base32) {
    //   let secret = speakeasy.generateSecret({ length: 20 });
    //   this.base32 = secret.base32;
    // }
    // console.log("this.base32 :", this.base32);
    // return this.base32;
  }
  /* LOGIN */
  public async encrypt_passowrd(req: Request, res: Response) {
    try {
      const { password }: { password: string } = req.body;
      let data: any;
      const newPassword: string = await bcrypt.hash(password, 10);
      data = {
        message: GlblMessages.SUCCESS,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        data: newPassword,
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in change_password API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async creating_private_key(req: Request, res: Response) {
    try {
      const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
        modulusLength: 1024, // Key size in bits
        publicKeyEncoding: {
          type: "pkcs1", // Public key format
          format: "pem", // Encoding format
        },
        privateKeyEncoding: {
          type: "pkcs1", // Private key format
          format: "pem", // Encoding format
        },
      });
      let data: any = {
        message: GlblMessages.SUCCESS,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        data: privateKey,
        data1: publicKey,
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in change_password API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async encrypt_data(req: Request, res: Response) {
    try {
      let datastring: any = await commonHelper.adminEncryptDataRSA(
        req.body.data
      );
      let data: any = {
        message: GlblMessages.SUCCESS,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        data: datastring,
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in encrypt data", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async login(req: Request, res: Response) {
    try {
      let { email, password }: { email: string; password: string } = req.body;

      let admin_data: any = await admin_queries.find_one_admin(
        [
          "id",
          "username",
          "email",
          "password",
          "mobile_no",
          "google2fa_secret",
          "google2fa_status",
          "login_status",
          "jwt_token",
          "role",
        ],
        { email: email, active: 1 }
      );
      let data: any;
      if (!admin_data) {
        data = {
          message: Messages.NO_EMAIL_EXIST,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }
      let checkPassword: any = await bcrypt.compare(
        password,
        admin_data.password
      );

      if (checkPassword == false) {
        data = {
          message: Messages.INCORRECT_PASS,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }

      let jwtToken: any = await jwtHelper.create_json_web_token(admin_data.id);
      const r = await admin_queries.update_admin_table(
        { login_status: GlblBooleanEnum.true, jwt_token: jwtToken },
        { id: admin_data.id }
      );

      //setting token for validation
      admin_data.jwt_token = jwtToken;
      console.log("in admin:::", r);
      //later change
      await dbHelper.create_admin_activity_logs({
        email: admin_data.email,
        ip: IP.address(),
        action_type: ActivityHeads.LOGIN,
        role_id: admin_data.role,
        created_at: new Date(),
        updated_at: new Date(),
      });

      delete admin_data.password;
      data = {
        message: GlblMessages.SUCCESS_LOGIN,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        data: admin_data,
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in admin login API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async logout(req: Request, res: Response) {
    try {
      await Models.AdminModel.update(
        { login_status: GlblBooleanEnum.false },
        { where: { id: req.adminId } }
      );
      await Models.AdminModel.update(
        { jwt_token: "" },
        { where: { id: req.adminId } }
      );
      console.log("user_email>>>", req.body.user_email);
      // await redisClient.delKey(config.ADMIN_TOKEN, req.body.user_email);
      if (req.adminDetails.admin_user_access_data != null) {
        await dbHelper.create_admin_activity_logs({
          email: req.adminDetails.email,
          ip: IP.address(),
          action_type: ActivityHeads.LOGOUT,
          role_id: req.adminDetails.role,
          created_at: new Date(),
          updated_at: new Date(),
        });
      }
      let data: any = {
        message: GlblMessages.SUCCESS,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        data: Messages.LOGOUT,
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in admin logout API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async change_password(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const {
        old_password,
        new_password,
      }: { old_password: string; new_password: string } = req.body;
      let data: any;
      const adminId: number = req.adminId;
      const newPassword: string = await bcrypt.hash(new_password, 10);
      let adminPassword: any = await admin_queries.find_one_admin(
        ["password"],
        { id: adminId, active: 1 }
      );

      if (
        new_password.toString().length < 8 ||
        new_password.toString().length > 20
      ) {
        throw new Error(
          "Kindly provide password greater than or equal to 8 and less than or equal to 20"
        );
      }

      if (new_password === old_password) {
        throw new Error("Kindly enter different password");
      }

      let checkPassword: any = await bcrypt.compare(
        old_password,
        adminPassword.password
      );

      if (checkPassword == false) {
        data = {
          message: Messages.INVALID_OLD_PASS,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }
      await Models.AdminModel.update(
        { password: newPassword },
        { where: { id: adminId } }
      );
      if (req.adminDetails.admin_user_access_data != null) {
        await dbHelper.create_admin_activity_logs({
          email: req.adminDetails.email,
          ip: IP.address(),
          action_type: ActivityHeads.PASSWORD_CHANGED,
          role_id: req.adminDetails.admin_user_access_data.role,
          created_at: new Date(),
          updated_at: new Date(),
        });
      }
      data = {
        // message: GlblMessages.SUCCESS,
        status: Status.TRUE,
        code: GlblCode.SUCCESS,
        message: Messages.PASSWORD_CHANGED,
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in admin change_password API", err);
      let data: any = {
        message:
          lang == "en"
            ? err?.message || GlblMessages.CATCH_MSG
            : GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async forgot_password(req: Request, res: Response) {
    try {
      let data: any;
      const email: string = req.body.email;
      let check_email_exist: any =
        await dbHelper.find_one_admin_with_admin_access(
          [
            "id",
            "username",
            "email",
            "password",
            "mobile_no",
            "google2fa_secret",
            "google2fa_status",
            "jwt_token",
            "login_status",
            "jwt_token",
            "created_at",
            "updated_at",
          ],
          { email: email, active: 1, username: req?.body?.name }
        );

      if (!check_email_exist) {
        data = {
          message: Messages.NO_ACCOUNT_EXIST,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }
      let newPassword: string | null =
        await adminHelper.creating_new_password();
      if (newPassword != null) {
        // let response: any = await adminHelper.sendMail(newPassword)
        const response: any = await commonHelper.send_mail(
          email,
          `Your New Password is: ${newPassword}`,
          "Reset Password"
        );
        if (response != null) {
          newPassword = await bcrypt.hash(newPassword, 10);
          // await Models.AdminModel.update(
          //   { password: newPassword },
          //   { where: { email: email, username:req?.body?.name} }
          // );

          if (check_email_exist.admin_user_access_data != null) {
            await dbHelper.create_admin_activity_logs({
              email: email,
              ip: IP.address(),
              action_type: ActivityHeads.FORGOT_PASSWORD,
              role_id: check_email_exist.admin_user_access_data.role_id,
              created_at: new Date(),
              updated_at: new Date(),
            });
          }
          data = {
            message: GlblMessages.SUCCESS,
            status: Status.TRUE,
            code: GlblCode.SUCCESS,
            data: Messages.PASSWORD_RESET,
          };
          return res.status(data.code).send(data);
        } else {
          data = {
            message: GlblMessages.NOT_SEND_MAIL,
            status: Status.FALSE,
            code: GlblCode.ERROR_CODE,
            data: {},
          };
          return res.status(data.code).send(data);
        }
      } else {
        data = {
          message: GlblMessages.NO_NEW_PASSWORD,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }
    } catch (err: any) {
      console.error("Error in admin change_password API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async google_auth_status(req: Request, res: Response) {
    try {
      const adminId: number = req.adminId;
      let data: any;
      let getStatus: any = await admin_queries.find_one_admin(
        ["google2fa_status"],
        { id: adminId, active: 1 }
      );
      // let getStatus: any = await Models.AdminModel.findOne({ attributes: ["google2fa_status"], where: { id: adminId }, raw: true });
      if (getStatus) {
        data = {
          message: GlblMessages.SUCCESS,
          status: Status.TRUE,
          code: GlblCode.SUCCESS,
          data: getStatus.google2fa_status,
        };
      } else {
        data = {
          message: Messages.AUTH_FAILED,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      }
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in google_auth_status API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async google_auth_secretkey(req: Request, res: Response) {
    try {
      let label: string = "Future Admin";
      const adminId: number = req.adminId;
      let secret: any = speakeasy.generateSecret({ length: 20 });
      console.log("secret :", secret);
      let secretBase32 = await adminController.initialize();
      console.log("secretBase32 :", secretBase32);
      let url: any = await speakeasy.otpauthURL({
        secret: secretBase32,
        encoding: "base32",
        label: label,
        algorithm: "sha1",
      });

      const adminDetails = await Models.AdminModel.findOne({
        where: { id: adminId },
      });

      if (adminDetails?.google2fa_status == 0) {
        await Models.AdminModel.update(
          { google2fa_secret: secretBase32 },
          { where: { id: adminId } }
        );
      }

      return QRCode.toDataURL(url, function (err: any, image_data: any) {
        let data: any = {
          message: GlblMessages.SUCCESS,
          status: Status.TRUE,
          code: GlblCode.SUCCESS,
          data: { google_secret_key: secretBase32, qr_code: image_data },
        };
        return res.status(data.code).send(data);
      });
    } catch (err: any) {
      console.error("Error in google_auth_secretkey API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async google_auth_enabledisable(req: Request, res: Response) {
    try {
      let data: any;
      const adminId: number = req.adminId;
      const {
        password,
        action,
        token,
      }: { password: string; action: number; token: string } = req.body;
      let adminData: any = await admin_queries.find_one_admin(
        ["password", "google2fa_secret"],
        { id: adminId, active: 1 }
      );
      // let adminData: any = await Models.AdminModel.findOne({
      //     attributes: ["password", "google2fa_secret"],
      //     where: { id: adminId },
      //     raw: true
      // });
      let msg =
        action == GlblBooleanEnum.true
          ? "Google Auth Enabled."
          : "Google Auth Disabled.";
      let checkPassword: any = await bcrypt.compare(
        password,
        adminData.password
      );
      if (checkPassword == false) {
        data = {
          message: Messages.INCORRECT_PASS,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }
      let secretBase32: any = adminData.google2fa_secret;
      let verified: any = speakeasy.totp.verify({
        secret: secretBase32,
        encoding: "base32",
        token: token,
        // window: 2,
        // algorithm: "sha1",
      });
      if (typeof verified === "undefined") {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      } else if (verified === null) {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      } else if (verified == false) {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      } else if (verified == true) {
        await Models.AdminModel.update(
          { google2fa_status: action },
          { where: { id: adminId } }
        );
        data = {
          message: GlblMessages.SUCCESS,
          status: Status.TRUE,
          code: GlblCode.SUCCESS,
          data: msg,
        };
      } else {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      }
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in google_auth_enabledisable API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async google_2fa_verify(req: Request, res: Response) {
    try {
      const { token }: any = req.body;
      let adminData: any = await admin_queries.find_one_admin(
        ["id", "username", "email", "google2fa_status", "google2fa_secret"],
        { id: req.adminId, active: 1 }
      );

      let data: any;
      let secretBase32: any = adminData.google2fa_secret;
      var verified: any = speakeasy.totp.verify({
        secret: secretBase32,
        encoding: "base32",
        token: token,
        // window: 2,
        // algorithm: "sha1",
      });

      console.log("verifired", verified);
      if (typeof verified === "undefined") {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      } else if (verified === null) {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      } else if (verified == false) {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      } else if (verified == true) {
        // let jwt_token: string = await adminMiddleware.generate_token(
        //   adminData.id
        // );
        let final_data = {
          id: adminData.id,
          user: adminData.username,
          email: adminData.email,
          // token: jwt_token,
          google2fa_status: adminData.google2fa_status,
        };
        if (req.adminDetails.admin_user_access_data != null) {
          await dbHelper.create_admin_activity_logs({
            email: req.adminDetails.email,
            ip: IP.address(),
            action_type: ActivityHeads.UPDATE_2FA_STATUS,
            role_id: req.adminDetails.role,
            created_at: new Date(),
            updated_at: new Date(),
          });
        }
        data = {
          message: GlblMessages.SUCCESS,
          status: Status.TRUE,
          code: GlblCode.SUCCESS,
          // details: `Token verified successfully.`,
          data: final_data,
        };
      } else {
        data = {
          message: Messages.INVALID_2FA,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
      }
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in google_2fa_verify API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async transactions(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let address_list: any = req.body.addrsListKeys
        ? req.body.addrsListKeys
        : [];
      let fiat_currency: string = String(
        req.body.fiat_currency ? req.body.fiat_currency : Fiat_Currency.USD
      );
      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "25") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let coin_id: number =
        req.body.coin_id == undefined
          ? (req.body.coin_id = GlblBooleanEnum.false)
          : req.body.coin_id;
      let status: GlblBlockchainTxStatusEnum =
        req.body.status == undefined
          ? (req.body.status = null)
          : req.body.status;
      let date_from: number = req.body.date_from ? req.body.date_from : null;
      let date_to: number = req.body.date_to ? req.body.date_to : null;
      let type: any = req.body.trnx_type ? req.body.trnx_type : "all";
      let coin_family: any = req.body.coin_family ? req.body.coin_family : [];

      let where_clause: any = {
        // [Op.or]: [
        //   {
        //     [Op.and]: [
        //       { from_adrs: { [Op.in]: address_list } },
        //       {
        //         [Op.or]: [
        //           { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
        //           { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
        //           { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
        //           { blockchain_status: null },
        //         ],
        //       },
        //     ],
        //   },
        //   {
        //     [Op.and]: [
        //       { to_adrs: { [Op.in]: address_list } },
        //       Sequelize.literal(
        //         `IF(merchant_id IS NOT null, 1 = 1, trnx_history.blockchain_status = "${GlblBlockchainTxStatusEnum.CONFIRMED}")`
        //       ),
        //     ],
        //   },
        // ],
      };

      if (type == TxTypesEnum.DEPOSIT) {
        where_clause = {
          to_adrs: {
            [Op.in]: address_list,
          },
          blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
          [Op.or]: [
            { type: TxTypesEnum.WITHDRAW },
            { type: TxTypesEnum.DEPOSIT },
          ],
        };
      }
      if (type == TxTypesEnum.WITHDRAW) {
        where_clause = {
          from_adrs: {
            [Op.in]: address_list,
          },
          [Op.or]: [
            { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
            { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
            { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
            { blockchain_status: null },
          ],
          [Op.or]: [
            { type: TxTypesEnum.WITHDRAW },
            { type: TxTypesEnum.DEPOSIT },
          ],
        };
      }
      if (type == TxTypesEnum.DAPP) {
        where_clause = {
          [Op.or]: [
            { type: TxTypesEnum.DAPP },
            { type: TxTypesEnum.APPROVE },
            { type: TxTypesEnum.SWAP },
            { type: TxTypesEnum.CROSS_CHAIN },
          ],
          from_adrs: {
            [Op.in]: address_list,
          },
        };
      }
      if (type == TxTypesEnum.BUY) {
        where_clause = {
          to_adrs: {
            [Op.in]: address_list,
          },
          type: TxTypesEnum.BUY,
        };
      }
      if (type == TxTypesEnum.SELL) {
        where_clause = {
          to_adrs: {
            [Op.in]: address_list,
          },
          type: TxTypesEnum.SELL,
        };
      }
      if (type == TxTypesEnum.CARDS) {
        where_clause = {
          [Op.or]: [
            { type: TxTypesEnum.CARD_FEES },
            { type: TxTypesEnum.CARD_RECHARGE },
          ],
          from_adrs: {
            [Op.in]: address_list,
          },
        };
      }
      if (type == TxTypesEnum.LEVEL_UPGRADE) {
        where_clause = {
          type: TxTypesEnum.LEVEL_UPGRADATION_LEVEL,
          from_adrs: {
            [Op.in]: address_list,
          },
        };
      }
      if (status) {
        where_clause = {
          ...where_clause,
          blockchain_status: status,
        };
      }

      //   if (coin_family) {
      //     where_clause = {
      //       ...where_clause,
      //       coin_family: { [Op.in]: coin_family },
      //     };
      //   }
      if (date_from && date_to) {
        where_clause = {
          ...where_clause,
          [Op.and]: Sequelize.literal(
            `DATE(trnx_history.created_at) BETWEEN '${date_from}' and '${date_to}'`
          ),
        };
      }
      let coin_where: any = "";
      if (coin_id > GlblBooleanEnum.false) {
        coin_where = { id: coin_id };
        where_clause = {
          ...where_clause,
          coin_id: coin_id,
        };
      }
      if (search) {
        coin_where = {
          ...coin_where,
          [Op.and]: {
            [Op.or]: {
              coin_name: {
                [Op.like]: search,
              },
              coin_symbol: {
                [Op.like]: search,
              },
            },
          },
        };
      }
      let query: any = {
        attributes: [
          "id",
          [
            Sequelize.literal(
              `IF(type ='withdraw' OR type = 'deposit',(IF(FIND_IN_SET(from_adrs, "${address_list.toString()}"),'withdraw','deposit')),type)`
            ),
            "type",
          ],
          "type",
          "tx_fee",
          "tx_id",
          "user_id",
          "req_type",
          "from_adrs",
          "to_adrs",
          "coin_family",
          "tx_raw",
          "order_id",
          "status",
          "blockchain_status",
          "coin_id",
          "amount",
          "fiat_price",
          "fiat_type",
          "created_at",
          "updated_at",
          "referral_upgrade_level",
        ],
        where: where_clause,
        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_symbol", "coin_name", "coin_image"],
            as: "coin_transation_data",
            where: Sequelize.literal(coin_where),
            include: [
              {
                model: Models.CoinPriceInFiatModel,
                as: "fiat_price_data",
                attributes: [
                  "fiat_type",
                  "value",
                  "price_change_24h",
                  "price_change_percentage_24h",
                ],
                where: { fiat_type: "usd" },
                required: false,
              },
            ],
          },
        ],
        order: [["id", "DESC"]],
        limit: limit,
        offset: offset,
        // logging: true
      };
      let transaction_data: any = await Models.TrnxHistoryModel.findAndCountAll(
        query
      );
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: transaction_data.rows,
          meta: {
            page: page,
            pages: Math.ceil(transaction_data.count / limit),
            perPage: limit,
            total: transaction_data.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > transactions.", err);
      await commonHelper.save_error_logs("wallet_transactions", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async userCount(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      console.log("IIIIIIIIIIII ", req.query.timeLine, req.query);

      let timeLine = req.query.timeLine;
      const currentDate = new Date();
      // Get date 1 day ago
      const oneDayAgo = new Date(currentDate);
      oneDayAgo.setDate(oneDayAgo.getDate() - 1);

      // Get date 7 days ago
      const sevenDaysAgo = new Date(currentDate);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      // Get date 1 month ago
      const oneMonthAgo = new Date(currentDate);
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

      let whereClause: any = null;

      if (timeLine) {
        console.log("INNNNNN");

        let time =
          timeLine == "1d"
            ? oneDayAgo
            : timeLine == "1w"
            ? sevenDaysAgo
            : timeLine == "1m"
            ? oneMonthAgo
            : null;
        whereClause = {
          updated_at: {
            [Op.gte]: time,
          },
        };
      }

      let query = {
        where: whereClause,
        group: ["user_id"],
      };

      console.log("WWWWWWWWWWWWW ", whereClause);

      let activ_user = await Models.DeviceTokenModel.count({
        where: whereClause,
      });
      console.log("active user : ", activ_user);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: activ_user,
        },
      });
    } catch (err: any) {
      console.error("Error in USER COUNT", err);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async users(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "25") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;

      let query: any = "";
      let user_data = await Models.WalletModel.findAndCountAll(query);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: user_data.rows,
          meta: {
            page: page,
            pages: Math.ceil(user_data.count / limit),
            perPage: limit,
            total: user_data.count,
          },
        },
      });
    } catch (err: any) {
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }
  public async sendAllNotifications(req: Request, res: Response) {
    let lang = req.headers["content-language"] || "en";
    try {
      let data: any;
      let {
        details,
        user_ids,
        title,
      }: { details: string; user_ids: any; title: string } = req.body;

      if (!title) {
        title = "ADMIN ANNOUNCEMENT";
      }
      let allValues: any;

      if (user_ids?.length > 100) {
        throw new Error(GlblMessages?.ANNOUNCEMNET_USER_LIMIT);
      }

      if (!user_ids.length) {
        let all_users: any = await Models.WalletModel.findAll({
          attributes: ["user_id"],
          group: ["user_id"],
          raw: true,
        });
        allValues = all_users
          .map((obj: { [s: string]: unknown } | ArrayLike<unknown>) =>
            Object.values(obj)
          )
          .flat();
        console.log("allValues::", allValues);
        user_ids = allValues.join(",");
      } else {
        allValues = user_ids;
        user_ids = user_ids.join(",");
      }
      let announcement_made: any = await Models.AnnouncementModel.create({
        title: title,
        message: details,
        user_id: user_ids,
      });

      const announcementFunction = adminHelper.announcement_part(
        allValues,
        user_ids,
        title,
        details
      );

      if (announcement_made) {
        if (req.adminDetails?.admin_user_access_data != null) {
          await dbHelper.create_admin_activity_logs({
            email: req.adminDetails.email,
            ip: IP.address(),
            action_type: ActivityHeads.MADE_ANNOUNCEMENT,
            role_id: req.adminDetails.admin_user_access_data.role_id,
            created_at: new Date(),
            updated_at: new Date(),
          });
        }
        data = {
          message: GlblMessages.SUCCESS,
          status: Status.TRUE,
          code: GlblCode.SUCCESS,
          data: Messages.ANNOUNCEMENT_MADE,
        };
      } else {
        data = {
          message: Messages.ANNOUNCEMENT_NOT_MADE,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: {},
        };
        return res.status(data.code).send(data);
      }
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in notification_to_all API", err);
      let data: any = {
        message: lang == "en" ? err?.message : GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async users_wallets(req: any, res: any) {
    let lang = req.headers["content-language"] || "en";
    try {
      let fromDate =
        req.body.from_date !== "" && req.body.from_date
          ? req.body.from_date
          : null;
      let toDate =
        req.body.to_date !== "" && req.body.to_date ? req.body.to_date : null;
      let limit = Number(req.body.limit) || 10;
      let search = req.body.search || "";
      let orderByfilter =
        req.body.filter?.toLowerCase() === "ascending" ? "ASC" : "DESC";
      let page = Number(req.body.page) || 1;
      let offset = (page - 1) * limit;
      let flag = 1;

      console.log("from_date::", fromDate);
      console.log("to_date::", toDate);

      if (fromDate && !toDate) {
        toDate = new Date();
      }
      if (!fromDate && toDate) {
        throw new Error("kindly provide the to date");
      }

      let totalCountQuery: any;
      if (search && search !== "") {
        totalCountQuery = {
          where: {
            coin_family: 2,
            [Op.or]: [
              { wallet_name: { [Op.like]: `%${search}%` } },
              // { wallet_address: { [Op.like]: `%${search}%` } },
            ],
            is_deleted: { [Op.or]: [null, 0] },
          },
          attributes: [
            "updated_at",
            [
              Sequelize.fn("COUNT", Sequelize.literal("DISTINCT user_id")),
              "userCount",
            ],
          ],
        };
      } else {
        totalCountQuery = {
          where: {
            coin_family: 2,
            is_deleted: { [Op.or]: [null, 0] },
          },
          attributes: [
            "updated_at",
            [
              Sequelize.fn("COUNT", Sequelize.literal("DISTINCT user_id")),
              "userCount",
            ],
          ],
        };
      }

      let totalCount: any = await Models.WalletModel.findAll(totalCountQuery);
      totalCount = totalCount[0]?.dataValues;

      let whereClause: any;
      if (search && search !== "") {
        whereClause = {
          [Op.or]: [
            { wallet_name: { [Op.like]: `%${search}%` } },
            // { wallet_address: { [Op.like]: `%${search}%` } },
          ],
        };
      }

      console.log("toDatw", toDate);
      if (fromDate && toDate) {
        console.log("inside it ");
        fromDate = new Date(fromDate);
        toDate = new Date(toDate);

        if (fromDate.toString() == toDate.toString()) {
          toDate = getNextDate(toDate);
          console.log("toDate12::", toDate);
        }

        whereClause = {
          ...whereClause,
          [Op.and]: [
            {
              created_at: {
                [Op.gte]: fromDate,
              },
            },
            {
              created_at: {
                [Op.lt]: toDate,
              },
            },
          ],
        };
      }

      let query: any = {
        where: {
          ...whereClause,
          is_deleted: { [Op.or]: [null, 0] },
        },
        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_name"],
            include: {
              model: Models.CoinPriceInFiatModel,
              attributes: ["value"],
              as: "fiat_price_data",
              where: { fiat_type: "usd" },
              required: true,
            },
          },
        ],
        attributes: [
          [
            Sequelize.literal(
              "(SELECT wallet_address FROM wallets AS w2 WHERE w2.user_id = wallets.user_id AND w2.coin_family = 2 LIMIT 1)"
            ),
            "address",
          ],
          [
            Sequelize.literal(
              "(SELECT coin_family FROM wallets AS w2 WHERE w2.user_id = wallets.user_id AND w2.coin_family = 2 LIMIT 1)"
            ),
            "coin_family",
          ],
          "wallet_name",
          "user_id",
          "updated_at",
          "created_at",
          [
            Sequelize.literal(
              "(SELECT Round(SUM(w2.balance * cf.value),4) FROM wallets w2 INNER JOIN coins c ON w2.coin_id = c.coin_id INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd' WHERE w2.user_id = wallets.user_id LIMIT 1)"
            ),
            "total_user_balance",
          ],
        ],
        group: ["user_id"],
        order: [["created_at", orderByfilter]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      const results: any = await Models.WalletModel.findAndCountAll(query);
      // console.log("data::", results);

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: results.rows,
          meta: {
            page: page,
            pages: Math.ceil(results?.count?.length / limit),
            perPage: limit,
            total: results?.count.length,
          },
        },
      });
    } catch (err) {
      console.log("error", err);
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }
  public async announcement_history(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let fromDate =
        req.body.from_date !== "" && req.body.from_date
          ? req.body.from_date
          : null;
      let toDate =
        req.body.to_date !== "" && req.body.to_date ? req.body.to_date : null;
      let orderByfilter =
        req.body.filter?.toLowerCase() === "ascending" ? "ASC" : "DESC";

      if (fromDate && !toDate) {
        toDate = new Date();
      }
      if (!fromDate && toDate) {
        throw new Error("kindly provide the to date");
      }

      let search: any =
        req.body.search == undefined
          ? (req.body.search = "%%")
          : (req.body.search = "%" + req.body.search + "%");
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "10") : req.body.limit
      );
      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;

      let where_clause: any = {};
      if (fromDate && toDate) {
        fromDate = new Date(fromDate);
        toDate = new Date(toDate);

        console.log("fromDate::", fromDate);
        console.log("toDate::", toDate);

        if (fromDate.toString() == toDate.toString()) {
          toDate = getNextDate(toDate);
        }

        where_clause = {
          ...where_clause,
          [Op.and]: [
            {
              updated_at: {
                [Op.gte]: fromDate,
              },
            },
            {
              updated_at: {
                [Op.lt]: toDate,
              },
            },
          ],
        };
      }

      if (req.body?.search) {
        where_clause = {
          ...where_clause,
          [Op.or]: [
            {
              title: {
                [Op.like]: search,
              },
            },
            {
              message: {
                [Op.like]: search,
              },
            },
          ],
        };
      }

      console.log("where::", where_clause);
      let query: any = {
        where: where_clause,

        order: [["updated_at", orderByfilter]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      // console.log("query::",query);
      let announcement_history: any =
        await Models.AnnouncementModel.findAndCountAll(query);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: announcement_history.rows,
          meta: {
            page: page,
            pages: Math.ceil(announcement_history.count / limit),
            perPage: limit,
            total: announcement_history.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in dashboard > announcement_history.", err);
      await commonHelper.save_error_logs("announcement_history", err.message);
      response.error(res, {
        data: {
          status: false,
          message: err.message || language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async downloadCsv(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let fromDate: any =
        req.query.from_date !== "" && req.query.from_date
          ? req.query.from_date
          : null;
      let toDate: any =
        req.query.to_date !== "" && req.query.to_date
          ? req.query.to_date
          : null;
      //console.log("fromDate::",fromDate);
      let orderByfilter: any = req.query.filter;

      orderByfilter =
        orderByfilter?.toLowerCase() === "ascending" ? "ASC" : "DESC";

      console.log("orderByfilter::", orderByfilter);
      if (fromDate && !toDate) {
        toDate = new Date();
      }
      if (!fromDate && toDate) {
        throw new Error("kindly provide the to date");
      }

      let search: any =
        req.query.search == undefined
          ? (req.query.search = "%%")
          : (req.query.search = "%" + req.query.search + "%");
      let limit: number = Number(
        req.query.limit == undefined
          ? (req.query.limit = "10")
          : req.query.limit
      );
      let page: number = Number(
        req.query.page == undefined ? (req.query.page = "1") : req.query.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;

      let where_clause: any = {};
      if (fromDate && toDate) {
        fromDate = new Date(fromDate);
        toDate = new Date(toDate);

        console.log("fromDate::", fromDate);
        console.log("toDate::", toDate);

        if (fromDate.toString() == toDate.toString()) {
          toDate = getNextDate(toDate);
        }

        where_clause = {
          ...where_clause,
          [Op.and]: [
            {
              updated_at: {
                [Op.gte]: fromDate,
              },
            },
            {
              updated_at: {
                [Op.lt]: toDate,
              },
            },
          ],
        };
      }

      if (req.body.search) {
        where_clause = {
          ...where_clause,
          title: {
            [Op.like]: search,
          },
        };
      }

      console.log("where::", where_clause);
      let query: any = {
        where: where_clause,

        order: [["updated_at", orderByfilter]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      let announcement_history: any =
        await Models.AnnouncementModel.findAndCountAll(query);
      let data: any = [];

      let cnt = 1;
      let i;
      for (i = 0; i < announcement_history.rows.length; i++) {
        let obj = announcement_history.rows[i];
        // console.log("announcementlenght",announcement_history.rows.length);
        let cnt = i + 1;
        let lengthArrayOfusers = obj.dataValues.user_id.split(",");

        let sent_users = lengthArrayOfusers.length;
        obj.coin_image = obj.coin?.coin_image;
        obj.coin_name = obj.coin?.coin_name;
        obj.dataValues.count = cnt;
        const downloadDate = formatDateWithAmPm(obj.dataValues.updatedAt);
        // let status="complete";

        const {
          dataValues: { title, message, updatedAt, count },
        }: any = obj;

        data.push({
          cnt,
          title,
          message,
          sent_users,
          // status,
          downloadDate,
        });
      }

      const opts = {
        fields: [
          { label: `${language[lang].SNO}`, value: "cnt" },

          {
            label: `${language[lang].TITLE}`,
            value: "title",
          },
          { label: `${language[lang].MESSAGE}`, value: "message" },
          // { label: `${language[lang].COIN_NAME}`, value: "coin_name" },
          // { label: `${language[lang].COIN_IMAGE}`, value: "coin_image" },

          { label: `${language[lang].SENT_USERS}`, value: "sent_users" },
          // { label: `${language[lang].STATUS}`, value: "status" },
          { label: `${language[lang].DATE}`, value: "downloadDate" },
        ],
      };

      const parser = new Parser(opts);
      const csvData = parser.parse(data);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=announcement_history.csv"
      );
      res.status(GlblCode.SUCCESS).end(csvData);
    } catch (err: any) {
      console.log("error", err);
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }
  public async maintenance_mode(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const adminId: number = req.adminId;

      const adminDetails = await Models.AdminModel.findOne({
        where: { id: adminId },
      });

      if (adminDetails?.maintenance_mode) {
        console.log("in 1");
        await Models.AdminModel.update(
          { maintenance_mode: 0 },
          {
            where: { id: adminId },
          }
        );
      } else {
        console.log("in 2");

        await Models.AdminModel.update(
          { maintenance_mode: 1 },
          {
            where: { id: adminId },
          }
        );
      }

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in dashboard > maintenance_mode_update.", err);
      await commonHelper.save_error_logs("maintenance_mode", err.message);
      response.error(res, {
        data: {
          status: false,
          message: err.message || language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async maintenance_mode_status(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const adminId: number = req.adminId;

      const adminDetails = await Models.AdminModel.findOne({
        where: { id: adminId },
      });

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          status: adminDetails?.maintenance_mode,
        },
      });
    } catch (err: any) {
      console.error("Error in dashboard > maintenance_mode_status.", err);
      await commonHelper.save_error_logs("maintenance_mode", err.message);
      response.error(res, {
        data: {
          status: false,
          message: err.message || language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async userCountPieGraph(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let timeLine = req.query.timeLine;
      const currentDate = new Date();
      // Get date 1 day ago
      const oneDayAgo = new Date(currentDate);
      oneDayAgo.setDate(oneDayAgo.getDate() - 1);
      oneDayAgo.setHours(0);
      oneDayAgo.setMinutes(0);
      oneDayAgo.setSeconds(0);
      oneDayAgo.setMilliseconds(0);

      // Get date 7 days ago
      const sevenDaysAgo = new Date(currentDate);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      // Get date 1 month ago
      const oneMonthAgo = new Date(currentDate);
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

      let whereClause = {
        created_at: {
          [Op.gte]: oneDayAgo,
        },
      };
      let exitingWhereClause = {
        created_at: {
          [Op.lte]: oneDayAgo,
        },
      };

      let new_user = await Models.UsersModel.count({
        where: whereClause,
      });

      let existing_user = await Models.UsersModel.count({
        where: exitingWhereClause,
      });

      // let activ_user = await Models.DeviceTokenModel.count({
      //   where: whereClause,
      // });
      // console.log("active user : ", activ_user);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          new_user: new_user,
          existing_user: existing_user,
        },
      });
    } catch (err: any) {
      console.error("Error in USER COUNT", err);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  public async check_auth_secret_key_dashboard(req: Request, res: Response) {
    try {
      let { token, password }: { token: number; password: string } = req.body;
      const adminId: number = req.adminId;

      const result: any = google_2fa_verify_dashboard(token, adminId, password);

      if (result.status) {
        return response.success(res, {
          data: result,
        });
      } else {
        response.error(res, {
          data: result,
        });
      }
    } catch (err: any) {
      console.error("Error in admin login API", err);
      let data: any = {
        message: err.message || GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
}

export const adminController = new AdminController();
