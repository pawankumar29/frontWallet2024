import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";

const crypto = require("crypto");
import {
  Fiat_Currency,
  GlblBlockchainTxStatusEnum,
  GlblBooleanEnum,
  GlblCode,
  GlblMessages,
  TxTypesEnum,
} from "./../../constants/global_enum";
import { Status, language } from "./../../constants";

import { Op, Sequelize, where } from "sequelize";
import response from "../../helpers/response/response.helpers";
import commonHelper from "../../helpers/common/common.helpers";
import { Parser } from "json2csv";
import {
  formatDate,
  formatDateWithAmPm,
  getAddress,
  getChain,
  MakeFirstLettarCapital,
} from "../helper/helper";
import moment from "moment";
import db from "../../helpers/common/db";
const IP = require("ip");

class UserController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() {}

  public async userCount(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let timeLine = req.query.timeLine;
      const currentDate = new Date();
      // Get date 1 day ago
      const oneDayAgo = new Date(currentDate);
      oneDayAgo.setDate(oneDayAgo.getDate() - 1);

      // Get date 7 days ago
      const sevenDaysAgo = new Date(currentDate);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      // Get date 1 month ago
      const oneMonthAgo = new Date(currentDate);
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

      let whereClause: any = null;

      if (timeLine) {
        let time =
          timeLine == "1d"
            ? oneDayAgo
            : timeLine == "1w"
            ? sevenDaysAgo
            : timeLine == "1m"
            ? oneMonthAgo
            : null;
        whereClause = {
          login_time: {
            [Op.gte]: time,
          },
        };
      }

      let query = {
        where: whereClause,

        include: {
          model: Models.WalletModel,
          as: "user_wallet_relation",
          required: true,
        },
        group: ["user_id"],
        logging: true,
      };

      let totalCountQuery = {
        attributes: ["user_id"],
        where: {},
        include: {
          model: Models.WalletModel,
          as: "user_wallet_relation",
          required: true,
        },
        logging: true,
      };

      let activ_user = await Models.UsersModel.findAll(query);
      let total_user = await Models.UsersModel.findAll(totalCountQuery);
      // console.log("active user : ", activ_user);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: activ_user?.length,
          total_user: total_user?.length,
        },
      });
    } catch (err: any) {
      console.error("Error in USER COUNT", err);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async swap_transaction(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "10") : req.body.limit
      );
      let filterType = req.body?.filter_type?.toLowerCase();
      filterType = filterType.replace(/\s+/g, " ");

      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      // validation
      const walletAddressList: [] = req.body.address_list;

      let where_clause: any = {
        [Op.and]: [
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.DEPOSIT}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.WITHDRAW}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.BUY}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.SELL}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
            },
          },
          {
            type: {
              [Op.notLike]: `%${TxTypesEnum.SELL}%`,
            },
          },
        ],
      };

      if (filterType === "cross-chain" || filterType === "cross-chain swap") {
        where_clause = {
          type: "cross_chain",
          [Op.or]: [
            {
              from_adrs: {
                [Op.in]: walletAddressList,
              },
            },
            {
              to_adrs: {
                [Op.in]: walletAddressList,
              },
            },
          ],
        };
      } else if (filterType === "on-chain" || filterType === "on-chain swap") {
        where_clause = {
          type: "Swap",
          [Op.or]: [
            {
              from_adrs: {
                [Op.in]: walletAddressList,
              },
            },
            {
              to_adrs: {
                [Op.in]: walletAddressList,
              },
            },
          ],
        };
      } else {
        where_clause = {
          //  blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
          ...where_clause,

          [Op.or]: [
            {
              type: {
                [Op.like]: "%Swap%",
              },
            },
            {
              type: {
                [Op.like]: "%cross_chain%",
              },
            },
          ],

          [Op.or]: [
            {
              from_adrs: {
                [Op.in]: walletAddressList,
              },
            },
            {
              to_adrs: {
                [Op.in]: walletAddressList,
              },
            },
          ],
        };
      }

      let status = req.body?.status?.toLowerCase();

      if (status != "" && status && status != "all") {
        where_clause = {
          ...where_clause,
          blockchain_status: status,
        };
      }

      console.log("where::", where_clause);

      let query: any = {
        attributes: [
          "from_adrs",
          "to_adrs",
          "updated_at",
          "tx_id",
          "amount",
          "type",
          "blockchain_status",
          "coin_family",
        ],
        where: where_clause,

        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_name", "coin_id", "coin_image", "coin_symbol"],
            as: "coin_transation_data",
            required: false,
            include: [
              {
                model: Models.CoinPriceInFiatModel,
                attributes: [["value", "price"]],
                as: "fiat_price_data",
                where: {
                  fiat_type: "usd",
                },
                required: false,
              },
            ],
          },
        ],
        logging: true,
        order: [["updated_at", "DESC"]],

        limit: limit,
        offset: offset,
      };
      let transaction_data: any = await Models.TrnxHistoryModel.findAndCountAll(
        query
      );

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: transaction_data.rows,
          meta: {
            page: page,
            pages: Math.ceil(transaction_data?.count / limit),
            perPage: limit,
            total: transaction_data?.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > swap_transaction.", err);
      await commonHelper.save_error_logs("swap_transaction", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async send_receive_transaction(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "10") : req.body.limit
      );

      const walletAddressList: [] = req.body.address_list;

      if (!walletAddressList.length) {
        throw new Error("No Address Provided");
      }

      let filterType = req.body?.filter_type?.toLowerCase();

      let status = req.body?.status?.toLowerCase();

      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let wallet_address: any = req.body.wallet_address; // validation
      console.log("page::", page);
      console.log("offset::", offset);
      // changes

      let where_clause: any = {};
      if (filterType == TxTypesEnum.DEPOSIT) {
        where_clause = {
          to_adrs: {
            [Op.in]: walletAddressList,
          },

          blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,

          [Op.or]: [
            { type: TxTypesEnum.DEPOSIT },
            { type: TxTypesEnum.WITHDRAW },
          ],

          // type: TxTypesEnum.DEPOSIT,
        };
      } else if (filterType == TxTypesEnum.WITHDRAW) {
        where_clause = {
          from_adrs: {
            [Op.in]: walletAddressList,
          },
          [Op.and]: [
            {
              [Op.or]: [
                { type: TxTypesEnum.DEPOSIT },
                { type: TxTypesEnum.WITHDRAW },
              ],
            },

            // type: TxTypesEnum.WITHDRAW,
            {
              [Op.or]: [
                { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
                { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
                { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
                { blockchain_status: null },
              ],
            },
          ],
        };
      } else {
        console.log("inside Dapp");
        where_clause = {
          [Op.and]: [
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
              },
            },

            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.BUY}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
              },
            },
            {
              type: {
                [Op.notLike]: "Swap",
              },
            },
            {
              type: {
                [Op.notLike]: "cross_chain",
              },
            },
          ],

          [Op.or]: [
            {
              from_adrs: {
                [Op.in]: walletAddressList,
              },
            },
            {
              to_adrs: {
                [Op.in]: walletAddressList,
              },
            },
          ],
        };
      }

      if (status !== "" && status && status != "all") {
        where_clause = {
          ...where_clause,
          blockchain_status: status,
        };
      }

      console.log("wallet_address::", walletAddressList);
      //changes

      console.log("where::", where_clause);

      let condAdded = {
        tx_id: {
          [Op.notIn]: Sequelize.literal(
            `(select tx_id from trnx_histories where type="Swap" or type="cross_chain")`
          ),
        },
      };

      let query: any = {
        attributes: [
          "updated_at",
          "type",
          // [
          //   Sequelize.literal(`
          //     SELECT tx_id FROM trnx_history t
          //     WHERE t.type=deposit limit 1
          //   `),
          //   "tx_id1"
          // ],
          "tx_id",
          "amount",
          [
            Sequelize.literal(
              `CASE WHEN from_adrs IN (:walletAddressList) THEN from_adrs 
               ELSE to_adrs 
               END`
            ),
            "tx_wallet_address",
          ],

          "from_adrs",
          "to_adrs",
          "blockchain_status",
          "coin_family",
        ],

        where: {
          // ...condAdded,  // removed as dicuss
          ...where_clause,
        },

        include: [
          {
            model: Models.CoinsModel,
            attributes: [
              "coin_family",
              "coin_symbol",
              "coin_name",
              "coin_id",
              "coin_image",
            ],
            as: "coin_transation_data",
            required: false,
            include: [
              {
                model: Models.CoinPriceInFiatModel,
                attributes: [["value", "price"]],
                as: "fiat_price_data",
                where: {
                  fiat_type: "usd",
                },
                required: false,
              },
            ],
          },
        ],
        replacements: {
          walletAddressList: walletAddressList,
        },
        order: [["updated_at", "DESC"]],

        limit: limit,
        offset: offset,
        //logging: true,
      };

      let finalData: any;

      finalData = await Models.TrnxHistoryModel.findAndCountAll(query);

      //console.log("finalData::", finalData);

      // changes

      if (finalData?.rows?.length) {
        for (let i = 0; i < finalData?.rows?.length; i++) {
          let data = finalData.rows[i].dataValues;
          let to_adrs: any = data.to_adrs;
          let from_adrs: any = data.from_adrs;

          if (walletAddressList.includes(to_adrs as never)) {
            data.type = "Deposit";
          } else if (walletAddressList.includes(from_adrs as never)) {
            data.type = "Withdraw";
          }
        }
      }

      // changes

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data:
            filterType == TxTypesEnum.DEPOSIT ||
            filterType == TxTypesEnum.WITHDRAW
              ? finalData.rows.filter((e: any) => {
                  return (
                    e.dataValues.type.toLowerCase() == filterType.toLowerCase()
                  );
                })
              : finalData?.rows,
          meta: {
            page: page,
            pages: Math.ceil(finalData?.count / limit),
            perPage: limit,
            total: finalData?.count,
          },
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > send_receive_transaction.", err);
      await commonHelper.save_error_logs(
        "send_receive_transaction",
        err.message
      );
      response.error(res, {
        data: {
          status: false,
          message: err.message || language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async referralUserSpecific(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let limit: number = Number(
        req.body.limit == undefined ? (req.body.limit = "25") : req.body.limit
      );

      let page: number = Number(
        req.body.page == undefined ? (req.body.page = "1") : req.body.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let user_id: any = req.params.userId; // validation

      let query: any = {
        // attributes: ["address", "amount", "type"],
        where: {
          referrer_from: user_id,
        },

        // include: {
        //   model: Models.UsersModel,
        //   required: true,
        // },
        // limit: limit,
        // offset: offset,
        //logging: true,
      };
      let rewardHistoryData: any = await Models.ReferralModel.findAndCountAll(
        query
      );

      let data = {
        success: true,
        message: GlblMessages.SUCCESS,
        data: rewardHistoryData.rows,
        totalReferrals: rewardHistoryData.rows.length,
      };

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: data,
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > referralUserSpecific.", err);
      await commonHelper.save_error_logs("referralUserSpecific", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async userbalance(req: Request | any, res: Response) {
    try {
      let user_id = req.params.userId;
      //console.log("req.user==>", req.user);
      let where_clause: any = {
        status: GlblBooleanEnum.true,
        user_id: user_id,
        // balance: { [Op.gt]: GlblBooleanEnum.false },
      };

      const user_details: any = await Models.UsersModel.findOne({
        where: {
          user_id: user_id,
        },
      });

      let user_data: any = await Models.WalletModel.findAndCountAll({
        attributes: [
          "user_id",
          "email",
          "login_type",
          "wallet_name",
          "wallet_address",
          "coin_id",
          "coin_family",
          "balance",
        ],
        where: where_clause,

        include: [
          {
            model: Models.CoinsModel,
            attributes: [
              "coin_name",
              "coin_symbol",
              "coin_image",
              "is_token",
              "coin_status",
            ],
            where: {
              //coin_status: GlblBooleanEnum.true,
            },
            //required:false,
            include: [
              {
                model: Models.CoinPriceInFiatModel,
                as: "fiat_price_data",
                attributes: [
                  "value",
                  "price_change_24h",
                  "fiat_type",
                  "price_change_percentage_24h",
                ],
                where: {
                  fiat_type: "usd",
                },
                required: false,
              },
            ],
          },
        ],
      });
      let data: any = {
        message: GlblMessages.SUCCESS,
        status: 1,
        code: GlblCode.SUCCESS,
        data: {
          data: user_data.rows,
          total_referrals: user_details.referral_count,
          meta: { total: user_data.count },
        },
      };
      return res.status(data.code).send(data);
    } catch (err: any) {
      console.error("Error in user_data API", err);
      let data: any = {
        message: GlblMessages.CATCH_MSG,
        status: Status.FALSE,
        code: GlblCode.ERROR_CODE,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async deleteUser(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let query: any;
      //changes
      const userId = req.params.user_id;

      await Models.WalletModel.update(
        { is_deleted: 1 },
        {
          where: {
            user_id: userId,
          },
        }
      );

      // await Models.UsersModel.destroy({
      //   where: {
      //     user_id: userId,
      //   },
      // });

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in user > deleteUser.", err);
      await commonHelper.save_error_logs("deleteUser", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async deleteMultipleUser(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      //changes
      const userIdArray: any = req.body.user_ids;

      if (userIdArray.length == 0) {
        throw new Error("No Ids Provided To Delete");
      }

      // const ids=userIdArray.split(',');
      // console.log("useridsArray::",ids);

      await Models.WalletModel.update(
        { is_deleted: 1 },
        {
          where: {
            user_id: {
              [Op.in]: userIdArray,
            },
          },
        }
      );

      // await Models.UsersModel.destroy({
      //   where: {
      //     user_id: userId,
      //   },
      // });

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
        },
      });
    } catch (err: any) {
      console.error("Error in user > deleteUser.", err);
      await commonHelper.save_error_logs("deleteUser", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async getAllWallets(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let query: any;
      //changes
      const userId = req.params.user_id;
      query = {
        attributes: ["wallet_address", "coin_family"],
        where: {
          user_id: userId,
        },
        group: ["coin_family"],
        logging: true,
      };

      const result = await Models.WalletModel.findAll(query);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: result,
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > send_receive_transaction.", err);
      await commonHelper.save_error_logs(
        "send_receive_transaction",
        err.message
      );
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  // public async users_wallets(req: Request, res: Response) {
  //   let lang: any = req.headers["content-language"] || "en";
  //   try {
  //     let limit: number = Number(
  //       req.body.limit == undefined ? (req.body.limit = "10") : req.body.limit
  //     );

  //     let search = req.body?.search ? req.body.search : "";

  //     let orderByfilter: any = req.body.filter == "ascending" ? "ASC" : "DESC";

  //     let page: number = Number(
  //       req.body.page == undefined ? (req.body.page = "1") : req.body.page
  //     );
  //     let offset: number = (page - GlblBooleanEnum.true) * limit;

  //     let totalCountquery: any;
  //     if (search && search != "") {
  //       totalCountquery = `SELECT updated_at ,COUNT(DISTINCT user_id) as userCount FROM wallets w WHERE w.coin_family =2 and ( w.wallet_name like "${search}" OR w.wallet_address like "${search}") and (w.is_deleted is null or w.is_deleted=0)  order by updated_at desc`;
  //     } else {
  //       totalCountquery =
  //         "SELECT updated_at,COUNT(DISTINCT user_id) as userCount FROM wallets w WHERE coin_family = 2 and (w.is_deleted is null or w.is_deleted=0)";
  //     }

  //     let query: any;
  //     search = search?.toString();
  //     // console.log("search::", search);
  //     if (search && search != "") {
  //       query = `
  //       SELECT
  //       (select w2.wallet_address from wallets w2 where w2.user_id = w.user_id AND w2.coin_family=2 limit 1) as address,
  //       (select w2.coin_family from wallets w2 where w2.user_id = w.user_id AND w2.coin_family=2 limit 1)as  coin_family,
  //       w.wallet_name,
  //         w.user_id,
  //         w.created_at,
  //         w.updated_at,
  //         ROUND(SUM(w.balance * cf.value), 4) AS total_user_balance,
  //         c.coin_name
  //       FROM wallets w
  //       INNER JOIN coins c ON c.coin_id = w.coin_id
  //       INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd'
  //       WHERE (w.is_deleted is null or w.is_deleted=0)
  //       and ( w.wallet_name like "${search}"
  //       OR w.wallet_address like "${search}")
  //       GROUP BY w.user_id order by w.updated_at ${orderByfilter} limit ${limit} offset ${offset}
  //     `;
  //     } else {
  //       query = `
  //         SELECT
  //         (select w2.wallet_address from wallets w2 where w2.user_id = w.user_id AND w2.coin_family=2 limit 1) as address,
  //         (select w2.coin_family from wallets w2 where w2.user_id = w.user_id AND w2.coin_family=2 limit 1)as  coin_family,
  //                  w.wallet_name,
  //           w.user_id,
  //           w.created_at,
  //           w.updated_at,
  //           ROUND(SUM(w.balance * cf.value), 4) AS total_user_balance,
  //           c.coin_name
  //         FROM wallets w
  //         INNER JOIN coins c ON c.coin_id = w.coin_id
  //         INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd'
  //         WHERE   w.is_deleted is null or w.is_deleted=0
  //         GROUP BY w.user_id order by w.updated_at ${orderByfilter} limit ${limit} offset ${offset}
  //       `;
  //     }

  //     const [results] = await db.db_read.query(query,{logging:true});

  //     const [count]: any = await db.db_read.query(totalCountquery);

  //     //console.log("results::",results);
  //     return response.success(res, {
  //       data: {
  //         success: true,
  //         message: GlblMessages.SUCCESS,
  //         data: results,
  //         meta: {
  //           page: page,
  //           pages: Math.ceil(count[0]?.userCount / limit),
  //           perPage: limit,
  //           total: count[0]?.userCount,
  //         },
  //       },
  //     });
  //   } catch (err: any) {
  //     console.log("error", err);
  //     response.error(res, {
  //       data: { status: false, message: language[lang].CATCH_MSG },
  //     });
  //   }
  // }
  // public async exportCsv(req: Request, res: Response) {
  //   let lang: any = req.headers["content-language"] || "en";
  //   try {
  //     let limit: number = Number(
  //       req.query.limit == undefined
  //         ? (req.query.limit = "10")
  //         : req.query.limit
  //     );

  //     let search = req.query?.search ? req.query.search : "";

  //     let orderByfilter: any = req.query.filter == "ascending" ? "ASC" : "DESC";

  //     let page: number = Number(
  //       req.query.page == undefined ? (req.query.page = "1") : req.query.page
  //     );
  //     let offset: number = (page - GlblBooleanEnum.true) * limit;

  //     let query: any;
  //     search = search?.toString();
  //     if (search && search != "") {
  //       query = `
  //       SELECT
  //         w.wallet_address AS address,
  //         w.coin_family,
  //         w.wallet_name,
  //         w.user_id,
  //         w.created_at,
  //         w.updated_at,
  //         ROUND(SUM(w.balance * cf.value), 4) AS total_user_balance,
  //         c.coin_name
  //       FROM wallets w
  //       INNER JOIN coins c ON c.coin_id = w.coin_id
  //       INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd'
  //       WHERE (w.is_deleted is null or w.is_deleted=0)
  //       and ( w.wallet_name like "${search}"
  //       OR w.wallet_address like "${search}")
  //       GROUP BY user_id order by w.created_at ${orderByfilter} limit ${limit} offset ${offset}
  //     `;
  //     } else {
  //       query = `
  //         SELECT
  //           w.wallet_address AS address,
  //           w.coin_family,
  //           w.wallet_name,
  //           w.user_id,
  //           w.created_at,
  //           w.updated_at,
  //           ROUND(SUM(w.balance * cf.value), 4) AS total_user_balance,
  //           c.coin_name
  //         FROM wallets w
  //         INNER JOIN coins c ON c.coin_id = w.coin_id
  //         INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd'
  //         WHERE w.is_deleted is null or w.is_deleted=0
  //         GROUP BY user_id order by w.created_at ${orderByfilter} limit ${limit} offset ${offset}
  //       `;
  //     }

  //     const [results] = await db.db_read.query(query);

  //     let data: any = [];
  //     results.map((obj: any) => {
  //       obj.coin_image = obj.coin?.coin_image;
  //       obj.coin_name = obj.coin?.coin_name;
  //       obj.date = formatDate(obj.created_at);

  //       const { address, wallet_name, total_user_balance, date }: any = obj;

  //       data.push({
  //         date,
  //         address,
  //         wallet_name,
  //         total_user_balance,
  //       });
  //     });

  //     const opts = {
  //       fields: [
  //         { label: `${language[lang].DATE}`, value: "date" },

  //         {
  //           label: `${language[lang].WALLET_ADDRESS}`,
  //           value: "address",
  //         },
  //         { label: `${language[lang].WALLET_NAME}`, value: "wallet_name" },
  //         // { label: `${language[lang].COIN_NAME}`, value: "coin_name" },
  //         // { label: `${language[lang].COIN_IMAGE}`, value: "coin_image" },

  //         { label: `${language[lang].BALANCE}`, value: "total_user_balance" },
  //         // { label: `${language[lang].USD_AMOUNT}`, value: "value" },
  //         // { label: `${language[lang].DATE}`, value: "created_at" },
  //       ],
  //     };

  //     const parser = new Parser(opts);
  //     const csvData = parser.parse(data);
  //     res.setHeader("Content-Type", "text/csv");
  //     res.setHeader(
  //       "Content-Disposition",
  //       "attachment; filename=transaction_history.csv"
  //     );
  //     res.status(GlblCode.SUCCESS).end(csvData);
  //   } catch (err: any) {
  //     console.log("error", err);
  //     response.error(res, {
  //       data: { status: false, message: language[lang].CATCH_MSG },
  //     });
  //   }
  // }

  public async exportCsv(req: Request, res: Response) {
    let lang = req.headers["content-language"] || "en";
    try {
      let limit = Number(req.query.limit) || 10;
      let search = req.query.search || "";

      let orderByfilter: any = req.query.filter;
      let page = Number(req.query.page) || 1;
      let offset = (page - 1) * limit;

      orderByfilter =
        orderByfilter?.toLowerCase() === "ascending" ? "ASC" : "DESC";

      console.log("page::", page);
      console.log("offset::", offset);

      let totalCountQuery: any;
      if (search && search !== "") {
        totalCountQuery = {
          where: {
            coin_family: 2,
            [Op.or]: [
              { wallet_name: { [Op.like]: `%${search}%` } },
              { wallet_address: { [Op.like]: `%${search}%` } },
            ],
            is_deleted: { [Op.or]: [null, 0] },
          },
          attributes: [
            "updated_at",
            [
              Sequelize.fn("COUNT", Sequelize.literal("DISTINCT user_id")),
              "userCount",
            ],
          ],
        };
      } else {
        totalCountQuery = {
          where: {
            coin_family: 2,
            is_deleted: { [Op.or]: [null, 0] },
          },
          attributes: [
            "updated_at",
            [
              Sequelize.fn("COUNT", Sequelize.literal("DISTINCT user_id")),
              "userCount",
            ],
          ],
        };
      }

      let totalCount: any = await Models.WalletModel.findAll(totalCountQuery);
      totalCount = totalCount[0]?.dataValues;

      let query: any = {
        where: {
          is_deleted: { [Op.or]: [null, 0] },
        },
        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_name"],
            include: {
              model: Models.CoinPriceInFiatModel,
              attributes: ["value"],
              as: "fiat_price_data",
              where: { fiat_type: "usd" },
              required: true,
            },
          },
        ],
        attributes: [
          [
            Sequelize.literal(
              "(SELECT wallet_address FROM wallets AS w2 WHERE w2.user_id = wallets.user_id AND w2.coin_family = 2 LIMIT 1)"
            ),
            "address",
          ],
          [
            Sequelize.literal(
              "(SELECT coin_family FROM wallets AS w2 WHERE w2.user_id = wallets.user_id AND w2.coin_family = 2 LIMIT 1)"
            ),
            "coin_family",
          ],
          "wallet_name",
          "user_id",
          "created_at",
          "updated_at",
          [
            Sequelize.literal(
              "(SELECT Round(SUM(w2.balance * cf.value),4) FROM wallets w2 INNER JOIN coins c ON w2.coin_id = c.coin_id INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd' WHERE w2.user_id = wallets.user_id LIMIT 1)"
            ),
            "total_user_balance",
          ],
        ],
        group: ["user_id"],
        order: [["total_user_balance", orderByfilter]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      if (search && search !== "") {
        query.where[Op.or] = [
          { wallet_name: { [Op.like]: `%${search}%` } },
          { wallet_address: { [Op.like]: `%${search}%` } },
        ];
      }

      const results = await Models.WalletModel.findAll(query);
      console.log("results::", results);
      let data: any = [];
      results.map((obj: any) => {
        console.log("obj::", obj);

        obj.coin_image = obj.coin?.coin_image;
        obj.coin_name = obj.coin?.coin_name;
        const param = obj.dataValues.created_at;
        obj.dataValues.date = formatDateWithAmPm(param);

        let {
          dataValues: { address, wallet_name, total_user_balance, date },
        }: any = obj;

        //adding to fixed
        total_user_balance = total_user_balance.toFixed(4);

        data.push({
          date,
          address,
          wallet_name,
          total_user_balance,
        });
      });

      const opts = {
        fields: [
          { label: `${language[lang].DATE}`, value: "date" },
          { label: `${language[lang].WALLET_NAME}`, value: "wallet_name" },

          {
            label: `${language[lang].WALLET_ADDRESS}`,
            value: "address",
          },
          // { label: `${language[lang].COIN_NAME}`, value: "coin_name" },
          // { label: `${language[lang].COIN_IMAGE}`, value: "coin_image" },

          {
            label: `${language[lang].MULTICHAIN_PORTFOLIO}`,
            value: "total_user_balance",
          },
          // { label: `${language[lang].USD_AMOUNT}`, value: "value" },
          // { label: `${language[lang].DATE}`, value: "created_at" },
        ],
      };

      const parser = new Parser(opts);
      const csvData = parser.parse(data);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=user_list.csv"
      );
      res.status(GlblCode.SUCCESS).end(csvData);
    } catch (err: any) {
      console.log("error", err);
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }

  public async downloadCsv(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      let limit: number = Number(
        req.query.limit == undefined
          ? (req.query.limit = "10")
          : req.query.limit
      );
      let address: any = req.query?.address;
      let walletAddressList: any = address?.split(",");
      let query: any;
      let type_check = req.query.type;
      let filterType: any = req.query?.filter_type;
      let status: any = req.query?.status;
      let page: number = Number(
        req.query.page == undefined ? (req.query.page = "1") : req.query.page
      );
      let offset: number = (page - GlblBooleanEnum.true) * limit;
      let wallet_address: any = req.params.wallet_address;
      let where_clause: any = {};

      // changes

      filterType = filterType?.toLowerCase();
      filterType = filterType.replace(/\s+/g, " ");
      status = status?.toLowerCase();

      if (type_check === "transaction") {
        //let where_clause: any = {};
        if (filterType == TxTypesEnum.DEPOSIT) {
          where_clause = {
            to_adrs: {
              [Op.in]: walletAddressList,
            },

            blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,

            [Op.or]: [
              { type: TxTypesEnum.DEPOSIT },
              { type: TxTypesEnum.WITHDRAW },
            ],
          };
        } else if (
          filterType == TxTypesEnum.WITHDRAW ||
          filterType == "withdrawal"
        ) {
          where_clause = {
            from_adrs: {
              [Op.in]: walletAddressList,
            },
            [Op.and]: [
              {
                [Op.or]: [
                  { type: TxTypesEnum.DEPOSIT },
                  { type: TxTypesEnum.WITHDRAW },
                ],
              },

              // type: TxTypesEnum.WITHDRAW,
              {
                [Op.or]: [
                  { blockchain_status: GlblBlockchainTxStatusEnum.PENDING },
                  { blockchain_status: GlblBlockchainTxStatusEnum.FAILED },
                  { blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED },
                  { blockchain_status: null },
                ],
              },
            ],
          };
        } else {
          where_clause = {
            [Op.and]: [
              {
                type: {
                  [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
                },
              },

              {
                type: {
                  [Op.notLike]: `%${TxTypesEnum.BUY}%`,
                },
              },
              {
                type: {
                  [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
                },
              },
              {
                type: {
                  [Op.notLike]: `%${TxTypesEnum.SELL}%`,
                },
              },
              {
                type: {
                  [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
                },
              },
              {
                type: {
                  [Op.notLike]: "Swap",
                },
              },
              {
                type: {
                  [Op.notLike]: "cross_chain",
                },
              },
            ],

            [Op.or]: [
              {
                from_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
              {
                to_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
            ],
          };
        }

        if (status !== "" && status) {
          where_clause = {
            ...where_clause,
            blockchain_status: status,
          };
        }

        //changes

        console.log("where::", where_clause);

        query = {
          attributes: [
            "updated_at",
            "type",
            "tx_id",
            "amount",
            [
              Sequelize.literal(
                `CASE WHEN from_adrs IN (:walletAddressList) THEN from_adrs ELSE to_adrs END`
              ),
              "tx_wallet_address",
            ],
            "from_adrs",
            "to_adrs",
            "blockchain_status",
            "coin_family",
          ],
          where: where_clause,

          include: [
            {
              model: Models.CoinsModel,
              attributes: [
                "coin_family",
                "coin_symbol",
                "coin_name",
                "coin_id",
                "coin_image",
              ],
              as: "coin_transation_data",
              required: false,
              include: [
                {
                  model: Models.CoinPriceInFiatModel,
                  attributes: ["value"],
                  as: "fiat_price_data",
                  where: {
                    fiat_type: "usd",
                  },
                  required: false,
                },
              ],
            },
          ],
          replacements: {
            walletAddressList: walletAddressList,
          },
          order: [["updated_at", "DESC"]],
          limit: limit,
          offset: offset,
        };
      } else {
        // let where_clause: any = {};

        let where_clause: any = {
          [Op.and]: [
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DEPOSIT}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.APPROVE}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.WITHDRAW}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.BUY}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.DAPP}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SMARTCONTRACTINTERACTION}%`,
              },
            },
            {
              type: {
                [Op.notLike]: `%${TxTypesEnum.SELL}%`,
              },
            },
          ],
        };

        if (filterType === "cross-chain" || filterType === "cross-chain swap") {
          where_clause = {
            type: "cross_chain",
            [Op.or]: [
              {
                from_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
              {
                to_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
            ],
          };
        } else if (
          filterType === "on-chain" ||
          filterType === "on-chain swap"
        ) {
          where_clause = {
            type: "Swap",
            [Op.or]: [
              {
                from_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
              {
                to_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
            ],
          };
        } else {
          where_clause = {
            //  blockchain_status: GlblBlockchainTxStatusEnum.CONFIRMED,
            ...where_clause,

            [Op.or]: [
              {
                type: {
                  [Op.like]: "%Swap%",
                },
              },
              {
                type: {
                  [Op.like]: "%cross_chain%",
                },
              },
            ],

            [Op.or]: [
              {
                from_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
              {
                to_adrs: {
                  [Op.in]: walletAddressList,
                },
              },
            ],
          };
        }

        // let status = req.body?.status?.toLowerCase();

        if (status != "" && status && status != "all") {
          where_clause = {
            ...where_clause,
            blockchain_status: status,
          };
        }

        console.log("where::", where_clause);

        query = {
          attributes: [
            "from_adrs",
            "to_adrs",
            "updated_at",
            "tx_id",
            "amount",
            "type",
            "blockchain_status",
            "coin_family",
          ],
          where: where_clause,

          include: [
            {
              model: Models.CoinsModel,
              attributes: ["coin_name", "coin_id", "coin_image", "coin_symbol"],
              as: "coin_transation_data",
              required: false,
              include: [
                {
                  model: Models.CoinPriceInFiatModel,
                  attributes: [["value", "price"]],
                  as: "fiat_price_data",
                  where: {
                    fiat_type: "usd",
                  },
                  required: false,
                },
              ],
            },
          ],
          logging: true,
          order: [["updated_at", "DESC"]],

          limit: limit,
          offset: offset,
        };
      }

      let finalData: any;

      finalData = await Models.TrnxHistoryModel.findAll(query);

      const data: any = [];
      let opts: any;

      if (type_check === "transaction") {
        if (finalData?.length) {
          // array changes

          for (let i = 0; i < finalData?.length; i++) {
            let data = finalData[i];
            let to_adrs: any = data.to_adrs;
            let from_adrs: any = data.from_adrs;

            if (walletAddressList.includes(to_adrs as never)) {
              data.type = "Deposit";
            } else if (walletAddressList.includes(from_adrs as never)) {
              data.type = "Withdraw";
            }
          }

          finalData =
            filterType == TxTypesEnum.DEPOSIT ||
            filterType == TxTypesEnum.WITHDRAW
              ? finalData
                  .map((m: any) => {
                    return m;
                  })
                  .filter(
                    (d: any) => d.type.toLowerCase() == filterType.toLowerCase()
                  )
              : finalData;
        }

        // array changes
        // changes
        finalData.map((obj: any) => {
          obj.coin_symbol = obj.coin_transation_data?.coin_symbol;
          obj.coin_name = obj.coin_transation_data?.coin_name;
          obj.price = obj.coin_transation_data?.fiat_price_data?.value;
          obj.type =
            obj.type.toLowerCase() == "withdraw"
              ? "Withdrawal"
              : MakeFirstLettarCapital(obj.type);
          obj.status = MakeFirstLettarCapital(obj.blockchain_status);

          //obj.wallet_address = wallet_address;
          obj.tx_wallet_address = getAddress(
            obj.from_adrs,
            obj.to_adrs,
            walletAddressList
          );
          obj.totalValue =
            obj.price && obj.amount ? eval(`${obj.price} * ${obj.amount}`) : 0;
          obj.date = formatDateWithAmPm(obj.updated_at);

          let {
            date,
            type,
            coin_name,
            coin_symbol,
            tx_wallet_address,
            tx_id,
            status,
            amount,
            totalValue,
          }: any = obj;

          amount = amount.toFixed(4);
          totalValue = totalValue.toFixed(4);
          data.push({
            date,
            type,
            coin_name,
            coin_symbol,
            status,
            tx_wallet_address,
            tx_id,
            amount,
            totalValue,
          });
        });

        opts = {
          fields: [
            { label: `${language[lang].DATE}`, value: "date" },
            { label: `${language[lang].TRANSACTION_TYPE}`, value: "type" },

            { label: `${language[lang].ASSET_NAME}`, value: "coin_name" },
            { label: `${language[lang].ASSET_SYMBOL}`, value: "coin_symbol" },

            {
              label: `${language[lang].WALLET_ADDRESS}`,
              value: "tx_wallet_address",
            },
            { label: `${language[lang].TRANSACTION_HASH}`, value: "tx_id" },
            { label: `${language[lang].STATUS}`, value: "status" },
            // { label: `${language[lang].PRICE}`, value: "price" },
            { label: `${language[lang].CRYPTO_AMOUNT}`, value: "amount" },
            { label: `${language[lang].USD_AMOUNT}`, value: "totalValue" },
          ],
        };
      } else {
        console.log("finalData::", finalData);
        finalData.map((obj: any) => {
          console.log("obj::", obj);
          obj.date = formatDateWithAmPm(obj.updated_at);
          let {
            date,
            from_adrs,
            to_adrs,
            amount,
            tx_id,
            blockchain_status,
            type,
          }: any = obj;

          blockchain_status = MakeFirstLettarCapital(blockchain_status);
          // adding tofixed
          amount = amount.toFixed(4);
          data.push({
            date,
            from_adrs,
            to_adrs,
            amount,
            tx_id,
            type,
            blockchain_status,
          });
        });

        opts = {
          fields: [
            { label: `${language[lang].DATE}`, value: "date" },
            {
              label: `${language[lang].FROM_ADRS}`,
              value: "from_adrs",
            },
            {
              label: `${language[lang].TO_ADRS}`,
              value: "to_adrs",
            },
            { label: `${language[lang].TRANSACTION_HASH}`, value: "tx_id" },
            { label: `${language[lang].AMOUNT}`, value: "amount" },
            { label: `${language[lang].TYPE}`, value: "type" },

            { label: `${language[lang].STATUS}`, value: "blockchain_status" },
          ],
        };
      }

      //

      const parser = new Parser(opts);
      const csvData = parser.parse(data);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=transaction_history.csv"
      );
      res.status(GlblCode.SUCCESS).end(csvData);
    } catch (err: any) {
      console.error("Error in wallet > download_csv.", err);
      await commonHelper.save_error_logs("download_csv", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }

  // public async exportCsv(req: Request, res: Response) {
  //   let lang: any = req.headers["content-language"] || "en";
  //   try {
  //     let limit: number = Number(
  //       req.query.limit == undefined
  //         ? (req.query.limit = "10")
  //         : req.query.limit
  //     );

  //     let search = req.query?.search ? req.query.search : "";

  //     let orderByfilter: any = req.query.filter == "ascending" ? "ASC" : "DESC";

  //     let page: number = Number(
  //       req.query.page == undefined ? (req.query.page = "1") : req.query.page
  //     );
  //     let offset: number = (page - GlblBooleanEnum.true) * limit;

  //     let query: any;
  //     search = search?.toString();
  //     if (search && search != "") {
  //       query = `
  //       SELECT
  //         w.wallet_address AS address,
  //         w.coin_family,
  //         w.wallet_name,
  //         w.user_id,
  //         w.created_at,
  //         w.updated_at,
  //         ROUND(SUM(w.balance * cf.value), 4) AS total_user_balance,
  //         c.coin_name
  //       FROM wallets w
  //       INNER JOIN coins c ON c.coin_id = w.coin_id
  //       INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd'
  //       WHERE (w.is_deleted is null or w.is_deleted=0)
  //       and ( w.wallet_name like "${search}"
  //       OR w.wallet_address like "${search}")
  //       GROUP BY user_id order by w.created_at ${orderByfilter} limit ${limit} offset ${offset}
  //     `;
  //     } else {
  //       query = `
  //         SELECT
  //           w.wallet_address AS address,
  //           w.coin_family,
  //           w.wallet_name,
  //           w.user_id,
  //           w.created_at,
  //           w.updated_at,
  //           ROUND(SUM(w.balance * cf.value), 4) AS total_user_balance,
  //           c.coin_name
  //         FROM wallets w
  //         INNER JOIN coins c ON c.coin_id = w.coin_id
  //         INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd'
  //         WHERE w.is_deleted is null or w.is_deleted=0
  //         GROUP BY user_id order by w.created_at ${orderByfilter} limit ${limit} offset ${offset}
  //       `;
  //     }

  //     const [results] = await db.db_read.query(query);

  //     let data: any = [];
  //     results.map((obj: any) => {
  //       obj.coin_image = obj.coin?.coin_image;
  //       obj.coin_name = obj.coin?.coin_name;
  //       obj.date = formatDate(obj.created_at);

  //       const { address, wallet_name, total_user_balance, date }: any = obj;

  //       data.push({
  //         date,
  //         address,
  //         wallet_name,
  //         total_user_balance,
  //       });
  //     });

  //     const opts = {
  //       fields: [
  //         { label: `${language[lang].DATE}`, value: "date" },

  //         {
  //           label: `${language[lang].WALLET_ADDRESS}`,
  //           value: "address",
  //         },
  //         { label: `${language[lang].WALLET_NAME}`, value: "wallet_name" },
  //         // { label: `${language[lang].COIN_NAME}`, value: "coin_name" },
  //         // { label: `${language[lang].COIN_IMAGE}`, value: "coin_image" },

  //         { label: `${language[lang].BALANCE}`, value: "total_user_balance" },
  //         // { label: `${language[lang].USD_AMOUNT}`, value: "value" },
  //         // { label: `${language[lang].DATE}`, value: "created_at" },
  //       ],
  //     };

  //     const parser = new Parser(opts);
  //     const csvData = parser.parse(data);
  //     res.setHeader("Content-Type", "text/csv");
  //     res.setHeader(
  //       "Content-Disposition",
  //       "attachment; filename=transaction_history.csv"
  //     );
  //     res.status(GlblCode.SUCCESS).end(csvData);
  //   } catch (err: any) {
  //     console.log("error", err);
  //     response.error(res, {
  //       data: { status: false, message: language[lang].CATCH_MSG },
  //     });
  //   }
  // }

  public async users_wallets(req: any, res: any) {
    let lang = req.headers["content-language"] || "en";
    try {
      let limit = Number(req.body.limit) || 10;
      let search = req.body.search || "";
 
      let orderCheckDefault:any=false;
      if(req.body.filter?.toLowerCase()=='all')
         orderCheckDefault =true;

      let orderByfilter =
        req.body.filter?.toLowerCase() === "ascending" ? "ASC" : "DESC";
      let page = Number(req.body.page) || 1;
      let offset = (page - 1) * limit;

      console.log("page::", page);
      console.log("offset::", offset);

      let totalCountQuery: any;
      if (search && search !== "") {
        totalCountQuery = {
          where: {
            coin_family: 2,
            [Op.or]: [
              { wallet_name: { [Op.like]: `%${search}%` } },
              { wallet_address: { [Op.like]: `%${search}%` } },
            ],
            is_deleted: { [Op.or]: [null, 0] },
          },
          attributes: [
            "updated_at",
            [
              Sequelize.fn("COUNT", Sequelize.literal("DISTINCT user_id")),
              "userCount",
            ],
          ],
        };
      } else {
        totalCountQuery = {
          where: {
            coin_family: 2,
            is_deleted: { [Op.or]: [null, 0] },
          },
          attributes: [
            "updated_at",
            [
              Sequelize.fn("COUNT", Sequelize.literal("DISTINCT user_id")),
              "userCount",
            ],
          ],
        };
      }

      let totalCount: any = await Models.WalletModel.findAll(totalCountQuery);
      totalCount = totalCount[0]?.dataValues;

      let query: any = {
        where: {
          is_deleted: { [Op.or]: [null, 0] },
        },
        include: [
          {
            model: Models.CoinsModel,
            attributes: ["coin_name"],
            include: {
              model: Models.CoinPriceInFiatModel,
              attributes: ["value"],
              as: "fiat_price_data",
              where: { fiat_type: "usd" },
              required: true,
            },
          },
        ],
        attributes: [
          [
            Sequelize.literal(
              "(SELECT wallet_address FROM wallets AS w2 WHERE w2.user_id = wallets.user_id AND w2.coin_family = 2 LIMIT 1)"
            ),
            "address",
          ],
          [
            Sequelize.literal(
              "(SELECT coin_family FROM wallets AS w2 WHERE w2.user_id = wallets.user_id AND w2.coin_family = 2 LIMIT 1)"
            ),
            "coin_family",
          ],
          "wallet_name",
          "user_id",
          "created_at",
          "updated_at",
          [
            Sequelize.literal(
              "(SELECT Round(SUM(w2.balance * cf.value),4) FROM wallets w2 INNER JOIN coins c ON w2.coin_id = c.coin_id INNER JOIN coin_price_in_fiats cf ON cf.cmc_id = c.cmc_id AND cf.fiat_type = 'usd' WHERE w2.user_id = wallets.user_id LIMIT 1)"
            ),
            "total_user_balance",
          ],
        ],
        group: ["user_id"],
        order: orderCheckDefault
          ? [["created_at", orderByfilter]]
          : [["total_user_balance", orderByfilter]],
        limit: limit,
        offset: offset,
        logging: true,
      };

      if (search && search !== "") {
        query.where[Op.or] = [
          { wallet_name: { [Op.like]: `%${search}%` } },
          { wallet_address: { [Op.like]: `%${search}%` } },
        ];
      }

      const results = await Models.WalletModel.findAll(query);

      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: results,
          meta: {
            page: page,
            pages: Math.ceil(totalCount?.userCount / limit),
            perPage: limit,
            total: totalCount?.userCount,
          },
        },
      });
    } catch (err) {
      console.log("error", err);
      response.error(res, {
        data: { status: false, message: language[lang].CATCH_MSG },
      });
    }
  }
}

export const userController = new UserController();
