import express from "express";
import { validate as validateExpress } from "express-validation";
import { ControllerInterface } from "../../interfaces/controller.interface";
import { userController } from "./controller";

import user_validator from "./validator";
import jwtVerification from "../../middlewares/verify.middleware";
import adminMiddleware from "../middleware";

class UserRoute implements ControllerInterface {
    public path = "/admin/users";
    public router = express.Router();

    constructor() {
        //this.router.use(adminMiddleware.checkLogin);
        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router.get(
            `${this.path}/count`,
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.userCount
        ).post(
            `${this.path}/list`,
            [validateExpress(user_validator.userList_validate)],
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.users_wallets
        ).post(
            `${this.path}/sendReceiveTransactions`,
            [validateExpress(user_validator.transaction)],
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.send_receive_transaction
        ).post(
            `${this.path}/rewardHistory`,
            [validateExpress(user_validator.referralValidate)],
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.referralUserSpecific
        ).post(
            `${this.path}/swapTransaction`,
            [validateExpress(user_validator.swap_transaction)],
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.swap_transaction
        ).get(
            `${this.path}/userBalance/:userId`,
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.userbalance
        ).get(
            `${this.path}/exportCsv`,
            userController.exportCsv
        ).get(
            `${this.path}/download`,
            userController.downloadCsv
        ).put(
            `${this.path}/delete/:user_id`,
            adminMiddleware.checkLogin,
            jwtVerification.verifyToken,
            userController.deleteUser
        ).put(
            `${this.path}/deleteMultipleUser`,
            adminMiddleware.checkLogin,
            [validateExpress(user_validator.userDeleteMultiple)],
            jwtVerification.verifyToken,
            userController.deleteMultipleUser
        )
    }
}
export default UserRoute;
