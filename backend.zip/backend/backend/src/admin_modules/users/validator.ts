import { Joi } from "express-validation";

export default class user_validator {
  static userList_validate = {
    body: Joi.object({
      limit: Joi.number().optional(),
      page: Joi.number().optional(),
      search: Joi.string().allow(null, "").optional(),
      filter:Joi.string().allow(null, "").optional()
    }),
  };

  static swap_transaction = {
    body: Joi.object({
      fiat_currency: Joi.string().allow(null, "").optional(),
     // wallet_address: Joi.string().required(),
      filter_type:Joi.string().allow(null, "").optional(),
      address_list:Joi.array().required(),
      status: Joi.string().allow(null, "").optional(),
      limit:Joi.number().allow(null, "").optional(),
      page:Joi.number().allow(null, "").optional()


    }),
  };

  static transaction = {
    body: Joi.object({
     // fiat_currency: Joi.string().allow(null, "").optional(),
     // wallet_address: Joi.string().required(),
      filter_type:Joi.string().allow(null, "").optional(),
      status:Joi.string().allow(null, "").optional(),
      address_list:Joi.array().required(),
      limit:Joi.number().allow(null, "").optional(),
      page:Joi.number().allow(null, "").optional()
    }),
  };

  static referralValidate = {
    body: Joi.object({
      wallet_address: Joi.string().required(),
    }),
  };

  static swap_coins = {
    body: Joi.object({
      coin_symbols: Joi.array().required(),
    }),
  };

  static userDeleteMultiple = {
    body: Joi.object({
      user_ids: Joi.array().required(),
    }),
  };

  static referralListValidate = {
    body: Joi.object({
      search: Joi.string().allow(null, "").optional(),
    }),
  };
}
