import AdminRoute from "./auth/routes";
import UserRoute from "./users/routes";
import TransactionRoute from "./transactions/routes";
import dashboardRoute from "./dashboard/routes";
import TokenRoute from "./token_management/router";
import RewardRoute from "./reward_setting/routes";

const admin_controllers = [new AdminRoute(), new UserRoute(), new TransactionRoute(),new dashboardRoute(),new TokenRoute(),new RewardRoute()];

export default admin_controllers;
