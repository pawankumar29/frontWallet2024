import { Request, Response } from "express";
import { OnlyControllerInterface } from "../../interfaces/controller.interface";
import * as Models from "../../models/model/index";
import { GlblMessages } from "./../../constants/global_enum";
import { language } from "./../../constants";
import { Op, Sequelize } from "sequelize";
import response from "../../helpers/response/response.helpers";
import commonHelper from "../../helpers/common/common.helpers";
import redisClient from "../../helpers/common/redis";
import { config } from "../../config";

const IP = require("ip");

class dashboardController implements OnlyControllerInterface {
  constructor() {
    this.initialize();
  }
  public initialize() { }
  public async swap_coins(req: Request, res: Response) {
    let lang: any = req.headers["content-language"] || "en";
    try {
      const limit = 10;
      const perpage = req.body.page ? req.body.page : 1;
      const offset = (perpage - 1) * limit;

      //   console.log("symbols::",req.body.coin_symbols);
      let query: any = {
        attributes: ["coin_id", "coin_symbol", "coin_name", "coin_image"],
        where: {},

        include: [
          {
            model: Models.CoinPriceInFiatModel,
            attributes: ["latest_price"],
            as: "fiat_price_data",
          },
        ],
        limit,
        offset,
      };
      let coin_data: any = await Models.CoinsModel.findAll(query);
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: coin_data,
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > swap_coins.", err);
      await commonHelper.save_error_logs("swap_coins", err.message);
      response.error(res, {
        data: {
          status: false,
          message: language[lang].CATCH_MSG,
        },
      });
    }
  }
  public async transaction_graph(req: Request, res: Response) {
    let lang: string = req.headers["content-language"] || "en";
    try {
      let from_date_year=new Date(2023, 0, 1);
      const currentDate1: any = new Date();
        const currentYear1: any = currentDate1.getFullYear();
      let to_date_year=new Date(currentYear1, 11,31 );
      let yearData:any=[]; let flag=0;
      const timeLine = req.query.timeLine;
      //previousDate.setDate(currentDate.getDate() - 1);
      // console.log('Current Date:', currentDate.toISOString().split('T')[0]);
      // console.log('Previous Date:', previousDate.toISOString().split('T')[0]);
      if (!timeLine) {
        throw new Error("TimeLine is not Provided");
      }
      const currentDate = new Date();
      let to_date = currentDate.toISOString().split('T')[0];
      to_date = `${to_date} 00:00:00`;

      let from_date: string = '';
      let attributes: any = Array();
      let group: string = '';
      if (timeLine == "1d") {
        const oneDayAgo = new Date(currentDate);
        oneDayAgo.setDate(currentDate.getDate() - 1);
        from_date = oneDayAgo.toISOString().split('T')[0];
        from_date = `${from_date} 00:00:00`;
        attributes = [
          [Sequelize.fn("HOUR", Sequelize.col("created_at")), "Date"],
          [Sequelize.fn("SUM", Sequelize.col("amount")), "total_amount"],
          "amount"
        ];
        group = `DATE(created_at)`;
        // const from_year = oneDayAgo.getFullYear();
        // const from_month = String(oneDayAgo.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
        // const from_day = String(oneDayAgo.getDate()).padStart(2, '0');

        // const from_date = `${from_year}-${from_month}-${from_day} 00:00:00`;
      } else if (timeLine == "1w") {
        // Calculate date 1 week ago
        const oneWeekAgo = new Date(currentDate);
        oneWeekAgo.setDate(currentDate.getDate() - 7);
        from_date = oneWeekAgo.toISOString().split('T')[0];
        from_date = `${from_date} 00:00:00`;
        attributes = [
          [Sequelize.literal(`DATE_FORMAT(created_at,'%a')`), "Date"],
          [Sequelize.fn("SUM", Sequelize.col("amount")), "total_amount"],
          "created_at"
        ];
        group = `DATE(created_at)`;
      } else if (timeLine == "1m") {
        // Calculate date 1 month ago
        const oneMonthAgo = new Date(currentDate);
        oneMonthAgo.setMonth(currentDate.getMonth() - 1);
        from_date = oneMonthAgo.toISOString().split('T')[0];
        from_date = `${from_date} 00:00:00`;

        attributes = [
          [Sequelize.fn("DAY", Sequelize.col("created_at")), "Date"],
          [Sequelize.fn("SUM", Sequelize.col("amount")), "total_amount"],
          "amount"
        ];
        group = `DATE(created_at)`;
      }
      else if (timeLine == "1y") {
        flag = 1;

        const currentDate: any = new Date();
        const currentYear: any = currentDate.getFullYear();

        let yearDiff = parseInt(currentYear) - 2023;


        for (let i = 0; i <= yearDiff; i++) {
          let year = 2023+ i;
          const from_date = new Date(year, 0, 1);
          from_date.setHours(0, 0, 0, 0);
          const to_date = new Date(year, 11, 31); // December is 11 (zero-indexed)
          to_date.setHours(23, 59, 59, 999);

          let whereClause = {
            created_at: {
              [Op.gte]: from_date,
              [Op.lte]: to_date,
            },
          };
          const attributes = [[Sequelize.fn("SUM", Sequelize.col("amount")), "total_amount"]];
        

          const query: any = {
            attributes: attributes,
            where: whereClause,
            logging: true,
          };
           const data: any = await Models.TrnxHistoryModel.findAll(query);
       



          let result = {
           
            from_date: from_date,
            to_date: to_date,
            total_amount: data[0]?.dataValues?.total_amount?data[0]?.dataValues?.total_amount.toFixed(4):0,
                year:year
          };

          yearData.push(result);
          console.log("year::",result)
        }
      }

      
      console.log('from_date >>>', from_date);
      console.log('to_date >>>', to_date);
      let whereClause = {
        created_at: {
          [Op.gte]: from_date,
         // [Op.lt]: to_date,
        }
      };
      //'SELECT HOUR(created_at) AS Hour, SUM(amount) AS total_amount FROM trnx_histories WHERE created_at >= '2024-05-15 00:00:00' AND created_at < '2024-05-16 00:00:00' GROUP BY HOUR(created_at) ORDER BY Hour'
      const query: any = {
        attributes: attributes,
        where: whereClause,
        group: Sequelize.literal(group),
        order: [["created_at", "ASC"]],
      };
        
      let data;
      if(!flag)
       data= await Models.TrnxHistoryModel.findAll(query);
      // let res_data: any = {labels:[],amount:[]};
      // if (timeLine == "1d") {
      //   let array_res_data = Array.from({ length: 24 }, (_, i) => ({ hour: i, total_amount: 0 }));
      //   // Fill hoursData with the results from the query
      //   let labels: number[] = new Array();
      //   let values:number[] = new Array();
      //   data.map((row: any) => {
      //     if(row.Date==array_res_data[row.Date].hour){
      //       labels.push(array_res_data[row.Date].hour);
      //       values.push(array_res_data[row.Date].total_amount);
      //     }else{
      //       labels.push(row.Date);;
      //       values.push(0);;
      //     }
      //   });
      //   let res_data: any = {labels:labels,amount:values};

      // } else if (timeLine == "1w") {
      // const startDate = new Date(from_date);
      // const res_data = Array.from({ length: 7 }, (_, i) => {
      //   const date = new Date(startDate);
      //   date.setDate(startDate.getDate() + i);
      //   return { date: date.toISOString().split('T')[0], total_amount: 0 };
      // });
      // // Fill daysData with the results from the query
      // data.forEach((row: any) => {
      //   const index = res_data.findIndex(day => day.date === row.Date);
      //   if (index !== -1) {
      //     res_data[index].total_amount = row.total_amount;
      //   }
      // });
      // } else if (timeLine == "1w") {
      //   const startDate: any = new Date(from_date);
      //   const endDate: any = new Date(to_date);
      //   const daysInMonth = (endDate - startDate) / (1000 * 60 * 60 * 24);

      //   // Initialize daysData with zeros for all days of the month
      //   const res_data = Array.from({ length: daysInMonth }, (_, i) => {
      //     const date = new Date(startDate);
      //     date.setDate(startDate.getDate() + i);
      //     return { date: date.toISOString().split('T')[0], total_amount: 0 };
      //   });

      //   // Fill daysData with the results from the query
      //   data.forEach((row: any) => {
      //     const index = res_data.findIndex(day => day.date === row.Date);
      //     if (index !== -1) {
      //       res_data[index].total_amount = row.total_amount;
      //     }
      //   });
      // }
      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          data: !flag
            ? { data: data, from_date: from_date, to_date: to_date }
            :  {data:yearData ,from_date:from_date_year,to_date:to_date_year}
        },
      });


    } catch (err: any) {
      console.error("Error in wallet > transaction_graph:", err);
      await commonHelper.save_error_logs("transaction_graph", err.message);

      return res.status(500).json({
        status: false,
        message: err.message || language[lang].CATCH_MSG,
      });
    }
  }
  public async news_latest(req: Request, res: Response) {
    let lang: string = req.headers["content-language"] || "en";

    try {
      let news: any;

      let coin_symbol:any = req.query.symbol;
       let id:any;
      if(coin_symbol?.toUpperCase()==="ETH"){
          id='1027'
      }
      else if(coin_symbol?.toUpperCase()==="USDT"){
          id='825'
      }
      else if(coin_symbol?.toUpperCase()==="BNB"){
           id='1839'
      }
      else{
          id='1'
      }
      
      let query:any={
         where:{
          cmc_id:id
         },
         order: [["updated_at", "DESC"]],
         group:["post_id"],
         limit:3
      }

      const newsResult:any=await Models.CmcPostModel.findAll(query);
//console.log("news_result::",newsResult);

let list:any=[];
for(let i=0;i<3;i++){
    let obj={
      owner:{
        nickname:newsResult[i].dataValues.nickname
      },
  post_id: newsResult[i].dataValues.post_id,
  text_content: newsResult[i].dataValues.text_content,
    post_time: newsResult[i].dataValues.post_time,
    comment_url:newsResult[i].dataValues.comment_url
    }

    list.push(obj);


}
      const newsResponse={
        data:{
          list:list
        }
      }


      return response.success(res, {
        data: {
          success: true,
          message: GlblMessages.SUCCESS,
          news:newsResponse
        },
      });
    } catch (err: any) {
      console.error("Error in wallet > news_latest:", err);
      await commonHelper.save_error_logs("news_latest", err.message);

      return res.status(500).json({
        status: false,
        message: err.message || language[lang].CATCH_MSG,
      });
    }
  }
}

export const dashboard_Controller = new dashboardController();
