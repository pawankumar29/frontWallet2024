import express from "express";
import { validate as validateExpress } from "express-validation";
import { ControllerInterface } from "../../interfaces/controller.interface";
import { dashboard_Controller } from "./controller";

import dashboard_validator from "./validator";
import jwtVerification from "../../middlewares/verify.middleware";
import adminMiddleware from "../middleware";

class dashboardRoute implements ControllerInterface {
    public path = "/admin/dashboard";
    public router = express.Router();

    constructor() {
      this.router.use(adminMiddleware.checkLogin);

        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router.post(
            `${this.path}/swap_coins`,
            [validateExpress(dashboard_validator.swap_coins)],
            jwtVerification.verifyToken,
            dashboard_Controller.swap_coins
          ).get(
            `${this.path}/transaction_graph`,
            jwtVerification.verifyToken,
            dashboard_Controller.transaction_graph
          ).get(
            `${this.path}/latest_news`,
           jwtVerification.verifyToken,
            dashboard_Controller.news_latest
          )
    }
    
}
export default dashboardRoute;
