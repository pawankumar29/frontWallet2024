import { Joi } from "express-validation";

export default class user_validator {
    static swap_coins = {
        body: Joi.object({
            limit: Joi.number().optional(),
            page: Joi.number().optional(),
            search: Joi.string().allow(null, "").optional(),
           // coin_symbols:Joi.array().required()
        }),
    };
}
