import { Request, Response, NextFunction } from "express";
import jwtHelper from "../helpers/common/jwt";
import jwt from "jsonwebtoken";
let CryptoJS = require("crypto-js");

import { config } from "../config";
import commonHelper from "../helpers/common/common.helpers";
import { GlblCode, GlblMessages, Status } from "./../constants/global_enum";
import dbHelper from "../helpers/dbHelper";
import redisClient from "../helpers/common/redis";

class AdminMiddleware {
  //   public async checkLogin(req: Request, res: Response, next: NextFunction) {
  //     try {
  //       let data: any;
  //       const encryptedJWT: any = req.headers["authorization"];
  //       let Jwt: any = CryptoJS.AES.decrypt(encryptedJWT, config.ENCRYPT_SECRET);
  //       let bearerHeader: any = Jwt.toString(CryptoJS.enc.Utf8);
  //       console.log("bearer::",bearerHeader);
  //       if (typeof bearerHeader !== "undefined") {
  //         const bearerToken: string = bearerHeader.split(" ")[1];
  //         console.log("encryptedJWT>>", encryptedJWT);
  //         if (jwtHelper.verify(bearerToken)) {
  //           const decodedData: any = jwtHelper.decodeToken(bearerToken);
  //           req.adminId = parseInt(decodedData);
  //           if (decodedData && req.adminId) {
  //             let adminData: any =
  //               await dbHelper.find_one_admin_with_admin_access(
  //                 [
  //                   "id",
  //                   "username",
  //                   "email",
  //                   "role",
  //                   "password",
  //                   "mobile_no",
  //                   "google2fa_secret",
  //                   "google2fa_status",
  //                   "login_status",
  //                   "jwt_token",
  //                   "created_at",
  //                   "updated_at",
  //                 ],
  //                 { id: req.adminId, active: 1 }
  //               );

  //               console.log("adminToken::",adminData?.jwt_token);
  //               console.log("bearerToken::",bearerToken);

  //             console.log("to uppercae>>>", adminData.email.toUpperCase());
  //             if (adminData) {
  //               if (adminData?.jwt_token!== bearerToken) {
  //                 data = {
  //                   message: GlblMessages.INVALID_TOKEN,
  //                   status: Status.FALSE,
  //                   code: GlblCode.INVALID_TOKEN,
  //                   data: ["123"],
  //                 };
  //                 return res.status(data.code).send(data);
  //               } else {
  //                 req.adminDetails = adminData;
  //                // req.body.user_email = adminData.email;
  //               }
  //             } else {
  //               data = {
  //                 message: GlblMessages.UNABLE_DECODE,
  //                 status: Status.FALSE,
  //                 code: GlblCode.ERROR_CODE,
  //                 data: [],
  //               };
  //               return res.status(data.code).send(data);
  //             }
  //           } else {
  //             data = {
  //               message: GlblMessages.UNABLE_DECODE,
  //               status: Status.FALSE,
  //               code: GlblCode.ERROR_CODE,
  //               data: [],
  //             };
  //             return res.status(data.code).send(data);
  //           }
  //         } else {
  //           data = {
  //             message: GlblMessages.INVALID_TOKEN,
  //             status: Status.FALSE,
  //             code: GlblCode.INVALID_TOKEN,
  //             data: [],
  //           };
  //           return res.status(data.code).send(data);
  //         }
  //         next();
  //       } else {
  //         data = {
  //           message: GlblMessages.TOKEN_NOT_FOUND,
  //           status: Status.FALSE,
  //           code: GlblCode.ERROR_CODE,
  //           data: [],
  //         };
  //         return res.status(data.code).send(data);
  //       }
  //     } catch (err: any) {
  //       console.error("Error in checkLogin of admin", err);
  //       let data: any = {
  //         message: GlblMessages.INVALID_TOKEN,
  //         status: Status.FALSE,
  //         code: GlblCode.INVALID_TOKEN,
  //         data: {},
  //       };
  //       return res.status(data.code).send(data);
  //     }
  //   }

  public async checkLogin(req: Request, res: Response, next: NextFunction) {
    try {
      let data: any;
      const encryptedJWT: any = req.headers["authorization"];
      let Jwt: any = CryptoJS.AES.decrypt(encryptedJWT, config.ENCRYPT_SECRET);
      let bearerHeader: any = Jwt.toString(CryptoJS.enc.Utf8);
      console.log("bearer::", bearerHeader);
      if (typeof bearerHeader !== "undefined") {
        const bearerToken: string = bearerHeader.split(" ")[1];
        console.log("encryptedJWT>>", encryptedJWT);
        if (jwtHelper.verify(bearerToken)) {
          const decodedData: any = jwtHelper.decodeToken(bearerToken);
          console.log("decoded::", decodedData);
          req.adminId = parseInt(decodedData.userId);

          if (decodedData && req.adminId) {
            let adminData: any =
              await dbHelper.find_one_admin_with_admin_access(
                [
                  "id",
                  "username",
                  "email",
                  "role",
                  "password",
                  "mobile_no",
                  "google2fa_secret",
                  "google2fa_status",
                  "login_status",
                  "jwt_token",
                  "created_at",
                  "updated_at",
                ],
                { id: req.adminId, active: 1 }
              );

            console.log("adminToken::", adminData?.jwt_token);
            console.log("bearerToken::", bearerToken);

            console.log("to uppercae>>>", adminData.email.toUpperCase());
            if (adminData) {
              if (adminData?.jwt_token !== encryptedJWT) {
                data = {
                  message: GlblMessages.INVALID_TOKEN,
                  status: Status.FALSE,
                  code: GlblCode.INVALID_TOKEN,
                  data: [],
                };
                 return res.status(data.code).send(data);
              } else {
                req.adminDetails = adminData;
                // req.body.user_email = adminData.email;
              }
            } else {
              data = {
                message: GlblMessages.UNABLE_DECODE,
                status: Status.FALSE,
                code: GlblCode.ERROR_CODE,
                data: [],
              };
              return res.status(data.code).send(data);
            }
          } else {
            data = {
              message: GlblMessages.UNABLE_DECODE,
              status: Status.FALSE,
              code: GlblCode.ERROR_CODE,
              data: [],
            };
            return res.status(data.code).send(data);
          }
        } else {
          data = {
            message: GlblMessages.INVALID_TOKEN,
            status: Status.FALSE,
            code: GlblCode.INVALID_TOKEN,
            data: [],
          };
          return res.status(data.code).send(data);
        }
        next();
      } else {
        data = {
          message: GlblMessages.TOKEN_NOT_FOUND,
          status: Status.FALSE,
          code: GlblCode.ERROR_CODE,
          data: [],
        };
        return res.status(data.code).send(data);
      }
    } catch (err: any) {
      console.error("Error in checkLogin of admin", err);
      let data: any = {
        message: GlblMessages.INVALID_TOKEN,
        status: Status.FALSE,
        code: GlblCode.INVALID_TOKEN,
        data: {},
      };
      return res.status(data.code).send(data);
    }
  }
  public async generate_token(user_id: number) {
    try {
      const token: any = jwt.sign({ user_id: user_id }, config.JWT_SECRET, {
        expiresIn: "30d",
      });
      const set_token: string = `JWT ${token}`;
      const encrypt_token: any = await commonHelper.adminEncryptDataRSA(
        set_token
      );
      return encrypt_token;
    } catch (err: any) {
      console.error("Error in generate_token.", err);
      throw err;
    }
  }
}

const adminMiddleware = new AdminMiddleware();
export default adminMiddleware;
