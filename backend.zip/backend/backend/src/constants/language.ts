export const language: any = {
  en: {
    NODE_ISSUE:"Node is Not working Properly",
    SNO:"S.No",
    TOKEN_UPDATED:"Token Updated Successfully",
    ASSET_SYMBOL:"Asset Symbol",
    ASSET_NAME:"Asset Name",
    EDIT_SUCCESSFULLY:"Edit Successfully",
    MULTICHAIN_PORTFOLIO:"Multichain Portfolio",
    COUNT_ID: "id",
    TITLE: "Title",
    MESSAGE: "Message",
    SENT_USERS: "Sent users",
    TRANSACTION_TYPE: "Transaction Type",
    TRANSACTION_HASH: "Transaction Hash",
    CHAIN: "Chain",
    TOKEN: "Token",
    TOTAL_VALUE: "Total Value",
    PRICE: "price",
    MAINTENANCE_MODE: "App is Under Maintenance",
    // Wallets
    WALLET_ADDRESS: "Wallet Address",
    WALLET_NAME: "Wallet_Name",
    COIN_IMAGE: "Coin_Image",
    BALANCE: "Balance",
    CRYPTO_AMOUNT: "Crypto Amount",
    USD_AMOUNT: "USD Amount",
    HASH: "Hash",
    Type: "Type",
    Date: "Date",
    // fields to add
    COIN_NAME: "coin_name",
    INVALID_ADDRESS: "The wallet address provided is invalid.",
    CATCH_MSG: "Something went wrong. Please try again later.",
    INVALID_TOKEN: "Invalid Token, please try again.",
    TOKENS_SEARCH: "Token information fetched successfully.",
    TOKENS_NOT_FOUND: "Token not found.",
    TOKEN_EXIST: "Token Already Exist.",
    TOKEN_ADDED: "Token added successfully.",
    COIN_NOT_FOUND: "Coin not found.",
    TOKEN_WALLET_ACTIVE: "Token Active successfully.",
    TOKEN_WALLET_INACTIVE: "Token Inactive successfully.",
    SWAP_LIST: "Get Swap list successfully.",
    UPDATED: "Updated Successfully.",
    REQUEST_EXECUTED: "Your request is executed successfully.",
    SUCCESS: "SUCCESS",
    NO_ADDRESS_FOUND: "No address found for this user.",
    DATA_NOT_FOUND: "Data not found.",
    DATA_FETCHED: "Data fetched successfully.",
    VALUE_FETCHED: "Value fetched successfully.",
    ERROR_FETCHING_DATA: "There was an error fetching your data.",
    MIN_BALANCE: (
      balance: any,
      currency: string,
      coin_symbol: string,
      coin: string,
      token_type: string
    ) =>
      `In order to send ${coin_symbol.toUpperCase()} (${token_type.toUpperCase()}), you need to fund ${coin.toUpperCase()} for the gas fee (Minimum ${balance} ${currency})`,
    // Alchemy
    FAILED: "FAILED",
    // BTC
    INSUFFICIENT: "Insufficient balance",
    TRANSACTION_BROADCAST_SUCCESSFULLY:
      "Transaction broadcasted to blockchain successfully",
    TRANSACTION_BROADCAST_FAILED: "Transaction processed.",
    INVALID_COIN_SYMBOL: "Invalid coin symbol request.",
    //ETH
    GET_NONCE: "wallet nonce",
    INSUFFICIENTETH: "Insufficient ETH balance",
    INSUFFICIENTBNB: "Insufficient BNB balance",
    ETH_INSUFFICIENT: (coin_symbol: string) =>
      `Insufficient ${coin_symbol.toUpperCase()} balance.`,
    ETH_GAS: (gasInEthForErc: any) =>
      `You need ${gasInEthForErc} ETH balance for this withdraw request.`,
    APPROVE_REQUEST:
      "Approval request has been processed successfully, Waiting for blockchain confirmation.",
    WITHDRAW_REQUEST_ETH: (amount: any, coin_symbol: string) =>
      `Withdraw request of ${amount} ${coin_symbol.toUpperCase()} has been processed successfully, Waiting for blockchain confirmation.`,
    SWAP_REQUEST_ETH: (amount: any, coin_symbol: string) =>
      `Swap request of ${amount} ${coin_symbol.toUpperCase()} has been processed successfully, Waiting for blockchain confirmation.`,
    TRANSACTION_REQUEST: "Transaction processed.",
    PENDING: "pending",
    ESTIMATE_ETH_TRANSFER_GAS_FEE: "Estimate ETH transfer gas fee.",
    TRNX_NOT_FOUND: "Tx not found.",
    //On-off-Ramp
    INITIATE_TXN_CREATED: "Transaction created successfully.",
    //TRON
    ERC20_TOKEN_SEARCH: "Unable to fetch ERC20 token. Please contact support",
    BSC_TOKEN_SEARCH: "Unable to fetch BSC token. Please contact support",
    TRON_TOKEN_SEARCH: "Unable to fetch TRC20 token. Please contact support",
    SAME_ADDRESS: "You cannot send to the same address!",
    INSUFFICIENTTRX: "Insufficient balance!",
    TRANSACTION_FEE_LOW: "Transaction fee is very low!",
    INSUFFICIENT_GAS_PRICE: "Insufficient balance for paying gas price!",
    //CARDS
    CARDS_MAINTENANCE_MODE:
      "New card applications are on hold due to maintenance from banking partners.This service will resume new week, deposits work as expected.",
    EMAIL_EXIST: "Email already exist.",
    SENT: "OTP Sent Successfully.",
    MOBILE_EXIST: "Mobile number already exist.",
    INVALID_NUMBER: "Please Enter Valid Mobile Number.",
    OTP_VERIFIED: "Otp verified successfully.",
    SESSION_TIMEOUT: "Session Timeout",
    INVALID_CODE: "Invalid code!",
    USED_OWN_REFERRAL_CODE: "Referral code can't be use on same account.",
    ADDED: "Added Successfully.",
    CARD_NOT_FOUND: "Card not found!",
    COIN_FETCH: "Coin fetched successfully",
    CARD_BIND: "Card Binding successfully!!! ",
    WALLET_NOT_ACTIVE: "Wallet not active",
    CARD_UN_BIND: "Card Un Binding successfully!!! ",
    VALIDATION_VAILED: "Validation failed!",
    INVALID_FILE_TYPE:
      "Invalid file type. Only JPEG, JPG and PNG files are allowed.",
    FILE_SIZE_EXCEED: "File size exceeds the limit of 2MB.",
    FILE_SIZE_EXCEED_MB: "File size exceeds the limit of 1MB.",
    INFORMATIION_IN_REVIEW: "Information in Review.",
    CARD_NOT_SUPPORT_RECHARGING: "Card does not support Recharge.",
    // Price_alerts, dapp, auth, swftc
    ALERT_EXISTS: "This Alert already exists.",
    ALERT_CREATED: "Alert created successfully",
    ALERT_FETCHED: "Alert fetched successfully.",
    ALERT_DELETED: "Alert deleted successfully.",
    UNABLE_DECODE: "Unable to decode token.",
    //Verify_token
    SESSION_EXPIRED: "Session expired",
    NO_TOKEN: "No Token detected",
    UNAUTHORIZED_ACCESS: "Unauthorized access. Please login to continue",
    //Validation
    VALIDATION_FAILED: "Validation Failed",
    //Users
    INVALID_REFERRAL_CODE: "Invalid Referral Code.",
    LOGOUT: "Logout successfully.",
    SAME_WALLET_ADDRESS_EXIST:
      "Address Book already saved with this wallet address.",
    SAME_WALLET_NAME_EXIST: "Address Book already saved with this wallet name,",
    MAX_LIMIT: "Maximum limit Reached.",
    ADDRESS_BOOK_SAVED: "Address Book saved successfully.",
    GET_ADDRESS_BOOK: "Address Book has been get successfully.",
    NO_WALLET_ADDRESS_EXIST: "Address Book wallet doesnt exist.",
    DELETED_ADDRESSBOOK_WALLET:
      "Address Book wallet has been deleted successfully.",
    NO_ADDRESSBOOK_EXIST: "Address Book doesnt exist.",
    ADDRESSBOOK_DELETED: "Address Book has been deleted successfully.",
    NO_ANNOUNEMENT: "No Announcement.",
    NO_FILE_SELECTED: "No file is selected.",
    FILE_UPLOADED: "File uploaded successfully.",
    WALLET_NONCE: "wallet nonce",
    //CSV
    WITHDRAW: "Withdraw",
    DEPOSIT: "Deposit",
    TYPE: "Type",
    FROM_ADRS: "From Address",
    TO_ADRS: "To Address",
    TX_ID: "Transaction Id",
    STATUS: "Status",
    BLOCKCHAIN_STATUS: "Blockchain Status",
    AMOUNT: "Amount",
    TRNX_FEE: "Transaction Fee",
    CREATED: "Created",
    CROSS_CHAIN: "Cross_chain",
    DAPP: "Dapp",
    SWAP: "Swap",
    APPROVE: "Approve",
    BUY: "Buy",
    CARD_FEES: "Card_fees",
    CARD_RECHARGE: "Card_recharge",
    COMPLETED: "Completed",
    FAILED_STATUS: "Failed",
    CONFIRMED: "Confirmed",
    PENDING_STATUS: "Pending",
    // CSV FOR CARD HISTORY
    COIN: "Coin",
    DESC: "Desc",
    AMOUNTT: "Amount",
    USER_ID: "User_id",
    EMAIL: "Email",
    DATE: "Date",
    LEVEL_UPGRADE: "Level Upgrade ",
    SIGNED_SUCCESSFULLY: "Signed Successfully.",
    BSC_UNABLE_TO_ESTIMATE:
      "Unable to estimate BEP20 token transfer gas fee. User dont have sufficient balance",
    REFERRED: "Same Referral Exist",
    REFERRED_ALREADY_USED: "Referral code already used",
    ADDRESS_BOOK_WITH_SAME_CONTACT_NAME_EXIST:
      "Address Book with same contact name already exists.",
    ADDRESS_BOOK_CONTACT_NAME_EDIT_SUCCESS: "Address Book edited successfully.",
    ADDRESS_BOOK_WITH_SAME_WALLET_NAME_EXIST:
      "Address Book with same wallet name already exists.",
    ADDRESS_BOOK_WITH_SAME_ADDRESS_EXIST:
      "Address Book with same address already exists.",
  },
  sp: {
    NODE_ISSUE:"El nodo no está funcionando correctamente",
    SNO:"N.º de Serie",
    TOKEN_UPDATED:"Token actualizado correctamente",
    ASSET_SYMBOL:"ASSET SÍMBOLO",
    ASSET_NAME:"NOMBRE DEL ACTIVO",
    EDIT_SUCCESSFULLY:"¡Edición exitosa!",
    MULTICHAIN_PORTFOLIO: "Cartera Multichain",
    COUNT_ID: "identificación",
    TITLE: "título",
    MESSAGE: "mensaje",
    SENT_USERS: "usuarios enviados",

    MAINTENANCE_MODE: "La aplicación se encuentra en mantenimiento",

    TRANSACTION_TYPE: "Tipo de Transacción",
    TRANSACTION_HASH: "Hash de la Transacción",
    CHAIN: "Cadena",
    TOKEN: "Token",
    PRICE: "Precio",
    TOTAL_VALUE: "Valor Total", //Wallets
    WALLET_ADDRESS: "Dirección_de_billetera",
    WALLET_NAME: "Nombre_de_billetera",
    COIN_IMAGE: "Imagen_de_moneda",
    BALANCE: "Saldo",

    CRYPTO_AMOUNT: "Cantidad de Cripto",
    USD_AMOUNT: "Monto en USD",
    HASH: "Hash",
    Type: "Tipo",
    Date: "Fecha",
    COIN_NAME: "Nombre de la Moneda",
    //newly added
    INVALID_ADDRESS: "La dirección de billetera proporcionada no es válida.",
    CATCH_MSG: "Algo salió mal. Por favor, inténtelo de nuevo más tarde.",
    INVALID_TOKEN: "Token no válido, inténtelo de nuevo.",
    TOKENS_SEARCH: "La información del token se obtuvo correctamente.",
    TOKENS_NOT_FOUND: "Token no encontrado.",
    TOKEN_EXIST: "El token ya existe.",
    TOKEN_ADDED: "Token agregado exitosamente.",
    COIN_NOT_FOUND: "Moneda no encontrada.",
    TOKEN_WALLET_ACTIVE: "Token activo exitosamente.",
    TOKEN_WALLET_INACTIVE: "Token inactivo exitosamente.",
    SWAP_LIST: "Obtener lista de Swap exitosamente.",
    UPDATED: "Actualizado con éxito.",
    REQUEST_EXECUTED: "Su solicitud se ejecutó exitosamente.",
    SUCCESS: "ÉXITO",
    NO_ADDRESS_FOUND: "No se encontró ninguna dirección para este usuario.",
    DATA_NOT_FOUND: "Datos no encontrados.",
    DATA_FETCHED: "Datos obtenidos exitosamente.",
    VALUE_FETCHED: "Valor obtenido exitosamente.",
    ERROR_FETCHING_DATA: "Se produjo un error al obtener sus datos.",
    MIN_BALANCE: (
      balance: any,
      currency: string,
      coin_symbol: string,
      coin: string,
      token_type: string
    ) =>
      `Para enviar ${coin_symbol.toUpperCase()} (${token_type.toUpperCase()}), necesita financiar ${coin.toUpperCase()} para la tarifa del gas (mínimo ${balance} ${currency})`,
    // Alchemy
    FAILED: "FALLIDA",
    // BTC
    INSUFFICIENT: "Saldo insuficiente",
    TRANSACTION_BROADCAST_SUCCESSFULLY:
      "La transacción se transmitió exitosamente a blockchain",
    TRANSACTION_BROADCAST_FAILED: "Transacción procesada.",
    INVALID_COIN_SYMBOL: "Solicitud de símbolo de moneda no válida.",
    //ETH
    GET_NONCE: "billetera nonce.",
    INSUFFICIENTETH: "Saldo ETH insuficiente.",
    INSUFFICIENTBNB: "Saldo BNB insuficiente.",

    ETH_INSUFFICIENT: (coin_symbol: string) =>
      `Insuficiente ${coin_symbol.toUpperCase()} Saldo.`,
    ETH_GAS: (gasInEthForErc: string) =>
      `Necesitas ${gasInEthForErc} Saldo ETH para esta solicitud de retiro.`,
    APPROVE_REQUEST:
      "La solicitud de aprobación se procesó correctamente. Esperando la confirmación de blockchain.",
    WITHDRAW_REQUEST_ETH: (amount: any, coin_symbol: string) =>
      `Retirar solicitud de ${amount} ${coin_symbol.toUpperCase()} has been processed successfully, Waiting for blockchain confirmation.`,
    SWAP_REQUEST_ETH: (amount: any, coin_symbol: string) =>
      `Swap request of ${amount} ${coin_symbol.toUpperCase()} has been processed successfully, Waiting for blockchain confirmation.`,
    TRANSACTION_REQUEST: "Transacción procesada.",
    PENDING: "pendiente.",
    ESTIMATE_ETH_TRANSFER_GAS_FEE:
      "Calcule la tarifa de transferencia de gas de ETH.",
    TRNX_NOT_FOUND: "Tx no encontrado.",
    //On-off-Ramp
    INITIATE_TXN_CREATED: "Transacción creada exitosamente.",

    //TRON
    ERC20_TOKEN_SEARCH:
      "No se puede recuperar el token ERC20. Por favor contacte con soporte",
    BSC_TOKEN_SEARCH:
      "No se puede recuperar el token BSC. Por favor contacte con soporte",
    TRON_TOKEN_SEARCH:
      "No se puede recuperar el token TRC20. Por favor contacte con soporte",
    SAME_ADDRESS: "¡No puedes enviar a la misma dirección!",
    INSUFFICIENTTRX: "¡Saldo insuficiente!",
    TRANSACTION_FEE_LOW: "¡La tarifa de transacción es muy baja!",
    INSUFFICIENT_GAS_PRICE: "¡Saldo insuficiente para pagar el precio del gas!",
    //CARDS
    CARDS_MAINTENANCE_MODE:
      "Las solicitudes de nuevas tarjetas están suspendidas debido al mantenimiento de los socios bancarios. Este servicio se reanudará la nueva semana y los depósitos funcionan como se esperaba.",
    EMAIL_EXIST: "Ya existe el correo electrónico.",
    SENT: "OTP enviada con éxito.",
    MOBILE_EXIST: "El número de móvil ya existe.",
    INVALID_NUMBER: "Ingrese un número de teléfono móvil válido.",
    OTP_VERIFIED: "OTP verificado exitosamente.",
    SESSION_TIMEOUT: "Hora de término de la sesión",
    INVALID_CODE: "Código no válido!",
    ADDED: "Agregado exitosamente.",
    CARD_NOT_FOUND: "¡Tarjeta no encontrada!",
    COIN_FETCH: "Moneda recuperada con éxito.",
    CARD_BIND: "¡¡¡Enlazado de tarjeta exitosamente!!!",
    WALLET_NOT_ACTIVE: "Cartera no activa",
    CARD_UN_BIND: "Tarjeta Desvinculante exitosamente!!!",
    VALIDATION_VAILED: "¡Validación fallida!",
    INVALID_FILE_TYPE:
      "Tipo de archivo no válido. Sólo se permiten archivos JPEG, JPG y PNG.",
    FILE_SIZE_EXCEED: "El tamaño del archivo supera el límite de 2 MB.",
    FILE_SIZE_EXCEED_MB: "El tamaño del archivo supera el límite de 1 MB.",
    INFORMATIION_IN_REVIEW: "Información en revisión.",
    CARD_NOT_SUPPORT_RECHARGING: "La tarjeta no admite recarga.",
    // Price_alerts, dapp, auth, swftc
    ALERT_EXISTS: "Esta alerta ya existe.",
    ALERT_CREATED: "Alerta creada exitosamente",
    ALERT_FETCHED: "Alerta obtenida exitosamente.",
    ALERT_DELETED: "Alerta eliminada exitosamente.",
    UNABLE_DECODE: "No se pueden decodificar datos.",
    //Verify_token
    SESSION_EXPIRED: "Sesión expirada",
    NO_TOKEN: "No se detectó ningún token",
    UNAUTHORIZED_ACCESS:
      "Acceso no autorizado. Por favor inicie sesión para continuar",
    //Validation
    VALIDATION_FAILED: "Validación fallida",
    //Users
    INVALID_REFERRAL_CODE: "Código de referencia no válido.",
    LOGOUT: "Cerró sesión exitosamente.",
    SAME_WALLET_ADDRESS_EXIST:
      "La libreta de direcciones ya está guardada con esta dirección de billetera.",
    SAME_WALLET_NAME_EXIST:
      "La libreta de direcciones ya está guardada con este nombre de billetera",
    MAX_LIMIT: "Límite máximo alcanzado.",
    ADDRESS_BOOK_SAVED: "Libreta de direcciones guardada correctamente.",
    GET_ADDRESS_BOOK: "La libreta de direcciones se obtuvo correctamente.",
    NO_WALLET_ADDRESS_EXIST:
      "La billetera de la libreta de direcciones no existe.",
    DELETED_ADDRESSBOOK_WALLET:
      "La cartera de la libreta de direcciones se ha eliminado correctamente.",
    NO_ADDRESSBOOK_EXIST: "La libreta de direcciones no existe.",
    ADDRESSBOOK_DELETED:
      "La libreta de direcciones se ha eliminado correctamente.",
    NO_ANNOUNEMENT: "Sin anuncio.",
    NO_FILE_SELECTED: "No hay ningún archivo seleccionado.",
    FILE_UPLOADED: "Documento cargado exitosamente.",
    WALLET_NONCE: "billetera",
    //CSV
    WITHDRAW: "Retirar",
    DEPOSIT: "Depósito",
    TYPE: "Tipo",
    FROM_ADRS: "De la Dirección",
    TO_ADRS: "Dirigirse",
    TX_ID: "ID de transacción",
    STATUS: "Estado",
    BLOCKCHAIN_STATUS: "Estado de la cadena de bloques",
    AMOUNT: "Cantidad",
    TRNX_FEE: "Tarifa de transacción",
    CREATED: "Creada",
    CROSS_CHAIN: "cadena cruzada",
    DAPP: "dapp",
    SWAP: "Intercambio",
    APPROVE: "Aprobar",
    BUY: "Comprar",
    CARD_FEES: "Tarifas de tarjeta",
    CARD_RECHARGE: "recarga_tarjeta",
    COMPLETED: "Terminada",
    FAILED_STATUS: "Fallida",
    CONFIRMED: "Confirmada",
    PENDING_STATUS: "Pendiente",
    // CSV FOR CARD HISTORY
    COIN: "Moneda",
    DESC: "Descripción",
    AMOUNTT: "Cantidad",
    USER_ID: "ID de usuario",
    EMAIL: "Correo electrónico",
    DATE: "Fecha",
    LEVEL_UPGRADE: "Mejora de nivel",
    SIGNED_SUCCESSFULLY: "Firmado exitosamente.",
    BSC_UNABLE_TO_ESTIMATE:
      "No se puede estimar la tarifa de gas por transferencia de token BEP20. El usuario no tiene saldo suficiente",
    REFERRED: "Existe la misma referencia",
    ADDRESS_BOOK_WITH_SAME_CONTACT_NAME_EXIST:
      "Ya existe una libreta de direcciones con el mismo nombre de contacto.",
    ADDRESS_BOOK_CONTACT_NAME_EDIT_SUCCESS:
      "Libreta de direcciones editada correctamente.",
    ADDRESS_BOOK_WITH_SAME_WALLET_NAME_EXIST:
      "Ya existe una libreta de direcciones con el mismo nombre de billetera.",
    ADDRESS_BOOK_WITH_SAME_ADDRESS_EXIST:
      "Ya existe una libreta de direcciones con la misma dirección.",
  },
};
