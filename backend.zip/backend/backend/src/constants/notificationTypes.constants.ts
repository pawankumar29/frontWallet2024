export enum NotificationTypes {
  WITHDRAW = 1,
  FAILED = 2,
  DEPOSIT = 3
}