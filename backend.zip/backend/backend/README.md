Future Wallet Backend (Decentralized Wallet)


