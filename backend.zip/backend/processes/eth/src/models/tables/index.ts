import CoinsModel from './model.coins';
import DeviceTokenModel from './model.deviceToken';
import NotificationModel from './model.notifications';
import TrnxHistoryModel from './model.trnxHistory';
import EthOldBLockModel from './model.eth_old_block';
import SettingsModel from './model.settings';
import CatchErrorMsgsModel from './model_catch_error_logs';
import RewardHistoryModel from './model.reward_history';
import ReferralModel from './model.referral';
import WalletModel from './model.wallets';
import CoinPriceInFiatModel from './model.coin_price_fiat';
import CustomTokennModel from './model.custom_tokens';

export {
    CoinsModel,
    DeviceTokenModel,
    NotificationModel,
    TrnxHistoryModel,
    EthOldBLockModel,
    SettingsModel,
    CatchErrorMsgsModel,
    RewardHistoryModel,
    ReferralModel,
    WalletModel,
    CoinPriceInFiatModel,
    CustomTokennModel
}