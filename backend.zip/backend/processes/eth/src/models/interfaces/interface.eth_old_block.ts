export interface EthOldBlockInterface {
    id: number;
    block_number: number;
    start_block: number;
    end_block: number;
    coin_family: number;
}
