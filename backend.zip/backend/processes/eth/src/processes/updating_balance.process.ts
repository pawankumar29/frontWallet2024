import { config } from "../config";
import rabbitMq from "../config/rabbitMq";
import { Wallet_Helper } from "../helpers";
import { WalletModel } from "../models";

class UpdateBalanceController {
    public async update_wallet_balance() {
        console.log('config.BACKEND_WALLET_ADDRESSES', config.config.ETH_ADDRESSES_PENDING_BALANCE_UPDATE);
        await rabbitMq.consumeQueue(
            config.config.ETH_ADDRESSES_PENDING_BALANCE_UPDATE || '',
            this.updateBalance
        )

    }
    public updateBalance= async (data: any)=>{
        try {
            if (data.queue_count < 10) {
               
                let balance: any = await Wallet_Helper.Update_Balance_Queue(data.wallet_address,data.coin_data);
                if (balance!==null) {
                    await WalletModel.update(
                        { balance: Number(balance) },
                        { where: { wallet_address: data.wallet_address, coin_id: data.coin_data.coin_id } })
                } else {
                    await rabbitMq.assertQueue(config.config.ETH_ADDRESSES_PENDING_BALANCE_UPDATE);
                    await rabbitMq.sendToQueue(config.config.ETH_ADDRESSES_PENDING_BALANCE_UPDATE, Buffer.from(JSON.stringify(
                        {
                            coin_data: data.coin_data,
                            wallet_address: data.wallet_address,
                            queue_count: data.queue_count + 1
                        })))
                }

                console.log("balance:::",balance);
            }
            else{
                 console.log(`updating balance attempts are more than 10 `);
            }
           
        } catch (err: any) {
            console.error("Error in updateBalance", err)
        }
    }



}


export default new UpdateBalanceController();