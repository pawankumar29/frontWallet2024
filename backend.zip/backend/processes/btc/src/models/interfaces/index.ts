export { CoinInterface } from './interface.coins';
export { NotificationInterface } from './interface.notifactions';
export { DeviceTokenInterface } from './interface.device_tokens';
export { ITrnxHistoryInterface } from './interface.trnxHistory';
export { WalletInterface } from './interface.wallets';
export { SettingsInterface } from './interface.settings';