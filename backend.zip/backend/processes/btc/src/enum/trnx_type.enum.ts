export enum TrnxTypeEnum {
    DEPOSIT = 'deposit',
    WITHDRAW = 'withdraw',
    DAPP = 'dapp',
    APPROVE = 'Approve',
    SWAP = 'Swap',
    CROSS_CHAIN = 'cross_chain'
}