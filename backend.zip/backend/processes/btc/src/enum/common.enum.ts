export enum BooleanEnum {
    false = 0,
    true = 1
}
export enum NotificationTypeEnum {
    DEPOSIT = 'deposit',
    WITHDRAW = 'withdraw',
}
export enum TxReqTypesEnum {
    APP = 'APP',
    EXNG = 'EXNG',
    TRANSAK = 'TRANSAK',
    ALCHEMY = 'ALCHEMY',
    NOTPRESET = 'NOT_PRESENT'
  }
