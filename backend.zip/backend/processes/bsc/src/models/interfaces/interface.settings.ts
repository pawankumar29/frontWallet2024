export interface SettingsInterface {
  id?: number,
  title: string,
  value: string | null,
  created_at: Date,
  updated_at: Date
}
