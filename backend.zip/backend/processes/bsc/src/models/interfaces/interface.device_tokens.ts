export interface DeviceTokenInterface {
    id: number;
    device_token: string | string[];
    user_id: number;
    status: number;
    push?: number;
}
