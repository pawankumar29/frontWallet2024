import CoinsModel from './model.coins';
import DeviceTokenModel from './model.deviceToken';
import NotificationModel from './model.notifications';
import TrnxHistoryModel from './model.trnxHistory';
import BscOldBLockModel from './model.bsc_old_block';
import SettingsModel from './model.settings';
import CatchErrorMsgsModel from './model_catch_error_logs';
import RewardHistoryModel from './model.reward_history';
import WalletModel from './model.wallets';
import ReferralModel from './model.referral';
import CoinPriceInFiatModel from './model.coin_price_fiat';
import CustomTokennModel from './model.custom_tokens';
export {
    CoinsModel,
    DeviceTokenModel,
    NotificationModel,
    TrnxHistoryModel,
    BscOldBLockModel,
    SettingsModel,
    CatchErrorMsgsModel,
    RewardHistoryModel,
    WalletModel,
    ReferralModel,
    CoinPriceInFiatModel,
    CustomTokennModel
}