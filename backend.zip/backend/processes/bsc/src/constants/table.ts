export enum TrnxHistory {
    TRNX_HISTORY = "trnx_histories"
}

export enum WALLETS {
    WALLETS = "wallets"
}