export enum KEYS {
    latestBlock='latestBlock',
    behinedBlock ='behinedBlock',
    readSpecificBlock='readSpecificBlock'
}