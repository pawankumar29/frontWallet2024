export enum BlockChainStatusEnum {
    PENDING = 'pending',
    FAILED = 'failed',
    CONFIRMED = 'confirmed'
}