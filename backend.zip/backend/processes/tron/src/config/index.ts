import { config } from "./config";
export { config }