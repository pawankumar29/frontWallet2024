import { config } from "../../config";
import { Wallets } from '.././../models/model/index';
import redisClient from "../../helpers/common/redis";
import NonEvmHelper from "../../helpers/common/non.evm.helper";
import { RabbitMq } from "../../helpers/common/rabbitmq.helper";
import { getBalances } from "../../helpers/common/globalFunctions";

class UpdateBalanceController {
    public async update_wallet_balance() {
        console.log('config.BACKEND_WALLET_ADDRESSES', config.BACKEND_WALLET_ADDRESSES);
        await RabbitMq.consumeQueue(
            config.BACKEND_WALLET_ADDRESSES || '',
            this.updateBalance
        )

    }
    public async updateBalance(data: any) {
        try {
            console.log("Entered into updateBalance", data);
            if (data.queue_count < 10) {
                let balDetails: any = await getBalances(data.coin_data, data.wallet_address);
                if (balDetails.status) {
                    await Wallets.WalletWrite.update(
                        { balance: balDetails.balance },
                        { where: { wallet_address: data.wallet_address, coin_id: data.coin_data.coin_id } })
                } else {
                    await RabbitMq.assertQueue(config.BACKEND_WALLET_ADDRESSES);
                    await RabbitMq.sendToQueue(config.BACKEND_WALLET_ADDRESSES, Buffer.from(JSON.stringify(
                        {
                            coin_data: data.coin_data,
                            wallet_address: data.wallet_address,
                            queue_count: data.queue_count + 1
                        })))
                }
            }
        } catch (err: any) {
            console.error("Error in updateBalance", err)
        }
    }

    public async updateBtcBalances() {
        try {
            console.log("Enterd into update_balances")
            let offset: number = 0;
            let limit: number = 8;
            let findCoinCounter: any = await redisClient.getKeyValuePair(config.REDISKEYS.COIN_LIMIT_COUNTS, `update_btc_balances`);
            if (findCoinCounter) {
                offset = Number(findCoinCounter);
            }
            console.log("Enterd into update_balances offset offset>>>>>>>>>>", offset)

            let user_wallets: any = await Wallets.WalletRead.findAndCountAll({
                attributes: ["wallet_address", "wallet_id"],
                where: { coin_family: config.STATIC_COIN_FAMILY.BTC },
                order: [['wallet_id', 'ASC']],
                limit: limit,
                offset: offset
            })
            if (user_wallets.rows.length > 0) {

                console.log("user_wallets.rows.length > 0", user_wallets.rows.length)
                console.log("No data in user_wallets table with this limit>>>", limit, "offset>>", offset)
                for (let i: number = 0; i < user_wallets.rows.length; i++) {
                    let bal = await NonEvmHelper.get_user_btc_balance(user_wallets.rows[i].wallet_address)
                    let balance: string | null = bal !== null ? bal.toString() : null
                    console.log("wallet_id >>>", user_wallets.rows[i].wallet_id, "wallet_address>>", user_wallets.rows[i].wallet_address, "balance>>", balance)
                    if (balance) {
                        await Wallets.WalletWrite.update({ balance: balance }, { where: { wallet_id: user_wallets.rows[i].wallet_id } })

                        await redisClient.setKeyValuePair(config.REDISKEYS.COIN_LIMIT_COUNTS, `update_btc_balances`, (offset + limit).toString());
                    }
                }
            } else {
                console.log("not data exist in user_wallets.rows.length")
            }
        } catch (err: any) {
            console.error("Error in updateBtcBalances", err)
        }

    }
    public async updateUsdtBalances() {
        try {
            console.log("Enterd into updateUsdtBalances")
            let offset: number = 0;
            let limit: number = 8;
            let findCoinCounter: any = await redisClient.getKeyValuePair(config.REDISKEYS.COIN_LIMIT_COUNTS, `update_usdt_balances`);
            if (findCoinCounter) {
                offset = Number(findCoinCounter);
            }
            console.log("Enterd into updateUsdtBalances offset offset>>>>>>>>>>", offset)

            let user_wallets: any = await Wallets.WalletRead.findAndCountAll({
                attributes: ["wallet_address", "wallet_id"],
                where: { coin_id: 360 },
                order: [['wallet_id', 'ASC']],
                limit: limit,
                offset: offset
            })
            if (user_wallets.rows.length > 0) {

                console.log("updateUsdtBalances.rows.length > 0", user_wallets.rows.length)
                console.log("No data in updateUsdtBalances table with this limit>>>", limit, "offset>>", offset)
                for (let i: number = 0; i < user_wallets.rows.length; i++) {
                    let bal = await NonEvmHelper.TRC20_Token_Balance(user_wallets.rows[i].wallet_address, 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t')
                    let balance: string | null = bal ? bal.toString() : null;
                    console.log("wallet_id >>>", user_wallets.rows[i].wallet_id, "wallet_address>>", user_wallets.rows[i].wallet_address, "balance>>", balance)
                    if (balance) {
                        await Wallets.WalletWrite.update({ balance: balance }, { where: { wallet_id: user_wallets.rows[i].wallet_id } })
                        await redisClient.setKeyValuePair(config.REDISKEYS.COIN_LIMIT_COUNTS, `update_usdt_balances`, (offset + limit).toString());
                    }
                }
            } else {
                console.log("not data exist in updateUsdtBalances.rows.length")
            }
        } catch (err: any) {
            console.error("Error in updateUsdtBalances", err)
        }

    }

}
const update_balance_controller = new UpdateBalanceController();
export default update_balance_controller;