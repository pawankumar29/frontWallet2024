export enum TxReqTypesEnum {
    APP = 'APP',
    EXNG = 'EXNG',
    TRANSAK = 'TRANSAK',
    ALCHEMY = 'ALCHEMY',
    NOTPRESET = 'NOT_PRESENT'
  }