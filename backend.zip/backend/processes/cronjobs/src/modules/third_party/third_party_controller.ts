import axios from "axios";
import { config } from "../../config";
import { GasPrice } from "../../models/model/index"

const { ETH: ETH, BNB: BNB } = config.STATIC_COIN_FAMILY;


class ThirdPartyController {
    public updateGasPrice = async () => {
        console.error("success ~ ~ updateGasPrice",);
        try {
            let url: string = `https://api.etherscan.io/api?module=gastracker&action=gasoracle&apikey=${config.ETH_GAS_FEE_API_KEY}`;
            await axios.get(url).then(async (responce) => {
                // console.log(' responce.data', responce);
                if (responce.status == 200) {
                    await GasPrice.GasPriceWrite.update(
                        {
                            safe_gas_price: Math.floor(
                                responce.data.result.SafeGasPrice
                            ),
                            propose_gas_price: Math.floor(
                                responce.data.result.ProposeGasPrice
                            ),
                            fast_gas_price: Math.floor(
                                responce.data.result.FastGasPrice
                            ),
                        },
                        {
                            where: { coin_family: ETH },
                        }
                    );
                }
            });
            return;
        } catch (err: any) {
            let message: any = (err as Error).message;
            console.error("🔥 ~ ~ updateGasPrice error", message);
            return;
        }
    };

    public updateBNBGasPrice = async () => {
        console.error("success ~ ~ updateBNBGasPrice",);
        try {
            let url: string = `https://api.bscscan.com/api?module=gastracker&action=gasoracle&apikey=${config.BNB_GAS_FEE_API_KEY}`;
            await axios.get(url).then(async (responce) => {
                if (responce.status == 200) {
                    await GasPrice.GasPriceWrite.update(
                        {
                            safe_gas_price: Math.floor(
                                responce.data.result.SafeGasPrice
                            ),
                            propose_gas_price: Math.floor(
                                responce.data.result.ProposeGasPrice
                            ),
                            fast_gas_price: Math.floor(
                                responce.data.result.FastGasPrice
                            ),
                        },
                        {
                            where: { coin_family: BNB },
                        }
                    );
                }
            });
            return;
        } catch (err: any) {
            let message: any = (err as Error).message;
            console.error("🔥 ~ ~ updateBNBGasPrice error", message);
            return;
        }
    };
}


const third_party_controller = new ThirdPartyController();
export default third_party_controller;
