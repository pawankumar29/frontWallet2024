export enum StatusCodes {
  SUCCESS = 200,
  CREATED = 201,
  ACCEPTED = 202,
  NOCONTENT = 204,
  BADREQUEST = 400,
  FORBIDDEN = 403,
  NOTFOUND = 404,
  TIMEOUT = 408,
  CONFLICT = 409,
  LENGTHREQUIRED = 411,
  UNRESPONSIBLEENTITY = 422,
  TOOMANYREQ = 429,
  INTERNALSERVER = 500,
  BADGATEWAYS = 502,
  SERVICEUNAVILABLE = 503,
  GATEWAYTIMEOUT = 504,
}

export enum LogsConstants {
  RABBIT_MQ_CONNECTED = "😆 Successfully connected to RabbitMQ server",
  RABBIT_MQ_CHANNEL_CREATED = "😆 RabbitMQ channel created successfully",
  RABBIT_MQ_CONNECTION_FAILED = "💩 Failed to connect to RabbitMQ server.",
  RABBIT_MQ_CHANNEL_FAILED = "💩 Failed to create channel.",
  ASSERT_QUEUE_FAILED = "💩 Failed to assert queue:- ",
  NOT_OUR_WALLET = "💩 Not our exchange wallet ",
  BLOCK_NUMBER_EXCEEDING = "💥 Running ahead of current blockchain",
}

export enum TrnxBlockchainStatus {
  PENDING = 'pending',
  FAILED = 'failed',
  CONFIRMED = 'confirmed',
}




