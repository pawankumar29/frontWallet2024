export enum TimePeriods {
  DAY = "24h",
  WEEK = "7d",
  MONTH = "30d",
  MONTHS3 = "3m",
  YEAR = "1y",
  YEARS5 = "5y",
}
