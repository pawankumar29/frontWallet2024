// export enum COIN_FAMILY {
//     bnb = 1,
//     eth = 2,
//     btc = 3,
//     //matic = 4,
//     tron = 6
// }
export enum COINS {
    ETH = 'ETH',
    BTC = 'BTC',
    TRX = 'TRX',
    BSC = 'BSC'
}
export enum ADDED_BY {
    admin = 'admin'
}

export enum TOKENS {
    ERC20 = 'ERC20',
    TRC20 = 'TRC20',
    BEP20 = 'BEP20'
}

export enum Boolean {
    true = 1,
    false = 0
}