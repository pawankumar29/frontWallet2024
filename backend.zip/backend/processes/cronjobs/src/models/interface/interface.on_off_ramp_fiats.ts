export interface OnOffRampFiatsInterface {
    id?: number;
    country_name: string,
    country_code: string,
    alchemy_payment_details: any | null,
    fiat_currency: string,
    transak_payment_detials: any | null
}
