export interface CurrencyFiatModel {
  currency_id: number;
  currency_name: string;
  currency_code: string;
  currency_symbol: string;
  uuid?: string;
}
