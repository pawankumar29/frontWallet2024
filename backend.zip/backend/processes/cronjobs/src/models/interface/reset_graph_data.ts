export interface ResetGraphModel {
    id: number;
    cmc_id: number,
    graph_type: string,
    created_at?: string;
    updated_at?: string | null;
}