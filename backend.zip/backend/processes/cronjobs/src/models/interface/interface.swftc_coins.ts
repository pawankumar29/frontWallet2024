export interface SWFTCcoinsInterface {
    id: number,
    coinName: string,
    coinCode: string,
    mainNetwork: string,
    contact: string,
    coinDecimal: number,
    noSupportCoin: string,
    isSupportAdvanced: string,
    isSupportMemo: string,
    coinCodeShow:string,
    coinImageUrl:string | null,
    status:number
}