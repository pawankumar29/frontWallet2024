export interface UserModel {
    user_id: number,
    currency_fiat_id: number,
    name?: string | null,
    wallet_pin?: string | null,
    mobile_no?: number | null,
    country_code_id?: number | null,
    google_2fa_secret?: string,
    google2fa_status?:number,
    referral_code?:string,
    referrer_code?:string,
    created_at: string,
    updated_at: string
}