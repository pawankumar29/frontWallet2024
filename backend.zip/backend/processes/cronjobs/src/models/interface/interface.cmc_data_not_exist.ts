export interface CMCDataNotExistInterface {
    id: number;
    cmc_id: number | null;
    fiat_type: string;
    token_address: string | null;
}

