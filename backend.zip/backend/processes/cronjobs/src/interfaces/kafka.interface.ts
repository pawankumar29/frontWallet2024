export interface KafkaCrednetials {
  clientId: string;
  brokers: string[];
}